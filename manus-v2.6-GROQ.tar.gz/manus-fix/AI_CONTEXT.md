# Contexto para IA - Asistente IA Autónomo

**Propósito:** Este documento proporciona contexto estructurado para que otras IAs puedan comprender y continuar el desarrollo del proyecto.

**Fecha:** Febrero 2026  
**Versión:** 2.0

---

## Resumen del Proyecto

Este es un **Asistente IA Autónomo** con capacidades de razonamiento, planificación y ejecución de tareas complejas. El sistema implementa un loop de razonamiento iterativo que permite al agente usar 13 herramientas especializadas para completar solicitudes del usuario.

**Características principales:**
- Motor de agente autónomo con loop de razonamiento (analizar → planificar → ejecutar → observar)
- 13 herramientas: búsqueda web, navegación, ejecución de código, análisis de datos, generación de imágenes/video, transcripción de audio, scraping, sistema de archivos
- Sistema de auto-mejora que propone cambios al propio código con aprobación del usuario
- Interfaz de chat en tiempo real con visualización de herramientas en ejecución
- Sistema de subida de archivos de todo tipo
- Autenticación con Manus OAuth
- Almacenamiento S3 para archivos generados

**Stack tecnológico:** React 19, TypeScript, tRPC 11, Express 4, Drizzle ORM, MySQL/TiDB, Tailwind CSS 4, shadcn/ui, Manus LLM API.

---

## Arquitectura de Alto Nivel

El sistema sigue una arquitectura de tres capas:

### Capa de Presentación (Frontend)
- **Ubicación:** `client/src/`
- **Framework:** React 19 con TypeScript
- **Estilos:** Tailwind CSS 4 con tema personalizado (púrpura)
- **Componentes UI:** shadcn/ui (Radix UI)
- **Rutas:** wouter (router ligero)
- **Estado:** React Query (via tRPC)

**Páginas principales:**
- `Chat.tsx`: Interfaz principal de chat con el agente
- `Improvements.tsx`: Revisión y aprobación de propuestas de auto-mejora
- `NotFound.tsx`: Página 404

**Componentes clave:**
- `FileUpload.tsx`: Subida de archivos con drag & drop
- `ImprovementProposalCard.tsx`: Tarjeta de propuesta de mejora
- `useAuth` hook: Gestión de autenticación

### Capa de Lógica de Negocio (Backend)
- **Ubicación:** `server/`
- **Framework:** Express 4 con tRPC 11
- **LLM:** Manus Built-in API (Claude/GPT compatible)
- **Autenticación:** Manus OAuth con JWT sessions

**Componentes clave:**
- `agent.ts`: Motor del agente autónomo (loop de razonamiento)
- `routers.ts`: Definición de API tRPC (auth, chat, improvements, files)
- `tools/*.ts`: 13 herramientas del agente
- `db.ts`: Helpers de base de datos (Repository pattern)
- `storage.ts`: Helpers de S3
- `improvementApplicator.ts`: Aplicador automático de mejoras

### Capa de Datos
- **Base de Datos:** MySQL/TiDB con Drizzle ORM
- **Almacenamiento:** S3 compatible para archivos
- **Servicios Externos:** Manus APIs (LLM, OAuth, Image Generation, Whisper)

---

## Motor del Agente Autónomo

### Ubicación
`server/agent.ts`

### Función Principal
`executeAgent(userMessage: string, conversationId: number, userId: number): Promise<AgentResponse>`

### Flujo de Ejecución

El agente implementa un loop iterativo con las siguientes fases:

**1. Construcción de Contexto:**
- Carga historial de conversación desde la base de datos
- Construye array de mensajes con roles (system, user, assistant, tool)
- Agrega prompt del sistema que describe capacidades y herramientas

**2. Loop de Razonamiento (máximo 10 iteraciones):**

```
WHILE iteration < maxIterations:
  - Invocar LLM con contexto actual y herramientas disponibles
  - ¿El LLM solicita tool_calls?
    - SÍ:
      - Para cada tool_call:
        - Parsear argumentos JSON
        - Ejecutar función de herramienta
        - Capturar resultado (éxito o error)
        - Agregar resultado al contexto como mensaje "tool"
      - Incrementar iteration
      - Continuar loop
    - NO:
      - Extraer respuesta final del LLM
      - Salir del loop
```

**3. Persistencia:**
- Guardar mensaje del usuario en la base de datos
- Guardar respuesta del agente en la base de datos
- Guardar cada ejecución de herramienta en `toolExecutions`

**4. Retorno:**
- Retornar respuesta final con pasos ejecutados

### Herramientas Disponibles

El agente tiene acceso a 13 herramientas registradas en dos estructuras:

**AVAILABLE_TOOLS:** Array de definiciones de herramientas (schemas) que se pasan al LLM

**TOOL_FUNCTIONS:** Mapa de `nombre_herramienta` → función de ejecución

| Herramienta | Archivo | Propósito |
|-------------|---------|-----------|
| search_web | tools/search.ts | Búsqueda en DuckDuckGo |
| navigate_to_url | tools/browser.ts | Navegar y extraer contenido de URLs |
| extract_data | tools/browser.ts | Scraping con selectores CSS |
| scrape_web | tools/webScraper.ts | Scraping avanzado con Cheerio |
| execute_code | tools/codeExecutor.ts | Ejecutar Python/JS en sandbox |
| analyze_data | tools/dataAnalyzer.ts | Análisis de CSV/Excel con Pandas |
| generate_image | tools/imageGenerator.ts | Generación de imágenes con Manus API |
| generate_video | tools/videoGenerator.ts | Generación de video con Runway ML |
| transcribe_audio | tools/audioTranscriber.ts | Transcripción con Whisper API |
| read_file | tools/fileSystem.ts | Leer archivos del workspace |
| write_file | tools/fileSystem.ts | Escribir archivos al workspace |
| list_files | tools/fileSystem.ts | Listar archivos disponibles |
| propose_self_improvement | tools/selfImprovement.ts | Proponer mejoras al código |

### Agregar Nueva Herramienta

Para agregar una herramienta:

1. Crear archivo `server/tools/miHerramienta.ts` con:
   - Interfaces `Input` y `Output`
   - Función `async ejecutarMiHerramienta(input): Promise<Output>`
   - Objeto `miHerramientaTool` con schema para el LLM

2. Importar en `server/agent.ts`

3. Agregar a `AVAILABLE_TOOLS` array

4. Agregar a `TOOL_FUNCTIONS` map

---

## Sistema de Auto-Mejora

### Propósito
Permite que el agente proponga cambios a su propio código buscando implementaciones en GitHub y analizando patrones.

### Flujo Completo

**1. Propuesta (Herramienta `propose_self_improvement`):**
- Usuario solicita funcionalidad o agente detecta limitación
- Agente busca código relevante en GitHub
- Analiza patrones de implementación
- Genera propuesta estructurada con:
  - Título y descripción
  - Justificación técnica
  - Cambios de código (diff format)
  - Nivel de impacto (low/medium/high)
- Guarda en tabla `improvementProposals` con status "pending"
- Notifica al propietario

**2. Revisión (Página `/improvements`):**
- Usuario ve lista de propuestas pendientes
- Puede expandir cada propuesta para ver detalles
- Revisa diff de código propuesto
- Aprueba o rechaza con botones de acción

**3. Aplicación (Procedimiento `applyImprovement`):**
- Crea backup de archivos afectados en `/tmp/backups/`
- Aplica cambios de código usando `fs.writeFileSync`
- Ejecuta `pnpm check` para validar sintaxis TypeScript
- Si validación falla:
  - Restaura archivos desde backup (rollback automático)
  - Marca propuesta como "rejected"
  - Notifica al usuario del fallo
- Si validación exitosa:
  - Marca propuesta como "applied"
  - Notifica al usuario del éxito

### Archivos Clave

- `server/tools/selfImprovement.ts`: Herramienta de propuesta
- `server/improvementApplicator.ts`: Aplicador automático
- `client/src/pages/Improvements.tsx`: Interfaz de revisión
- `drizzle/schema.ts`: Tabla `improvementProposals`

### Seguridad

- Aprobación humana obligatoria
- Backup antes de modificar
- Validación de sintaxis
- Rollback automático si falla
- Auditoría completa en base de datos

---

## Base de Datos

### Esquema (drizzle/schema.ts)

**Tabla users:**
- id (PK, autoincrement)
- openId (unique, OAuth identifier)
- email, name, loginMethod
- role (enum: user/admin)
- createdAt, updatedAt, lastSignedIn

**Tabla conversations:**
- id (PK)
- userId (FK → users)
- title
- createdAt, updatedAt

**Tabla messages:**
- id (PK)
- conversationId (FK → conversations)
- role (enum: system/user/assistant/tool)
- content (text)
- createdAt

**Tabla toolExecutions:**
- id (PK)
- messageId (FK → messages)
- toolName, toolInput (JSON), toolOutput (JSON)
- status (enum: success/error)
- executedAt

**Tabla uploadedFiles:**
- id (PK)
- userId (FK), conversationId (FK, optional)
- filename, mimeType, size
- s3Key, s3Url
- uploadedAt

**Tabla improvementProposals:**
- id (PK)
- userId (FK)
- title, description, justification
- impact (enum: low/medium/high)
- codeChanges (JSON)
- status (enum: pending/approved/rejected/applied)
- createdAt, approvedAt, appliedAt

### Helpers (server/db.ts)

Funciones principales:
- `getDb()`: Retorna instancia de Drizzle
- `upsertUser(user)`: Crea o actualiza usuario
- `getUserByOpenId(openId)`: Busca usuario por OAuth ID

Patrón: Repository pattern con funciones específicas por entidad.

---

## API tRPC

### Routers (server/routers.ts)

**Router auth:**
- `me`: Query que retorna usuario actual (o null)
- `logout`: Mutation que limpia cookie de sesión

**Router chat:**
- `sendMessage`: Mutation que ejecuta el agente y retorna respuesta
- `getConversations`: Query que lista conversaciones del usuario
- `getMessages`: Query que obtiene mensajes de una conversación
- `createConversation`: Mutation que crea nueva conversación
- `deleteConversation`: Mutation que elimina conversación

**Router improvements:**
- `list`: Query que lista propuestas con filtros por status
- `approve`: Mutation que aprueba propuesta
- `reject`: Mutation que rechaza propuesta
- `applyImprovement`: Mutation que aplica mejora aprobada
- `rollback`: Mutation que revierte mejora aplicada

**Router files:**
- `upload`: Mutation que sube archivo a S3
- `list`: Query que lista archivos del usuario
- `delete`: Mutation que elimina archivo

### Uso en Frontend

```typescript
// Query
const { data, isLoading } = trpc.chat.getMessages.useQuery({ conversationId });

// Mutation
const sendMessage = trpc.chat.sendMessage.useMutation();
await sendMessage.mutateAsync({ message, conversationId });
```

---

## Autenticación

### Flujo OAuth

1. Usuario hace clic en "Iniciar sesión"
2. Frontend redirige a `VITE_OAUTH_PORTAL_URL` con state
3. Usuario se autentica en Manus
4. Manus redirige a `/api/oauth/callback` con código
5. Backend intercambia código por tokens
6. Backend crea sesión JWT y la almacena en cookie httpOnly
7. Frontend redirige a la aplicación

### Verificación de Sesión

En cada request a `/api/trpc`:
1. Middleware de contexto (`server/_core/context.ts`) lee cookie
2. Verifica y decodifica JWT con `JWT_SECRET`
3. Carga usuario desde base de datos usando `openId`
4. Agrega usuario al contexto de tRPC

### Procedimientos Protegidos

```typescript
const protectedProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: 'UNAUTHORIZED' });
  return next({ ctx: { ...ctx, user: ctx.user } });
});
```

### Reconocimiento de Creador

El usuario con email "damh0087@gmail.com" se reconoce automáticamente como admin en `server/db.ts`:

```typescript
if (user.openId === ENV.ownerOpenId || user.email === "damh0087@gmail.com") {
  values.role = 'admin';
}
```

---

## Frontend

### Estructura de Componentes

**Páginas:**
- `Chat.tsx`: Interfaz principal con historial de mensajes, input, botón de subida de archivos
- `Improvements.tsx`: Lista de propuestas con filtros (pending/approved/rejected/applied)
- `NotFound.tsx`: Página 404

**Componentes reutilizables:**
- `FileUpload.tsx`: Drag & drop, previsualizaciones, subida a S3
- `ImprovementProposalCard.tsx`: Tarjeta expandible con diff de código

### Hooks Personalizados

**useAuth:**
```typescript
const { user, loading, error, isAuthenticated, logout } = useAuth();
```

Encapsula lógica de autenticación usando `trpc.auth.me.useQuery()`.

### Estilos

**Tema:** Definido en `client/src/index.css` con CSS variables.

**Colores principales:**
- Primary: Púrpura (#9333ea)
- Background: Blanco/gris claro
- Foreground: Gris oscuro

**Componentes UI:** shadcn/ui con Radix UI (accesibles y personalizables).

---

## Tareas Pendientes

Consulta `todo.md` para ver el estado actual de todas las funcionalidades. Las tareas marcadas con `[ ]` están pendientes, las marcadas con `[x]` están completadas.

**Funcionalidades principales completadas:**
- Motor del agente autónomo ✓
- 13 herramientas especializadas ✓
- Sistema de auto-mejora con aprobación ✓
- Interfaz de chat ✓
- Sistema de subida de archivos ✓
- Autenticación OAuth ✓
- Almacenamiento S3 ✓

**Funcionalidades pendientes:**
- Sidebar con historial de conversaciones
- Streaming en tiempo real de respuestas del agente
- Interfaz de gestión de usuarios para el creador
- Limpieza automática de archivos temporales
- Herramientas adicionales (procesamiento de documentos, síntesis de voz, traducción)

---

## Problemas Conocidos

### Error del LLM con tool_use_id

**Síntoma:** Error en logs: `"messages.2.content.0.tool_result.tool_use_id: String should match pattern '^[a-zA-Z0-9_-]+$'"`

**Causa:** El `tool_use_id` generado por el LLM contiene caracteres no permitidos.

**Solución temporal:** El sistema valida `response.choices` antes de usarlo y maneja el error gracefully.

**Solución permanente:** Sanitizar `tool_use_id` antes de enviarlo de vuelta al LLM.

### Límite de Iteraciones

**Síntoma:** El agente se detiene después de 10 pasos incluso si no terminó la tarea.

**Causa:** `maxIterations` está configurado en 10 para prevenir loops infinitos.

**Solución:** Aumentar `maxIterations` en `server/agent.ts` si es necesario, o implementar detección más inteligente de completitud.

---

## Cómo Continuar el Desarrollo

### Para Otra IA

Si eres una IA que va a continuar este proyecto:

1. **Lee primero estos documentos:**
   - `TECHNICAL_DOCUMENTATION.md`: Visión completa del sistema
   - `ARCHITECTURE_GUIDE.md`: Diagramas y patrones de diseño
   - `DEVELOPMENT_MANUAL.md`: Instrucciones paso a paso
   - `AI_CONTEXT.md`: Este documento (contexto estructurado)

2. **Explora el código:**
   - Comienza por `server/agent.ts` (motor del agente)
   - Revisa `server/routers.ts` (API completa)
   - Examina `client/src/pages/Chat.tsx` (interfaz principal)
   - Estudia `drizzle/schema.ts` (modelo de datos)

3. **Ejecuta el proyecto:**
   - `pnpm install` para instalar dependencias
   - `pnpm dev` para iniciar servidor de desarrollo
   - Abre `http://localhost:3000` en el navegador

4. **Consulta `todo.md`:**
   - Identifica tareas pendientes
   - Prioriza según necesidades del usuario
   - Marca tareas completadas con `[x]`

5. **Sigue las mejores prácticas:**
   - Validar inputs con Zod
   - Manejar errores con try-catch
   - Documentar funciones complejas
   - Escribir tests para nuevas funcionalidades
   - Crear checkpoint antes de cambios grandes

### Para Humanos

Si eres un desarrollador humano:

1. **Configura el entorno:**
   - Instala Node.js 22+
   - Clona el repositorio
   - Ejecuta `pnpm install`
   - Configura variables de entorno

2. **Familiarízate con el stack:**
   - React 19 + TypeScript
   - tRPC 11 (type-safe API)
   - Drizzle ORM (base de datos)
   - Tailwind CSS 4 (estilos)

3. **Lee la documentación:**
   - `README.md`: Visión general
   - `DEVELOPMENT_MANUAL.md`: Guía práctica
   - `ARCHITECTURE_GUIDE.md`: Diseño del sistema

4. **Empieza con tareas pequeñas:**
   - Agregar una nueva herramienta
   - Crear un nuevo componente UI
   - Agregar un procedimiento tRPC
   - Escribir tests

---

## Información de Contacto

**Creador del proyecto:** damh0087@gmail.com (reconocido como admin automáticamente)

**Soporte de Manus:** https://help.manus.im

**Documentación de Manus:** https://docs.manus.im

---

## Conclusión

Este proyecto es un asistente IA autónomo completo con capacidades avanzadas de razonamiento y auto-mejora. El sistema está diseñado para ser extensible, mantenible y seguro. La arquitectura modular facilita agregar nuevas herramientas y funcionalidades sin modificar el núcleo del sistema.

Para cualquier pregunta o problema, consulta la documentación técnica completa o el manual de desarrollo. Si eres una IA, sigue las instrucciones de "Cómo Continuar el Desarrollo" para empezar a trabajar en el proyecto.

---

**Documento generado por Manus AI - Febrero 2026**
