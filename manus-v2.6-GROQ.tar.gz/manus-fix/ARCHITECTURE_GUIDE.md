# Guía de Arquitectura - Asistente IA Autónomo

**Autor:** Manus AI  
**Fecha:** Febrero 2026  
**Versión:** 2.0

---

## Introducción

Esta guía proporciona una visión detallada de la arquitectura del Asistente IA Autónomo, incluyendo diagramas de componentes, flujos de datos y patrones de diseño utilizados. El objetivo es facilitar la comprensión del sistema para desarrolladores que deseen extenderlo o mantenerlo.

---

## Arquitectura de Alto Nivel

El sistema sigue una arquitectura de tres capas con separación clara de responsabilidades:

```
┌─────────────────────────────────────────────────────────────┐
│                     CAPA DE PRESENTACIÓN                     │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  Chat.tsx    │  │Improvements  │  │ FileUpload   │     │
│  │              │  │    .tsx      │  │    .tsx      │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
│  React 19 + Tailwind CSS + shadcn/ui                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ tRPC (Type-Safe API)
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  CAPA DE LÓGICA DE NEGOCIO                   │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  agent.ts    │  │  routers.ts  │  │  tools/*     │     │
│  │ (Motor del   │  │ (API tRPC)   │  │ (13 tools)   │     │
│  │   Agente)    │  │              │  │              │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
│  Express 4 + tRPC 11 + Manus LLM API                        │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ Drizzle ORM
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                       CAPA DE DATOS                          │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  MySQL/TiDB  │  │   S3 Storage │  │  Manus APIs  │     │
│  │  (Relacional)│  │   (Archivos) │  │  (LLM, OAuth)│     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

La comunicación entre capas es unidireccional: el frontend solo habla con el backend a través de tRPC, y el backend gestiona toda la comunicación con la base de datos y servicios externos.

---

## Flujo de Datos Principal

### Flujo de Conversación con el Agente

Cuando un usuario envía un mensaje al agente, el sistema ejecuta el siguiente flujo:

```
Usuario escribe mensaje
        │
        ▼
Frontend (Chat.tsx)
        │
        │ trpc.chat.sendMessage.mutate()
        ▼
Backend (routers.ts)
        │
        │ Validar autenticación
        │ Guardar mensaje en DB
        ▼
Motor del Agente (agent.ts)
        │
        │ Construir contexto
        │ Loop de razonamiento
        ▼
┌───────────────────────────────────────┐
│   LOOP DE RAZONAMIENTO (max 10 iter) │
│                                       │
│  1. Invocar LLM con contexto          │
│  2. ¿Hay tool_calls?                  │
│     │                                 │
│     ├─ SÍ: Ejecutar herramientas      │
│     │   │                             │
│     │   ├─ search_web                 │
│     │   ├─ execute_code               │
│     │   ├─ generate_image             │
│     │   └─ ...                        │
│     │                                 │
│     │   Agregar resultados al contexto│
│     │   Volver a paso 1               │
│     │                                 │
│     └─ NO: Generar respuesta final    │
│                                       │
└───────────────────────────────────────┘
        │
        │ Respuesta completa
        ▼
Backend guarda respuesta en DB
        │
        ▼
Frontend recibe respuesta
        │
        ▼
Usuario ve respuesta en chat
```

Este flujo garantiza que el agente pueda ejecutar múltiples herramientas en secuencia hasta completar la tarea solicitada.

---

## Arquitectura del Motor del Agente

El motor del agente (`server/agent.ts`) es el componente más complejo del sistema. Su arquitectura interna se organiza de la siguiente manera:

### Componentes del Motor

**Sistema de Prompt:** Define las capacidades del agente y las herramientas disponibles. El prompt del sistema se construye dinámicamente incluyendo descripciones de todas las herramientas registradas en `AVAILABLE_TOOLS`.

**Gestor de Contexto:** Mantiene el historial completo de la conversación en un array de mensajes. Cada mensaje tiene un rol (system, user, assistant, tool) y contenido. El contexto se pasa al LLM en cada iteración.

**Selector de Herramientas:** El LLM decide qué herramientas usar mediante function calling nativo. El sistema valida que las herramientas solicitadas existan en `TOOL_FUNCTIONS` antes de ejecutarlas.

**Ejecutor de Herramientas:** Toma los parámetros proporcionados por el LLM, invoca la función correspondiente y captura el resultado (éxito o error). Los resultados se agregan al contexto como mensajes de tipo "tool".

**Detector de Completitud:** Determina cuándo el agente ha terminado la tarea. Esto ocurre cuando el LLM no solicita más herramientas o cuando se alcanza el límite de iteraciones.

### Diagrama de Flujo Interno

```
executeAgent(userMessage)
        │
        ▼
Construir contexto inicial
[system prompt, historial, userMessage]
        │
        ▼
┌─────────────────────────────────────┐
│  ITERACIÓN (iteration < maxIter)   │
│                                     │
│  invokeLLM(messages, tools)         │
│         │                           │
│         ▼                           │
│  ¿response.tool_calls existe?       │
│         │                           │
│    ┌────┴────┐                      │
│    │         │                      │
│   SÍ        NO                      │
│    │         │                      │
│    │         └──> Retornar respuesta│
│    │              final             │
│    │                                │
│    ▼                                │
│  Para cada tool_call:               │
│    │                                │
│    ├─ Parsear argumentos            │
│    ├─ Ejecutar herramienta          │
│    ├─ Capturar resultado            │
│    └─ Agregar a contexto            │
│                                     │
│  iteration++                        │
│  Volver al inicio del loop          │
│                                     │
└─────────────────────────────────────┘
```

Este diseño permite que el agente razone de manera iterativa, ejecutando múltiples herramientas hasta resolver la tarea.

---

## Arquitectura de Herramientas

Cada herramienta del agente sigue un patrón de diseño consistente que facilita su mantenimiento y extensión:

### Estructura de una Herramienta

```typescript
// 1. Definir tipos de entrada y salida
export interface HerramientaInput {
  parametro1: string;
  parametro2?: number;
}

export interface HerramientaOutput {
  resultado: string;
  metadata?: any;
}

// 2. Implementar función de ejecución
export async function ejecutarHerramienta(
  input: HerramientaInput
): Promise<HerramientaOutput> {
  // Validar input
  // Ejecutar lógica
  // Retornar resultado estructurado
}

// 3. Definir schema para el LLM
export const herramientaTool = {
  type: "function" as const,
  function: {
    name: "nombre_herramienta",
    description: "Descripción clara y concisa",
    parameters: {
      type: "object",
      properties: {
        parametro1: {
          type: "string",
          description: "Qué representa este parámetro",
        },
      },
      required: ["parametro1"],
    },
  },
};
```

### Registro de Herramientas

Las herramientas se registran en dos lugares en `agent.ts`:

1. **AVAILABLE_TOOLS:** Array de definiciones de herramientas que se pasan al LLM
2. **TOOL_FUNCTIONS:** Mapa de nombre → función de ejecución

Cuando se agrega una nueva herramienta, debe importarse y registrarse en ambos lugares.

---

## Arquitectura de Base de Datos

El esquema de base de datos está diseñado para soportar conversaciones multi-usuario con historial completo y auditoría de acciones:

### Diagrama de Relaciones

```
┌──────────────┐
│    users     │
│──────────────│
│ id (PK)      │◄───┐
│ openId       │    │
│ email        │    │
│ role         │    │
└──────────────┘    │
                    │
                    │ 1:N
                    │
        ┌───────────┴──────────┐
        │                      │
        ▼                      ▼
┌──────────────┐      ┌──────────────┐
│conversations │      │uploadedFiles │
│──────────────│      │──────────────│
│ id (PK)      │◄──┐  │ id (PK)      │
│ userId (FK)  │   │  │ userId (FK)  │
│ title        │   │  │ s3Url        │
└──────────────┘   │  └──────────────┘
                   │
                   │ 1:N
                   │
                   ▼
           ┌──────────────┐
           │   messages   │
           │──────────────│
           │ id (PK)      │◄──┐
           │ convId (FK)  │   │
           │ role         │   │
           │ content      │   │
           └──────────────┘   │
                              │
                              │ 1:N
                              │
                              ▼
                  ┌──────────────────┐
                  │ toolExecutions   │
                  │──────────────────│
                  │ id (PK)          │
                  │ messageId (FK)   │
                  │ toolName         │
                  │ toolInput        │
                  │ toolOutput       │
                  └──────────────────┘

┌──────────────────────┐
│improvementProposals  │
│──────────────────────│
│ id (PK)              │
│ userId (FK)          │
│ title                │
│ codeChanges (JSON)   │
│ status               │
└──────────────────────┘
```

### Patrones de Acceso

Las consultas más comunes son:

- **Listar conversaciones de un usuario:** `SELECT * FROM conversations WHERE userId = ?`
- **Obtener mensajes de una conversación:** `SELECT * FROM messages WHERE conversationId = ? ORDER BY createdAt`
- **Buscar propuestas pendientes:** `SELECT * FROM improvementProposals WHERE status = 'pending'`

Todas estas consultas están indexadas por las foreign keys correspondientes.

---

## Arquitectura de Autenticación

El sistema de autenticación utiliza OAuth 2.0 con Manus como proveedor:

### Flujo de Autenticación

```
┌─────────┐                 ┌─────────┐                 ┌─────────┐
│ Usuario │                 │Frontend │                 │ Backend │
└────┬────┘                 └────┬────┘                 └────┬────┘
     │                           │                           │
     │ 1. Clic "Iniciar sesión"  │                           │
     ├──────────────────────────>│                           │
     │                           │                           │
     │                           │ 2. Redirigir a OAuth      │
     │                           ├──────────────────────────>│
     │                           │                           │
     │                           │   3. Redirigir a Manus    │
     │<──────────────────────────┴───────────────────────────┤
     │                                                       │
     │ 4. Login en Manus                                     │
     ├──────────────────────────────────────────────────────>│
     │                                                       │
     │ 5. Callback con código                                │
     │<──────────────────────────────────────────────────────┤
     │                           │                           │
     │                           │ 6. Intercambiar código    │
     │                           │    por tokens             │
     │                           ├──────────────────────────>│
     │                           │                           │
     │                           │ 7. Crear sesión JWT       │
     │                           │    Set-Cookie             │
     │                           │<──────────────────────────┤
     │                           │                           │
     │ 8. Redirigir a app        │                           │
     │<──────────────────────────┤                           │
     │                           │                           │
     │ 9. Requests con cookie    │                           │
     ├──────────────────────────>├──────────────────────────>│
     │                           │                           │
     │                           │ 10. Verificar JWT         │
     │                           │     Cargar usuario        │
     │                           │                           │
```

### Seguridad de Sesiones

Las sesiones se almacenan en cookies con las siguientes propiedades de seguridad:

- **httpOnly:** Previene acceso desde JavaScript (protección XSS)
- **secure:** Solo se envía por HTTPS
- **sameSite: none:** Permite requests cross-origin (necesario para OAuth)
- **maxAge:** Expiración configurable (por defecto 7 días)

El JWT contiene el `openId` del usuario y se firma con `JWT_SECRET`. En cada request, el middleware verifica la firma y carga el usuario desde la base de datos.

---

## Arquitectura de Auto-Mejora

El sistema de auto-mejora es una de las características más innovadoras del proyecto. Permite que el agente proponga cambios a su propio código:

### Flujo de Auto-Mejora

```
┌──────────────────────────────────────────────────────────┐
│                FASE 1: IDENTIFICACIÓN                     │
│                                                           │
│  Usuario solicita funcionalidad                           │
│  o agente detecta limitación                              │
└──────────────────────┬───────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────┐
│                FASE 2: INVESTIGACIÓN                      │
│                                                           │
│  propose_self_improvement()                               │
│    │                                                      │
│    ├─ Buscar en GitHub con términos relevantes           │
│    ├─ Analizar código de repositorios similares          │
│    ├─ Identificar patrones de implementación             │
│    └─ Evaluar diferentes enfoques                        │
└──────────────────────┬───────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────┐
│             FASE 3: GENERACIÓN DE PROPUESTA               │
│                                                           │
│  Crear propuesta estructurada:                            │
│    - Título descriptivo                                   │
│    - Descripción detallada                                │
│    - Justificación técnica                                │
│    - Cambios de código (diff)                             │
│    - Nivel de impacto                                     │
└──────────────────────┬───────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────┐
│              FASE 4: ALMACENAMIENTO                       │
│                                                           │
│  INSERT INTO improvementProposals                         │
│  SET status = 'pending'                                   │
│                                                           │
│  notifyOwner("Nueva propuesta de mejora")                │
└──────────────────────┬───────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────┐
│             FASE 5: REVISIÓN DEL USUARIO                  │
│                                                           │
│  Usuario accede a /improvements                           │
│    │                                                      │
│    ├─ Ver lista de propuestas                            │
│    ├─ Revisar detalles y diff                            │
│    └─ Aprobar o Rechazar                                 │
└──────────────────────┬───────────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────────┐
│              FASE 6: APLICACIÓN                           │
│                                                           │
│  applyImprovement()                                       │
│    │                                                      │
│    ├─ Crear backup de archivos                           │
│    ├─ Aplicar cambios de código                          │
│    ├─ Validar sintaxis (pnpm check)                      │
│    ├─ ¿Validación exitosa?                               │
│    │   ├─ SÍ: Marcar como "applied"                      │
│    │   └─ NO: Rollback automático                        │
│    │                                                      │
│    └─ notifyOwner(resultado)                             │
└──────────────────────────────────────────────────────────┘
```

### Capas de Seguridad

El sistema implementa múltiples capas de seguridad para prevenir cambios peligrosos:

1. **Aprobación humana obligatoria:** Ningún cambio se aplica sin revisión
2. **Backup automático:** Todos los archivos se respaldan antes de modificar
3. **Validación de sintaxis:** TypeScript verifica que el código compile
4. **Rollback automático:** Si falla la validación, se restauran los archivos
5. **Auditoría completa:** Cada acción se registra con timestamp y usuario

---

## Patrones de Diseño Utilizados

El proyecto implementa varios patrones de diseño establecidos:

### Patrón Repository

Los helpers de base de datos en `server/db.ts` implementan el patrón Repository, encapsulando la lógica de acceso a datos:

```typescript
// Repository para usuarios
export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  return await db.select().from(users).where(eq(users.openId, openId));
}

// Repository para conversaciones
export async function getConversationsByUserId(userId: number) {
  const db = await getDb();
  return await db.select().from(conversations).where(eq(conversations.userId, userId));
}
```

Este patrón facilita el testing y permite cambiar la implementación de persistencia sin afectar el resto del código.

### Patrón Strategy

Las herramientas del agente implementan el patrón Strategy, permitiendo intercambiar algoritmos dinámicamente:

```typescript
const TOOL_FUNCTIONS: Record<string, (input: any) => Promise<any>> = {
  search_web: searchWeb,
  execute_code: executeCode,
  // ...
};

// Selección dinámica de estrategia
const toolFunction = TOOL_FUNCTIONS[toolName];
const result = await toolFunction(input);
```

Esto permite agregar nuevas herramientas sin modificar el motor del agente.

### Patrón Middleware

tRPC utiliza el patrón Middleware para autenticación y autorización:

```typescript
const protectedProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});
```

Los middlewares se encadenan y cada uno puede modificar el contexto o interrumpir la ejecución.

### Patrón Observer

React Query (usado por tRPC) implementa el patrón Observer para sincronización de estado:

```typescript
const { data, isLoading } = trpc.chat.getMessages.useQuery({ conversationId });
```

Los componentes se suscriben a queries y se re-renderizan automáticamente cuando los datos cambian.

---

## Escalabilidad y Rendimiento

### Consideraciones de Escalabilidad

El sistema está diseñado para escalar horizontalmente:

**Stateless Backend:** El servidor no mantiene estado de sesión en memoria. Todas las sesiones se almacenan en cookies JWT, permitiendo balanceo de carga entre múltiples instancias.

**Base de Datos Compartida:** Múltiples instancias del backend pueden compartir la misma base de datos MySQL/TiDB sin conflictos.

**Almacenamiento Externo:** Los archivos se almacenan en S3, no en el sistema de archivos local, permitiendo que cualquier instancia acceda a ellos.

### Optimizaciones de Rendimiento

El sistema implementa varias optimizaciones:

- **Lazy Loading:** Los componentes de React se cargan bajo demanda
- **Query Caching:** React Query cachea respuestas de API automáticamente
- **Índices de Base de Datos:** Todas las foreign keys están indexadas
- **Streaming de Respuestas:** El agente puede streamear pasos en tiempo real (función `executeAgentStreaming`)

---

## Seguridad en Profundidad

### Modelo de Amenazas

El sistema considera las siguientes amenazas:

**Inyección SQL:** Mitigado mediante Drizzle ORM que usa prepared statements.

**XSS (Cross-Site Scripting):** Mitigado mediante cookies httpOnly y sanitización de inputs en React.

**CSRF (Cross-Site Request Forgery):** Mitigado mediante sameSite cookie policy y verificación de origin.

**Ejecución de Código Malicioso:** Mitigado mediante sandbox aislado para ejecución de código del usuario.

**Modificaciones No Autorizadas:** Mitigado mediante sistema de aprobación de mejoras y rollback automático.

### Mejores Prácticas Implementadas

- Validación de inputs con Zod schemas
- Autenticación en todas las rutas protegidas
- Logging de acciones sensibles
- Backups automáticos antes de cambios críticos
- Rate limiting (pendiente de implementar en producción)

---

## Conclusión

La arquitectura del Asistente IA Autónomo está diseñada para ser modular, extensible y segura. La separación clara de responsabilidades entre capas, el uso de patrones de diseño establecidos y las múltiples capas de seguridad garantizan que el sistema sea mantenible y escalable a largo plazo.

Para continuar el desarrollo, consulta el Manual de Desarrollo que proporciona instrucciones paso a paso para tareas comunes.

---

**Documento generado por Manus AI - Febrero 2026**
