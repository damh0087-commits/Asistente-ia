# Manual de Desarrollo - Asistente IA Autónomo

**Autor:** Manus AI  
**Fecha:** Febrero 2026  
**Versión:** 2.0

---

## Introducción

Este manual proporciona instrucciones paso a paso para desarrolladores que deseen extender, modificar o mantener el Asistente IA Autónomo. Cubre tareas comunes de desarrollo, desde configurar el entorno hasta implementar nuevas funcionalidades.

---

## Configuración del Entorno de Desarrollo

### Requisitos Previos

Antes de comenzar, asegúrate de tener instalado:

- **Node.js:** Versión 22.13.0 o superior
- **pnpm:** Gestor de paquetes (incluido con Node.js)
- **Git:** Para control de versiones
- **Editor de código:** VS Code recomendado con extensiones de TypeScript

### Clonar el Proyecto

Si el proyecto está en un repositorio Git, clónalo con:

```bash
git clone <URL_DEL_REPOSITORIO>
cd manus-clone
```

Si estás trabajando desde un checkpoint de Manus, descarga el código desde la interfaz de gestión.

### Instalar Dependencias

Ejecuta el siguiente comando en la raíz del proyecto:

```bash
pnpm install
```

Este comando instalará todas las dependencias listadas en `package.json`, incluyendo React, Express, tRPC, Drizzle y todas las bibliotecas UI.

### Configurar Variables de Entorno

El proyecto requiere varias variables de entorno. En desarrollo local con Manus, estas se inyectan automáticamente. Si trabajas fuera de Manus, crea un archivo `.env` en la raíz con:

```env
DATABASE_URL=mysql://usuario:password@host:puerto/database
JWT_SECRET=tu-secreto-jwt-seguro
VITE_APP_ID=id-de-aplicacion-oauth
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_OPEN_ID=openid-del-propietario
OWNER_NAME=Nombre del Propietario
BUILT_IN_FORGE_API_URL=https://forge.manus.im
BUILT_IN_FORGE_API_KEY=tu-api-key-de-manus
VITE_FRONTEND_FORGE_API_KEY=tu-frontend-api-key
RUNWAY_API_KEY=tu-api-key-de-runway-ml (opcional)
```

### Iniciar el Servidor de Desarrollo

Una vez configurado todo, inicia el servidor con:

```bash
pnpm dev
```

Este comando inicia tanto el backend (Express + tRPC) como el frontend (Vite + React) con hot-reload automático. El servidor estará disponible en `http://localhost:3000`.

---

## Estructura del Proyecto

Comprender la estructura del proyecto es fundamental para navegar el código eficientemente:

```
manus-clone/
├── client/                    # Frontend React
│   ├── public/                # Assets estáticos
│   └── src/
│       ├── components/        # Componentes reutilizables
│       │   ├── ui/            # Componentes shadcn/ui
│       │   ├── FileUpload.tsx
│       │   └── ...
│       ├── contexts/          # Contextos de React
│       ├── hooks/             # Hooks personalizados
│       ├── lib/               # Utilidades y configuración
│       │   └── trpc.ts        # Cliente tRPC
│       ├── pages/             # Páginas de la aplicación
│       │   ├── Chat.tsx
│       │   ├── Improvements.tsx
│       │   └── ...
│       ├── App.tsx            # Componente raíz y rutas
│       ├── main.tsx           # Punto de entrada
│       └── index.css          # Estilos globales
│
├── server/                    # Backend Express + tRPC
│   ├── _core/                 # Infraestructura del framework
│   │   ├── context.ts         # Contexto de tRPC
│   │   ├── trpc.ts            # Configuración de tRPC
│   │   ├── oauth.ts           # Autenticación OAuth
│   │   ├── llm.ts             # Cliente LLM
│   │   └── ...
│   ├── tools/                 # Herramientas del agente
│   │   ├── search.ts
│   │   ├── browser.ts
│   │   ├── codeExecutor.ts
│   │   └── ...
│   ├── agent.ts               # Motor del agente autónomo
│   ├── routers.ts             # Definición de API tRPC
│   ├── db.ts                  # Helpers de base de datos
│   ├── storage.ts             # Helpers de S3
│   └── *.test.ts              # Tests unitarios
│
├── drizzle/                   # Esquema y migraciones de BD
│   └── schema.ts
│
├── shared/                    # Código compartido
│   └── const.ts               # Constantes
│
├── package.json               # Dependencias y scripts
├── tsconfig.json              # Configuración de TypeScript
├── vite.config.ts             # Configuración de Vite
└── README.md                  # Documentación del proyecto
```

### Archivos Clave

Los archivos más importantes que modificarás frecuentemente son:

- `server/agent.ts`: Motor del agente y loop de razonamiento
- `server/routers.ts`: Definición de procedimientos tRPC
- `server/tools/*.ts`: Implementación de herramientas del agente
- `drizzle/schema.ts`: Esquema de base de datos
- `client/src/pages/*.tsx`: Páginas de la interfaz de usuario
- `client/src/components/*.tsx`: Componentes reutilizables

---

## Tareas Comunes de Desarrollo

### Agregar una Nueva Herramienta al Agente

Para agregar una nueva herramienta que el agente pueda usar:

**Paso 1:** Crear archivo de herramienta en `server/tools/miNuevaHerramienta.ts`:

```typescript
export interface MiHerramientaInput {
  parametro: string;
}

export interface MiHerramientaOutput {
  resultado: string;
  exito: boolean;
}

export async function ejecutarMiHerramienta(
  input: MiHerramientaInput
): Promise<MiHerramientaOutput> {
  try {
    // Implementar lógica de la herramienta
    const resultado = `Procesado: ${input.parametro}`;
    
    return {
      resultado,
      exito: true,
    };
  } catch (error) {
    return {
      resultado: `Error: ${error.message}`,
      exito: false,
    };
  }
}

export const miHerramientaTool = {
  type: "function" as const,
  function: {
    name: "mi_nueva_herramienta",
    description: "Descripción clara de qué hace esta herramienta y cuándo usarla",
    parameters: {
      type: "object",
      properties: {
        parametro: {
          type: "string",
          description: "Descripción del parámetro",
        },
      },
      required: ["parametro"],
    },
  },
};
```

**Paso 2:** Registrar la herramienta en `server/agent.ts`:

```typescript
// Importar al inicio del archivo
import {
  ejecutarMiHerramienta,
  miHerramientaTool,
} from "./tools/miNuevaHerramienta";

// Agregar a AVAILABLE_TOOLS
const AVAILABLE_TOOLS = [
  // ... herramientas existentes
  miHerramientaTool,
];

// Agregar a TOOL_FUNCTIONS
const TOOL_FUNCTIONS: Record<string, (input: any) => Promise<any>> = {
  // ... funciones existentes
  mi_nueva_herramienta: ejecutarMiHerramienta,
};
```

**Paso 3:** Reiniciar el servidor:

```bash
# El servidor se reiniciará automáticamente si usas pnpm dev
# Si no, detén y vuelve a iniciar manualmente
```

**Paso 4:** Probar la herramienta:

Envía un mensaje al agente solicitando que use la nueva herramienta. Por ejemplo: "Usa mi nueva herramienta con el parámetro 'test'".

### Agregar un Nuevo Procedimiento tRPC

Para agregar un nuevo endpoint API:

**Paso 1:** Abrir `server/routers.ts` y localizar el router apropiado o crear uno nuevo:

```typescript
export const appRouter = router({
  // ... routers existentes
  
  miRouter: router({
    miProcedimiento: protectedProcedure
      .input(z.object({
        parametro: z.string(),
      }))
      .query(async ({ ctx, input }) => {
        // Implementar lógica
        return {
          resultado: `Procesado: ${input.parametro}`,
        };
      }),
  }),
});
```

**Paso 2:** Usar el procedimiento en el frontend:

```typescript
// En un componente React
const { data, isLoading } = trpc.miRouter.miProcedimiento.useQuery({
  parametro: "valor",
});
```

### Agregar una Nueva Tabla a la Base de Datos

Para agregar una nueva tabla:

**Paso 1:** Editar `drizzle/schema.ts`:

```typescript
export const miNuevaTabla = mysqlTable("mi_nueva_tabla", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contenido: text("contenido"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MiNuevaTabla = typeof miNuevaTabla.$inferSelect;
export type InsertMiNuevaTabla = typeof miNuevaTabla.$inferInsert;
```

**Paso 2:** Aplicar migración:

```bash
pnpm db:push
```

Este comando genera la migración y la aplica automáticamente a la base de datos.

**Paso 3:** Agregar helpers en `server/db.ts` (opcional):

```typescript
export async function insertarEnMiNuevaTabla(data: InsertMiNuevaTabla) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(miNuevaTabla).values(data);
}
```

### Agregar una Nueva Página

Para agregar una nueva página a la interfaz:

**Paso 1:** Crear componente de página en `client/src/pages/MiPagina.tsx`:

```typescript
import { useAuth } from "@/_core/hooks/useAuth";

export default function MiPagina() {
  const { user, isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <div>Debes iniciar sesión</div>;
  }
  
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold">Mi Nueva Página</h1>
      <p>Bienvenido, {user.name}</p>
    </div>
  );
}
```

**Paso 2:** Agregar ruta en `client/src/App.tsx`:

```typescript
import MiPagina from "./pages/MiPagina";

function Router() {
  return (
    <Switch>
      {/* ... rutas existentes */}
      <Route path={"/mi-pagina"} component={MiPagina} />
    </Switch>
  );
}
```

**Paso 3:** Agregar enlace de navegación (opcional):

```typescript
<Link href="/mi-pagina">
  <Button>Ir a Mi Página</Button>
</Link>
```

### Modificar el Esquema de una Tabla Existente

Para agregar o modificar columnas:

**Paso 1:** Editar la definición de tabla en `drizzle/schema.ts`:

```typescript
export const users = mysqlTable("users", {
  // ... columnas existentes
  nuevaColumna: varchar("nuevaColumna", { length: 255 }),
});
```

**Paso 2:** Aplicar migración:

```bash
pnpm db:push
```

**Nota:** Si la columna es NOT NULL, debes proporcionar un valor por defecto o migrar datos existentes manualmente.

### Agregar un Componente UI Reutilizable

Para crear un componente reutilizable:

**Paso 1:** Crear archivo en `client/src/components/MiComponente.tsx`:

```typescript
import { Button } from "@/components/ui/button";

interface MiComponenteProps {
  titulo: string;
  onAccion: () => void;
}

export function MiComponente({ titulo, onAccion }: MiComponenteProps) {
  return (
    <div className="p-4 border rounded-lg">
      <h2 className="text-lg font-semibold">{titulo}</h2>
      <Button onClick={onAccion}>Acción</Button>
    </div>
  );
}
```

**Paso 2:** Usar el componente en páginas:

```typescript
import { MiComponente } from "@/components/MiComponente";

export default function MiPagina() {
  const handleAccion = () => {
    console.log("Acción ejecutada");
  };
  
  return (
    <MiComponente titulo="Título" onAccion={handleAccion} />
  );
}
```

---

## Testing

### Ejecutar Tests

El proyecto usa Vitest para testing. Para ejecutar todos los tests:

```bash
pnpm test
```

### Escribir un Nuevo Test

Para agregar un test para un procedimiento tRPC:

**Paso 1:** Crear archivo de test `server/miRouter.test.ts`:

```typescript
import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createMockContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as any,
    res: {} as any,
  };
}

describe("miRouter", () => {
  it("debe retornar resultado correcto", async () => {
    const ctx = createMockContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.miRouter.miProcedimiento({
      parametro: "test",
    });
    
    expect(result.resultado).toBe("Procesado: test");
  });
});
```

**Paso 2:** Ejecutar el test:

```bash
pnpm test
```

---

## Debugging

### Debugging del Backend

Para debuggear el backend con VS Code:

**Paso 1:** Crear configuración de launch en `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "launch",
      "name": "Debug Backend",
      "runtimeExecutable": "pnpm",
      "runtimeArgs": ["dev"],
      "skipFiles": ["<node_internals>/**"],
      "console": "integratedTerminal"
    }
  ]
}
```

**Paso 2:** Establecer breakpoints en el código y presionar F5 para iniciar debugging.

### Debugging del Agente

Si el agente no responde correctamente:

**Paso 1:** Revisar logs de consola:

```bash
tail -f .manus-logs/browserConsole.log
```

**Paso 2:** Verificar respuestas del LLM en logs del servidor:

```bash
tail -f .manus-logs/devserver.log | grep "LLM"
```

**Paso 3:** Agregar logging adicional en `server/agent.ts`:

```typescript
console.log("Contexto del agente:", JSON.stringify(messages, null, 2));
console.log("Respuesta del LLM:", JSON.stringify(response, null, 2));
```

**Paso 4:** Simplificar la solicitud del usuario para aislar el problema.

### Debugging de Herramientas

Si una herramienta falla:

**Paso 1:** Agregar try-catch y logging en la función de la herramienta:

```typescript
export async function miHerramienta(input: Input): Promise<Output> {
  try {
    console.log("Input de herramienta:", input);
    const result = await ejecutarLogica(input);
    console.log("Output de herramienta:", result);
    return result;
  } catch (error) {
    console.error("Error en herramienta:", error);
    throw error;
  }
}
```

**Paso 2:** Revisar logs y verificar que el input sea el esperado.

---

## Despliegue

### Preparar para Producción

Antes de desplegar:

**Paso 1:** Ejecutar verificación de tipos:

```bash
pnpm check
```

**Paso 2:** Ejecutar todos los tests:

```bash
pnpm test
```

**Paso 3:** Compilar el proyecto:

```bash
pnpm build
```

Este comando genera los archivos optimizados para producción en `dist/`.

### Desplegar en Manus

Para desplegar en la plataforma Manus:

**Paso 1:** Crear un checkpoint:

```bash
# Desde la interfaz de Manus o mediante código
webdev_save_checkpoint({
  description: "Versión lista para producción",
});
```

**Paso 2:** Hacer clic en el botón "Publish" en la interfaz de Manus.

**Paso 3:** Configurar dominio personalizado si es necesario en Settings → Domains.

### Desplegar en Otro Hosting

Si deseas desplegar fuera de Manus:

**Paso 1:** Configurar variables de entorno en el servidor de producción.

**Paso 2:** Subir el código al servidor:

```bash
git push origin main
```

**Paso 3:** En el servidor, instalar dependencias y compilar:

```bash
pnpm install
pnpm build
```

**Paso 4:** Iniciar el servidor:

```bash
pnpm start
```

**Paso 5:** Configurar un proceso manager como PM2:

```bash
npm install -g pm2
pm2 start dist/index.js --name manus-clone
pm2 save
pm2 startup
```

---

## Mejores Prácticas

### Código

- **Usar TypeScript estricto:** No usar `any` sin justificación
- **Validar inputs:** Usar Zod schemas para validar todos los inputs de API
- **Manejar errores:** Siempre usar try-catch en operaciones asíncronas
- **Documentar funciones complejas:** Agregar JSDoc comments
- **Mantener funciones pequeñas:** Máximo 50 líneas por función

### Base de Datos

- **Usar transacciones:** Para operaciones que modifican múltiples tablas
- **Indexar foreign keys:** Todas las foreign keys deben tener índices
- **Evitar N+1 queries:** Usar joins en lugar de queries en loops
- **Validar antes de insertar:** Verificar constraints antes de escribir

### Frontend

- **Componentes pequeños:** Máximo 200 líneas por componente
- **Usar hooks personalizados:** Extraer lógica reutilizable a hooks
- **Optimizar re-renders:** Usar `useMemo` y `useCallback` cuando sea necesario
- **Accesibilidad:** Usar atributos ARIA y navegación por teclado

### Seguridad

- **Nunca exponer secretos:** No commitear API keys o passwords
- **Validar en backend:** Nunca confiar en validación del frontend
- **Sanitizar inputs:** Prevenir inyección SQL y XSS
- **Usar HTTPS:** En producción, siempre usar conexiones seguras

---

## Solución de Problemas Comunes

### El servidor no inicia

**Problema:** Error al ejecutar `pnpm dev`

**Solución:**
1. Verificar que todas las dependencias estén instaladas: `pnpm install`
2. Verificar que las variables de entorno estén configuradas
3. Verificar que el puerto 3000 no esté en uso: `lsof -i :3000`

### Errores de TypeScript

**Problema:** Errores de tipo al compilar

**Solución:**
1. Ejecutar `pnpm check` para ver todos los errores
2. Verificar que los tipos importados sean correctos
3. Regenerar tipos de tRPC si es necesario

### El agente no responde

**Problema:** El agente se queda "pensando" indefinidamente

**Solución:**
1. Revisar logs de consola: `.manus-logs/browserConsole.log`
2. Verificar que el LLM esté respondiendo correctamente
3. Aumentar el límite de iteraciones en `agent.ts`
4. Simplificar la solicitud del usuario

### Errores de base de datos

**Problema:** Error al conectar a la base de datos

**Solución:**
1. Verificar que `DATABASE_URL` esté configurado correctamente
2. Verificar que la base de datos esté accesible
3. Ejecutar `pnpm db:push` para aplicar migraciones pendientes

---

## Recursos Adicionales

### Documentación de Tecnologías

- **React:** https://react.dev/
- **TypeScript:** https://www.typescriptlang.org/docs/
- **tRPC:** https://trpc.io/docs/
- **Drizzle ORM:** https://orm.drizzle.team/docs/overview
- **Tailwind CSS:** https://tailwindcss.com/docs
- **shadcn/ui:** https://ui.shadcn.com/

### Comunidad y Soporte

Para preguntas o problemas, consulta:

- Documentación técnica del proyecto
- Guía de arquitectura
- Issues en el repositorio Git (si aplica)
- Soporte de Manus: https://help.manus.im

---

## Conclusión

Este manual cubre las tareas más comunes de desarrollo. Para información más detallada sobre la arquitectura del sistema, consulta la Guía de Arquitectura. Para transferir el proyecto a otra IA, consulta el Archivo de Contexto para IAs.

---

**Documento generado por Manus AI - Febrero 2026**
