# Guía de Inicio Rápido

## Para Desarrolladores Humanos

### 1. Instalación

```bash
# Instalar dependencias
pnpm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales
```

### 2. Desarrollo

```bash
# Iniciar servidor de desarrollo
pnpm dev

# Abrir navegador en http://localhost:3000
```

### 3. Base de Datos

```bash
# Aplicar migraciones
pnpm db:push
```

### 4. Testing

```bash
# Ejecutar tests
pnpm test
```

### 5. Producción

```bash
# Compilar para producción
pnpm build

# Iniciar servidor de producción
pnpm start
```

## Para IAs

### 1. Leer Documentación

Comienza leyendo en este orden:
1. `AI_CONTEXT.md` - Contexto estructurado
2. `TECHNICAL_DOCUMENTATION.md` - Documentación completa
3. `ARCHITECTURE_GUIDE.md` - Arquitectura del sistema
4. `DEVELOPMENT_MANUAL.md` - Instrucciones paso a paso

### 2. Explorar Código

Archivos clave para entender el sistema:
- `server/agent.ts` - Motor del agente autónomo
- `server/routers.ts` - API tRPC completa
- `server/tools/*.ts` - Herramientas del agente
- `drizzle/schema.ts` - Esquema de base de datos
- `client/src/pages/Chat.tsx` - Interfaz principal

### 3. Consultar Tareas

`todo.md` contiene el estado de todas las funcionalidades:
- `[x]` = Completado
- `[ ]` = Pendiente

### 4. Continuar Desarrollo

Sigue las mejores prácticas en `DEVELOPMENT_MANUAL.md`:
- Validar inputs con Zod
- Manejar errores con try-catch
- Escribir tests para nuevas funcionalidades
- Documentar funciones complejas
- Crear checkpoints antes de cambios grandes

## Estructura del Proyecto

```
manus-clone/
├── client/          # Frontend React
├── server/          # Backend Express + tRPC
├── drizzle/         # Esquema de base de datos
├── shared/          # Código compartido
├── docs/            # Documentación
└── package.json     # Dependencias
```

## Comandos Útiles

```bash
pnpm dev             # Desarrollo
pnpm build           # Compilar
pnpm start           # Producción
pnpm test            # Tests
pnpm check           # Verificar tipos
pnpm db:push         # Migrar base de datos
```

## Soporte

- Documentación completa: Ver archivos .md en la raíz
- Problemas conocidos: Ver AI_CONTEXT.md sección "Problemas Conocidos"
- Contacto: damh0087@gmail.com
- Soporte Manus: https://help.manus.im
