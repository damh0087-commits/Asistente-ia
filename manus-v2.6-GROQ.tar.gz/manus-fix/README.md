# Asistente IA Autónomo - 100% GRATUITO

Un agente de inteligencia artificial autónomo capaz de razonar, planificar y ejecutar tareas complejas de manera independiente, utilizando **SOLO modelos de lenguaje y herramientas 100% GRATUITAS**.

## 🎯 Características Principales

### ✅ 100% GRATUITO
- **Modelos LLM locales** con Ollama (DeepSeek-R1, Qwen3, Llama)
- **Sin API keys necesarias** para funcionalidad básica
- **Todas las herramientas son gratuitas** (DuckDuckGo, Playwright, Python, etc.)
- **Fallback opcional** a Manus Forge si Ollama no está disponible

### 🤖 Agente Autónomo Inteligente

El sistema implementa un **agente autónomo** que puede descomponer tareas complejas en pasos más simples, seleccionar y ejecutar herramientas apropiadas, y proporcionar respuestas completas basadas en razonamiento paso a paso. El agente opera mediante un loop de razonamiento continuo que analiza el contexto, planifica acciones, ejecuta herramientas y observa resultados hasta completar la tarea solicitada.

**Mejoras implementadas**:
- ✅ **20 iteraciones** (aumentado de 10) para tareas más complejas
- ✅ **Sistema de caché** para evitar ejecuciones repetidas
- ✅ **Validación de parámetros** con Zod para mensajes de error claros
- ✅ **Reintentos automáticos** con backoff exponencial
- ✅ **Manejo de errores mejorado** con sugerencias para el LLM

### 🛠️ Capacidades del Agente (100% GRATIS)

**Búsqueda y Navegación Web**. El agente puede buscar información actualizada en Internet usando DuckDuckGo (con scraping HTML mejorado para más resultados), navegar a URLs específicas para extraer contenido de páginas web, y realizar scraping de datos estructurados mediante selectores CSS. Esta capacidad le permite acceder a información en tiempo real sin necesidad de API keys.

**Ejecución de Código**. El sistema incluye un sandbox seguro para ejecutar código Python y JavaScript, lo que permite al agente realizar cálculos complejos, procesar datos, generar visualizaciones y crear scripts personalizados. El código se ejecuta en un entorno aislado con límites de tiempo para garantizar la seguridad.

**Análisis de Datos**. Utilizando Pandas y Matplotlib, el agente puede analizar conjuntos de datos en formatos CSV o JSON, generar estadísticas descriptivas, crear visualizaciones gráficas, filtrar y agregar datos, y calcular correlaciones. Esta funcionalidad es especialmente útil para tareas de análisis exploratorio y generación de insights.

**Sistema de Archivos**. El agente mantiene un workspace persistente donde puede leer y escribir archivos, lo que le permite guardar resultados intermedios, generar documentos, código o reportes, y mantener estado entre diferentes interacciones.

### 🚀 Integración con Modelos LLM Gratuitos

El sistema está diseñado para funcionar **PRIMERO** con **Ollama**, una plataforma que permite ejecutar modelos de lenguaje de código abierto localmente **SIN COSTO**. Los modelos recomendados incluyen:

- **DeepSeek-R1** (8B/32B): Modelo especializado en razonamiento con excelente rendimiento en matemáticas y lógica (AIME 2025: 87.5%)
- **Qwen3** (8B/14B): Modelo multilingüe con contexto extendido de más de 1 millón de tokens
- **Llama-3.3-70B**: Modelo potente con excelente capacidad de seguimiento de instrucciones
- **Gemma-2** (9B/27B): Modelos eficientes de Google

**Modo de Operación**:
1. **Primario**: El sistema detecta automáticamente si Ollama está disponible y lo usa (100% GRATIS)
2. **Fallback**: Si Ollama no está disponible, puede usar Manus Forge como respaldo (requiere API key)

Puedes forzar el uso de Ollama o verificar el estado actual a través de las funciones exportadas en `server/_core/llm.ts`.

### Interfaz de Usuario Elegante

La aplicación presenta una interfaz de chat moderna con tema púrpura elegante, visualización en tiempo real de las herramientas que el agente está ejecutando, indicadores de progreso para cada paso del razonamiento, y renderizado de markdown para respuestas formateadas. El diseño utiliza glassmorphism y animaciones suaves para una experiencia visual refinada.

## Arquitectura del Sistema

El sistema sigue una arquitectura de tres capas claramente definidas:

### Capa de Presentación (Frontend)

Construida con **React 19** y **TailwindCSS 4**, la interfaz proporciona una experiencia de usuario fluida y responsiva. Los componentes utilizan **tRPC** para comunicación type-safe con el backend, eliminando la necesidad de definir contratos API manualmente. El estado de autenticación se gestiona mediante hooks personalizados que integran OAuth de Manus.

### Capa de Lógica (Backend)

El servidor está construido con **Express 4** y **tRPC 11**, proporcionando endpoints type-safe para todas las operaciones. El motor del agente implementa el loop de razonamiento autónomo, coordinando la ejecución de herramientas y la comunicación con el modelo de lenguaje. Todas las interacciones se registran en la base de datos para mantener historial y contexto.

### Capa de Datos

**MySQL/TiDB** almacena toda la información persistente del sistema, incluyendo usuarios y sesiones, conversaciones y mensajes, historial de ejecución de herramientas, y metadatos de archivos generados. El esquema está diseñado con relaciones en cascada para mantener integridad referencial.

## Configuración e Instalación

### Requisitos Previos

El sistema requiere las siguientes dependencias instaladas en el entorno:

- **Node.js 22+** para ejecutar el servidor y el frontend
- **Python 3.11+** para ejecución de código y análisis de datos
- **Ollama** para ejecutar modelos LLM localmente
- **MySQL/TiDB** como base de datos (configurado automáticamente en Manus)

### Instalación de Ollama

Para instalar Ollama en un servidor Linux, ejecute los siguientes comandos:

```bash
# Instalar Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Descargar modelo recomendado
ollama pull deepseek-r1:8b

# O alternativamente
ollama pull qwen3:8b
```

Para verificar que Ollama está funcionando correctamente:

```bash
# Verificar servicio
curl http://localhost:11434/api/tags

# Probar modelo
ollama run deepseek-r1:8b "Hola, ¿cómo estás?"
```

### Instalación de Dependencias del Proyecto

Una vez clonado el repositorio, instale las dependencias necesarias:

```bash
# Instalar dependencias de Node.js
pnpm install

# Instalar navegador para Playwright
npx playwright install chromium

# Instalar bibliotecas de Python para análisis de datos
sudo pip3 install pandas matplotlib plotly numpy
```

### Configuración de Variables de Entorno

El sistema utiliza variables de entorno para configuración. Las variables críticas incluyen:

```bash
# URL de Ollama (por defecto: http://localhost:11434)
OLLAMA_URL=http://localhost:11434

# Modelo a usar (por defecto: deepseek-r1:8b)
OLLAMA_MODEL=deepseek-r1:8b

# Las siguientes variables son inyectadas automáticamente por Manus:
# DATABASE_URL, JWT_SECRET, VITE_APP_ID, etc.
```

### Migración de Base de Datos

Antes de ejecutar la aplicación por primera vez, aplique las migraciones de base de datos:

```bash
pnpm db:push
```

Este comando genera las migraciones necesarias y las aplica a la base de datos, creando todas las tablas requeridas.

### Ejecución en Desarrollo

Para iniciar el servidor de desarrollo:

```bash
pnpm dev
```

El servidor estará disponible en `http://localhost:3000` con hot-reload habilitado para desarrollo rápido.

### Ejecución en Producción

Para construir y ejecutar en producción:

```bash
# Construir aplicación
pnpm build

# Iniciar servidor de producción
pnpm start
```

## Uso del Sistema

### Interacción Básica

Los usuarios interactúan con el agente a través de la interfaz de chat. Simplemente escriba una solicitud en lenguaje natural y el agente determinará automáticamente qué herramientas necesita usar para completar la tarea.

**Ejemplos de solicitudes:**

- "Busca información sobre los últimos avances en IA generativa"
- "Analiza estos datos de ventas y crea un gráfico de barras"
- "Escribe un script en Python que calcule la secuencia de Fibonacci"
- "Navega a example.com y extrae todos los títulos de artículos"

### Visualización del Proceso

Durante la ejecución, el agente muestra en tiempo real cada paso que está realizando, incluyendo qué herramienta está usando, qué parámetros está pasando, y qué resultados está obteniendo. Esta transparencia permite a los usuarios entender el razonamiento del agente y verificar su proceso.

### Gestión de Conversaciones

Cada sesión de chat se guarda como una conversación persistente. El agente mantiene contexto entre mensajes, permitiendo referencias a interacciones anteriores y construcción incremental de soluciones complejas.

## Herramientas Disponibles (100% GRATIS)

### search_web

Busca información en la web usando DuckDuckGo con scraping HTML mejorado. **NO requiere API key** y proporciona resultados reales actualizados.

**Parámetros:**
- `query` (string): Consulta de búsqueda
- `maxResults` (number, opcional): Número máximo de resultados (por defecto: 5, máximo: 20)

**Mejoras**:
- ✅ Scraping HTML de DuckDuckGo para más resultados
- ✅ Fallback automático a API
- ✅ Resultados cacheados por 1 hora

**Ejemplo de uso:**
```json
{
  "query": "últimas noticias sobre inteligencia artificial",
  "maxResults": 10
}
```

### navigate_to_url

Navega a una URL y extrae el contenido de texto de la página. **100% gratuito** usando Playwright.

**Parámetros:**
- `url` (string): URL a visitar
- `waitForSelector` (string, opcional): Selector CSS para esperar antes de extraer

**Ejemplo de uso:**
```json
{
  "url": "https://example.com/article",
  "waitForSelector": ".article-content"
}
```

### extract_data

Extrae datos específicos de una página web usando selectores CSS.

**Parámetros:**
- `url` (string): URL de la página
- `selector` (string): Selector CSS para encontrar elementos

**Ejemplo de uso:**
```json
{
  "url": "https://example.com/products",
  "selector": ".product-title"
}
```

### execute_code

Ejecuta código Python o JavaScript en un entorno seguro.

**Parámetros:**
- `code` (string): Código a ejecutar
- `language` (string): "python" o "javascript"
- `timeout` (number, opcional): Timeout en milisegundos (por defecto: 30000)

**Ejemplo de uso:**
```json
{
  "code": "import math\\nprint(math.factorial(10))",
  "language": "python"
}
```

### analyze_data

Analiza datos usando Pandas con varias operaciones disponibles.

**Parámetros:**
- `data` (string): Datos en formato CSV o JSON
- `operation` (string): "describe", "plot", "filter", "aggregate", "correlate", o "custom"
- `parameters` (object, opcional): Parámetros adicionales según la operación

**Ejemplo de uso:**
```json
{
  "data": "name,age,salary\\nAlice,30,50000\\nBob,35,60000",
  "operation": "describe"
}
```

### write_file / read_file / list_files

Gestiona archivos en el workspace del agente.

**write_file parámetros:**
- `path` (string): Ruta relativa del archivo
- `content` (string): Contenido a escribir

**read_file parámetros:**
- `path` (string): Ruta relativa del archivo

**list_files parámetros:**
- `path` (string, opcional): Directorio a listar

### generate_image

Genera imágenes a partir de descripciones en texto usando el servicio integrado de Manus. También puede editar imágenes existentes.

**Parámetros:**
- `prompt` (string): Descripción detallada de la imagen a generar
- `originalImages` (array, opcional): Imágenes originales para editar

**Ejemplo de uso:**
```json
{
  "prompt": "Un paisaje sereno con montañas al atardecer, estilo acuarela"
}
```

### transcribe_audio

Transcribe audio a texto usando Whisper API. Soporta múltiples idiomas y formatos (webm, mp3, wav, ogg, m4a).

**Parámetros:**
- `audioUrl` (string): URL del archivo de audio a transcribir
- `language` (string, opcional): Código de idioma ISO-639-1 (ej: 'es', 'en')
- `prompt` (string, opcional): Contexto para mejorar la transcripción

**Ejemplo de uso:**
```json
{
  "audioUrl": "https://example.com/audio.mp3",
  "language": "es"
}
```

### scrape_web

Extrae contenido estructurado de páginas web, incluyendo texto, imágenes y enlaces.

**Parámetros:**
- `url` (string): URL de la página web a scrapear
- `selector` (string, opcional): Selector CSS para extraer contenido específico
- `extractImages` (boolean, opcional): Si es true, extrae todas las URLs de imágenes
- `extractLinks` (boolean, opcional): Si es true, extrae todos los enlaces

**Ejemplo de uso:**
```json
{
  "url": "https://example.com/article",
  "selector": ".article-content",
  "extractImages": true
}
```

### propose_self_improvement

Busca código y funcionalidades en GitHub/internet para proponer mejoras al sistema. Analiza patrones, técnicas y mejores prácticas, y genera propuestas detalladas de mejora que requieren aprobación del usuario antes de aplicarse.

**Parámetros:**
- `query` (string): Qué tipo de mejora buscar
- `context` (string, opcional): Contexto adicional sobre el sistema actual

**Ejemplo de uso:**
```json
{
  "query": "optimización de rendimiento para agentes IA",
  "context": "El agente actualmente tarda mucho en responder consultas complejas"
}
```

## Almacenamiento de Archivos

Los archivos generados por el agente se almacenan automáticamente en **Amazon S3** para acceso permanente. El sistema mantiene metadatos en la base de datos incluyendo nombre del archivo, URL de acceso, tipo MIME, y tamaño. Los usuarios pueden descargar archivos generados directamente desde la interfaz de chat.

## Notificaciones al Propietario

El sistema envía notificaciones automáticas al propietario del proyecto cuando el agente completa tareas complejas que requieren más de tres pasos de ejecución. Esto permite monitorear el uso del sistema y detectar patrones de uso interesantes. Las notificaciones incluyen información sobre el usuario, número de pasos ejecutados, y un resumen de la tarea.

## Seguridad y Limitaciones

### Sandbox de Ejecución

Todo el código ejecutado por el agente corre en un entorno aislado con las siguientes restricciones:

- **Timeout de 30 segundos** por defecto para prevenir ejecuciones infinitas
- **Límite de memoria** de 10MB para salida de comandos
- **Directorio temporal** aislado para operaciones de archivos
- **Sin acceso a red** desde código Python/JavaScript ejecutado

### Navegación Web

El navegador automatizado opera con restricciones de seguridad:

- **Timeout de 30 segundos** para cargar páginas
- **Contenido limitado** a 5000 caracteres por extracción
- **Sin ejecución de JavaScript** malicioso gracias a Playwright

### Límites del Agente

El loop de razonamiento tiene un **límite de 10 iteraciones** para prevenir bucles infinitos. Si el agente no puede completar una tarea en 10 pasos, retorna el progreso alcanzado hasta ese momento.

## Arquitectura Técnica Detallada

### Motor del Agente

El motor del agente implementa un patrón de **ReAct (Reasoning + Acting)** donde cada iteración sigue estos pasos:

1. **Análisis**: El LLM recibe el contexto completo incluyendo la solicitud del usuario, historial de conversación, y resultados de herramientas previas
2. **Planificación**: El modelo decide qué herramienta usar y con qué parámetros
3. **Ejecución**: La herramienta seleccionada se ejecuta con los parámetros especificados
4. **Observación**: El resultado se agrega al contexto para la siguiente iteración
5. **Decisión**: El modelo determina si la tarea está completa o necesita más pasos

Este ciclo continúa hasta que el modelo genera una respuesta final sin llamadas a herramientas adicionales.

### Sistema de Herramientas

Las herramientas se definen usando el formato de **function calling** compatible con OpenAI, lo que permite al LLM entender qué herramientas están disponibles y cómo usarlas. Cada herramienta incluye:

- **Nombre**: Identificador único de la herramienta
- **Descripción**: Explicación de qué hace y cuándo usarla
- **Parámetros**: Schema JSON con tipos y descripciones de cada parámetro
- **Función de ejecución**: Implementación real de la herramienta

### Gestión de Contexto

El sistema mantiene contexto completo de cada conversación en la base de datos. Cuando el usuario envía un mensaje, el sistema:

1. Recupera todos los mensajes previos de la conversación
2. Construye el historial en formato compatible con Ollama
3. Ejecuta el agente con el contexto completo
4. Guarda el nuevo mensaje del usuario y la respuesta del asistente

Esto permite al agente mantener coherencia y referirse a interacciones anteriores.

### Integración con Ollama

La comunicación con Ollama se realiza mediante HTTP REST API. El sistema envía solicitudes POST a `/api/chat` con el formato:

```json
{
  "model": "deepseek-r1:8b",
  "messages": [
    {"role": "system", "content": "..."},
    {"role": "user", "content": "..."}
  ],
  "tools": [...]
}
```

Ollama responde con el mensaje del asistente, que puede incluir llamadas a herramientas en el formato `tool_calls`. El sistema ejecuta estas herramientas y envía los resultados de vuelta a Ollama para continuar el razonamiento.

## Stack Tecnológico Completo

### Frontend
- **React 19**: Biblioteca de UI con características modernas
- **TailwindCSS 4**: Framework de utilidades CSS con tema personalizado
- **tRPC 11**: Cliente type-safe para comunicación con backend
- **Wouter**: Router ligero para navegación
- **Streamdown**: Renderizado de markdown con soporte para streaming
- **Lucide React**: Iconos modernos y consistentes

### Backend
- **Express 4**: Servidor HTTP con middleware robusto
- **tRPC 11**: Framework para APIs type-safe
- **Drizzle ORM**: ORM moderno con inferencia de tipos
- **Zod**: Validación de esquemas con TypeScript
- **Axios**: Cliente HTTP para comunicación con Ollama

### Herramientas del Agente
- **Playwright**: Automatización de navegador Chromium
- **DuckDuckGo Search**: API de búsqueda sin autenticación
- **Pandas** (Python): Análisis y manipulación de datos
- **Matplotlib** (Python): Generación de gráficos y visualizaciones

### Infraestructura
- **MySQL/TiDB**: Base de datos relacional
- **Amazon S3**: Almacenamiento de objetos para archivos
- **Manus OAuth**: Sistema de autenticación integrado
- **Vitest**: Framework de testing unitario

## Desarrollo y Contribución

### Estructura del Proyecto

```
manus-clone/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Componentes de página
│   │   ├── components/    # Componentes reutilizables
│   │   ├── lib/           # Utilidades y configuración
│   │   └── index.css      # Estilos globales
│   └── public/            # Assets estáticos
├── server/                # Backend Express + tRPC
│   ├── _core/             # Infraestructura del framework
│   ├── tools/             # Implementación de herramientas
│   ├── agent.ts           # Motor del agente
│   ├── ollama.ts          # Cliente de Ollama
│   ├── db.ts              # Helpers de base de datos
│   └── routers.ts         # Definición de endpoints
├── drizzle/               # Esquema y migraciones
│   └── schema.ts          # Definición de tablas
└── shared/                # Código compartido
```

### Agregar Nuevas Herramientas

Para agregar una nueva herramienta al agente:

1. **Crear el archivo de la herramienta** en `server/tools/`:

```typescript
export interface MyToolInput {
  param1: string;
  param2: number;
}

export interface MyToolOutput {
  result: string;
}

export async function myTool(input: MyToolInput): Promise<MyToolOutput> {
  // Implementación
  return { result: "..." };
}

export const myToolDefinition = {
  type: "function" as const,
  function: {
    name: "my_tool",
    description: "Descripción de qué hace la herramienta",
    parameters: {
      type: "object",
      properties: {
        param1: { type: "string", description: "..." },
        param2: { type: "number", description: "..." },
      },
      required: ["param1", "param2"],
    },
  },
};
```

2. **Registrar la herramienta** en `server/agent.ts`:

```typescript
import { myTool, myToolDefinition } from "./tools/myTool";

const AVAILABLE_TOOLS = [
  // ... otras herramientas
  myToolDefinition,
];

const TOOL_FUNCTIONS: Record<string, (input: any) => Promise<any>> = {
  // ... otras funciones
  my_tool: myTool,
};
```

3. **Probar la herramienta** escribiendo un test en `server/tools/myTool.test.ts`

### Ejecutar Tests

El proyecto incluye tests unitarios para verificar funcionalidad:

```bash
# Ejecutar todos los tests
pnpm test

# Ejecutar tests en modo watch
pnpm test -- --watch

# Ejecutar tests con cobertura
pnpm test -- --coverage
```

### Formateo de Código

El proyecto usa Prettier para mantener consistencia:

```bash
pnpm format
```

## Casos de Uso Avanzados

### Análisis de Datos Complejo

El agente puede procesar datasets completos, realizar análisis estadístico, y generar visualizaciones:

**Ejemplo**: "Aquí están mis datos de ventas en CSV. Analiza las tendencias por mes, calcula el crecimiento porcentual, y crea un gráfico de líneas mostrando la evolución."

El agente:
1. Usa `analyze_data` con operación "describe" para entender los datos
2. Usa `execute_code` para calcular crecimiento porcentual
3. Usa `analyze_data` con operación "plot" para generar visualización
4. Usa `write_file` para guardar resultados
5. Proporciona análisis interpretativo de los hallazgos

### Investigación Web Profunda

El agente puede realizar investigación multi-fuente combinando búsqueda y navegación:

**Ejemplo**: "Investiga las mejores prácticas de arquitectura de microservicios, busca artículos recientes, y resume los puntos clave."

El agente:
1. Usa `search_web` para encontrar artículos relevantes
2. Usa `navigate_to_url` para leer cada artículo
3. Sintetiza información de múltiples fuentes
4. Genera resumen estructurado con referencias

### Generación de Código con Validación

El agente puede escribir código, ejecutarlo para verificar que funciona, y refinarlo:

**Ejemplo**: "Escribe una función en Python que convierta temperaturas de Celsius a Fahrenheit, pruébala con varios valores, y guárdala en un archivo."

El agente:
1. Genera el código inicial
2. Usa `execute_code` para probar la función
3. Verifica los resultados
4. Usa `write_file` para guardar el código validado

## Limitaciones Conocidas

### Dependencia de Ollama

El sistema requiere que Ollama esté ejecutándose localmente o en un servidor accesible. Si Ollama no está disponible, el agente no puede funcionar. Para entornos de producción, considere configurar Ollama como servicio systemd con reinicio automático.

### Rendimiento de Modelos

Los modelos de código abierto, aunque potentes, pueden ser más lentos que modelos comerciales como GPT-4. El tiempo de respuesta depende del hardware disponible. Se recomienda GPU para mejor rendimiento, aunque los modelos más pequeños (7B-8B parámetros) funcionan razonablemente en CPU.

### Capacidad de Razonamiento

Aunque los modelos modernos son impresionantes, pueden cometer errores en tareas muy complejas o ambiguas. El límite de 10 iteraciones puede ser insuficiente para problemas extremadamente complejos. Considere descomponer tareas muy grandes en subtareas más manejables.

## Roadmap Futuro

### Mejoras Planificadas

- **Streaming de respuestas**: Implementar streaming real-time de respuestas del LLM para mejor UX
- **Historial de conversaciones**: Sidebar con lista de conversaciones previas
- **Subida de archivos**: Permitir al usuario subir archivos para que el agente los procese
- **Más herramientas**: Integrar APIs adicionales (clima, finanzas, traducción, etc.)
- **Memoria a largo plazo**: Sistema de embeddings para recordar información entre sesiones
- **Múltiples agentes**: Coordinación de varios agentes especializados para tareas complejas

### Optimizaciones Técnicas

- **Caché de resultados**: Cachear resultados de herramientas para evitar ejecuciones redundantes
- **Paralelización**: Ejecutar herramientas independientes en paralelo
- **Compresión de contexto**: Resumir conversaciones largas para mantener contexto manejable
- **Fine-tuning**: Entrenar modelos específicos para mejorar rendimiento en tareas comunes

## Conclusión

Este sistema demuestra el poder de los agentes autónomos basados en LLMs de código abierto. Al combinar razonamiento avanzado con herramientas especializadas, el agente puede resolver problemas complejos que requieren múltiples pasos y diferentes tipos de conocimiento. La arquitectura modular facilita la extensión con nuevas capacidades, y el uso de modelos gratuitos hace que la solución sea accesible sin costos de API recurrentes.

El código está diseñado para ser mantenible y escalable, siguiendo mejores prácticas de TypeScript, React, y desarrollo backend moderno. La integración con Manus proporciona autenticación, base de datos, y almacenamiento sin configuración adicional, permitiendo enfocarse en la lógica del agente.

---

**Desarrollado con Manus AI** | **Licencia MIT** | **Versión 1.0.0**
