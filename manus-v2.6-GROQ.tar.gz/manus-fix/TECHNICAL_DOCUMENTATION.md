# Documentación Técnica - Asistente IA Autónomo

**Autor:** Manus AI  
**Fecha:** Febrero 2026  
**Versión del Proyecto:** 2.0

---

## Resumen Ejecutivo

Este documento proporciona una documentación técnica completa del **Asistente IA Autónomo**, un sistema de inteligencia artificial capaz de razonar, planificar y ejecutar tareas complejas de manera independiente. El sistema está construido con React 19, TypeScript, tRPC, Express y utiliza el LLM integrado de Manus para procesamiento de lenguaje natural.

El asistente cuenta con **13 herramientas especializadas** que le permiten realizar búsquedas web, navegar sitios, ejecutar código, analizar datos, generar imágenes, transcribir audio, y proponer mejoras a su propio código. Además, incluye un sistema de auto-mejora que permite al agente buscar código en internet y proponer actualizaciones que requieren aprobación del usuario.

---

## Arquitectura del Sistema

### Stack Tecnológico

El proyecto utiliza las siguientes tecnologías principales:

| Componente | Tecnología | Versión | Propósito |
|------------|------------|---------|-----------|
| Frontend | React | 19.2.1 | Interfaz de usuario reactiva |
| Estilos | Tailwind CSS | 4.1.14 | Sistema de diseño utility-first |
| Componentes UI | shadcn/ui + Radix UI | Última | Componentes accesibles |
| Backend | Express | 4.21.2 | Servidor HTTP |
| API | tRPC | 11.6.0 | Type-safe API sin REST |
| Base de Datos | MySQL/TiDB | - | Almacenamiento persistente |
| ORM | Drizzle | 0.44.5 | Mapeo objeto-relacional |
| LLM | Manus Built-in API | - | Procesamiento de lenguaje natural |
| Autenticación | Manus OAuth | - | Sistema de login integrado |
| Almacenamiento | S3 Compatible | - | Archivos y assets |

### Arquitectura de Componentes

El sistema sigue una arquitectura de tres capas claramente definida:

**Capa de Presentación (Frontend):** La interfaz de usuario está construida con React 19 y utiliza el patrón de componentes funcionales con hooks. Los componentes principales incluyen la página de chat (`Chat.tsx`), la página de revisión de mejoras (`Improvements.tsx`), y componentes reutilizables como `FileUpload.tsx` e `ImprovementProposalCard.tsx`. La comunicación con el backend se realiza exclusivamente a través de tRPC, lo que garantiza type-safety end-to-end.

**Capa de Lógica de Negocio (Backend):** El servidor Express maneja las solicitudes HTTP y expone procedimientos tRPC definidos en `server/routers.ts`. El motor del agente autónomo (`server/agent.ts`) implementa un loop de razonamiento que analiza solicitudes del usuario, selecciona herramientas apropiadas, ejecuta acciones y genera respuestas. Las herramientas del agente están modularizadas en archivos separados bajo `server/tools/`.

**Capa de Datos:** Drizzle ORM gestiona el esquema de base de datos definido en `drizzle/schema.ts`. Las tablas principales incluyen usuarios, conversaciones, mensajes, ejecuciones de herramientas, archivos subidos y propuestas de mejora. Los helpers de base de datos en `server/db.ts` proporcionan funciones reutilizables para operaciones CRUD comunes.

---

## Motor del Agente Autónomo

### Loop de Razonamiento

El agente implementa un ciclo iterativo de razonamiento basado en el patrón **Analyze → Plan → Execute → Observe**:

**Fase 1 - Análisis:** El agente recibe el mensaje del usuario y el historial de conversación. Construye un contexto completo incluyendo el prompt del sistema que describe sus capacidades y las herramientas disponibles.

**Fase 2 - Planificación:** El LLM analiza la solicitud y decide qué herramientas necesita usar. Puede seleccionar múltiples herramientas en secuencia para tareas complejas. El sistema utiliza function calling nativo del LLM para esta selección.

**Fase 3 - Ejecución:** Cada herramienta seleccionada se ejecuta con los parámetros proporcionados por el LLM. Los resultados se capturan y se agregan al contexto de la conversación como mensajes de tipo "tool".

**Fase 4 - Observación:** El agente evalúa los resultados de las herramientas ejecutadas. Si la tarea no está completa, regresa a la fase de planificación. Si está completa o se alcanza el límite de iteraciones (10 por defecto), genera una respuesta final para el usuario.

Este loop continúa hasta que el agente determina que ha completado la tarea o alcanza el máximo de iteraciones configurado.

### Gestión de Contexto

El sistema mantiene el contexto de conversación completo en memoria durante cada sesión. Cada mensaje incluye su rol (system, user, assistant, tool) y contenido. El historial se persiste en la base de datos después de cada interacción, permitiendo que las conversaciones se retomen en sesiones futuras.

---

## Herramientas del Agente

El agente tiene acceso a 13 herramientas especializadas organizadas por categoría:

### Herramientas de Búsqueda e Información

**search_web:** Realiza búsquedas en internet usando DuckDuckGo API sin requerir API keys. Retorna títulos, descripciones y URLs de resultados relevantes. Implementada en `server/tools/search.ts`.

**navigate_to_url:** Navega a una URL específica usando Playwright y extrae el contenido completo de la página. Útil para leer artículos, documentación o páginas web. Implementada en `server/tools/browser.ts`.

**extract_data:** Extrae datos estructurados de páginas web usando selectores CSS. Permite scraping dirigido de información específica. Implementada en `server/tools/browser.ts`.

**scrape_web:** Scraping web avanzado que extrae no solo texto sino también imágenes, enlaces y metadatos de páginas. Usa Cheerio para parsing HTML eficiente. Implementada en `server/tools/webScraper.ts`.

### Herramientas de Ejecución de Código

**execute_code:** Ejecuta código Python o JavaScript en un sandbox aislado. Captura stdout, stderr y valores de retorno. Soporta instalación de paquetes npm y pip. Implementada en `server/tools/codeExecutor.ts`.

### Herramientas de Análisis de Datos

**analyze_data:** Analiza datos estructurados (CSV, JSON, Excel) usando Pandas. Puede generar estadísticas descriptivas, filtrar datos, crear gráficos con Matplotlib/Plotly y exportar resultados. Implementada en `server/tools/dataAnalyzer.ts`.

### Herramientas de Generación de Contenido

**generate_image:** Genera imágenes desde descripciones de texto usando el servicio de generación de imágenes integrado de Manus. Retorna URLs de imágenes almacenadas en S3. Implementada en `server/tools/imageGenerator.ts`.

**generate_video:** Genera videos cortos desde texto usando Runway ML API (requiere API key del usuario). Implementa polling para esperar la generación completa. Implementada en `server/tools/videoGenerator.ts`.

### Herramientas de Audio

**transcribe_audio:** Transcribe archivos de audio a texto usando Whisper API. Soporta múltiples formatos (mp3, wav, webm, m4a). Retorna transcripción completa con timestamps. Implementada en `server/tools/audioTranscriber.ts`.

### Herramientas de Sistema de Archivos

**read_file:** Lee archivos del workspace del agente. Permite acceder a archivos generados previamente o proporcionados por el usuario. Implementada en `server/tools/fileSystem.ts`.

**write_file:** Escribe archivos en el workspace del agente. Útil para guardar código generado, datos procesados o resultados de análisis. Implementada en `server/tools/fileSystem.ts`.

**list_files:** Lista todos los archivos disponibles en el workspace. Ayuda al agente a navegar el sistema de archivos. Implementada en `server/tools/fileSystem.ts`.

### Herramienta de Auto-Mejora

**propose_self_improvement:** Busca código y funcionalidades en GitHub, analiza patrones de implementación y propone mejoras al propio código del sistema. Las propuestas se guardan en la base de datos y requieren aprobación explícita del usuario antes de aplicarse. Implementada en `server/tools/selfImprovement.ts`.

---

## Sistema de Auto-Mejora

### Flujo de Propuesta de Mejoras

El sistema de auto-mejora permite que el agente evolucione autónomamente con supervisión humana:

**Paso 1 - Identificación:** El agente identifica áreas de mejora potencial basándose en solicitudes del usuario, errores encontrados o limitaciones detectadas.

**Paso 2 - Investigación:** Usa la herramienta `propose_self_improvement` para buscar implementaciones similares en GitHub, analizar patrones de código y evaluar diferentes enfoques.

**Paso 3 - Generación de Propuesta:** Crea una propuesta estructurada que incluye título, descripción detallada, justificación técnica, cambios de código específicos (con diff), y nivel de impacto estimado.

**Paso 4 - Almacenamiento:** La propuesta se guarda en la tabla `improvementProposals` con estado "pending" y se notifica al propietario del sistema.

**Paso 5 - Revisión del Usuario:** El usuario accede a la página `/improvements` donde puede ver todas las propuestas pendientes, revisar los cambios de código propuestos y aprobar o rechazar cada una.

**Paso 6 - Aplicación:** Si se aprueba, el sistema ejecuta `improvementApplicator.ts` que crea un backup de los archivos afectados, aplica los cambios, valida la sintaxis con TypeScript, y si todo funciona, marca la mejora como "applied". Si algo falla, hace rollback automático.

### Seguridad y Validación

El sistema incluye múltiples capas de seguridad para prevenir cambios peligrosos:

- **Aprobación obligatoria:** Ninguna mejora se aplica sin aprobación explícita del usuario.
- **Backup automático:** Todos los archivos modificados se respaldan antes de aplicar cambios.
- **Validación de sintaxis:** Se ejecuta `pnpm run check` para verificar que el código compilado correctamente.
- **Rollback automático:** Si la validación falla, los archivos se restauran desde el backup.
- **Auditoría completa:** Cada mejora aplicada se registra con timestamp, usuario que aprobó y resultado.

---

## Base de Datos

### Esquema de Tablas

El esquema de base de datos está definido en `drizzle/schema.ts` e incluye las siguientes tablas principales:

**Tabla users:** Almacena información de usuarios autenticados. Campos clave incluyen `id` (autoincremental), `openId` (identificador OAuth único), `email`, `name`, `role` (enum: user/admin), `createdAt`, `updatedAt` y `lastSignedIn`. El usuario con email "damh0087@gmail.com" se reconoce automáticamente como admin.

**Tabla conversations:** Representa sesiones de chat. Contiene `id`, `userId` (foreign key a users), `title` (generado automáticamente o proporcionado por usuario), `createdAt` y `updatedAt`.

**Tabla messages:** Almacena mensajes individuales dentro de conversaciones. Incluye `id`, `conversationId` (foreign key), `role` (system/user/assistant/tool), `content` (texto del mensaje), `createdAt`.

**Tabla toolExecutions:** Registra cada ejecución de herramienta por el agente. Campos: `id`, `messageId` (foreign key), `toolName`, `toolInput` (JSON), `toolOutput` (JSON), `status` (success/error), `executedAt`.

**Tabla uploadedFiles:** Gestiona archivos subidos por usuarios. Contiene `id`, `userId`, `conversationId` (opcional), `filename`, `mimeType`, `size`, `s3Key`, `s3Url`, `uploadedAt`.

**Tabla improvementProposals:** Almacena propuestas de auto-mejora. Incluye `id`, `userId`, `title`, `description`, `justification`, `impact` (low/medium/high), `codeChanges` (JSON con diffs), `status` (pending/approved/rejected/applied), `createdAt`, `approvedAt`, `appliedAt`.

### Relaciones

Las relaciones entre tablas están definidas mediante foreign keys:

- Un usuario puede tener múltiples conversaciones (1:N)
- Una conversación pertenece a un usuario y contiene múltiples mensajes (1:N)
- Un mensaje puede tener múltiples ejecuciones de herramientas (1:N)
- Un archivo subido pertenece a un usuario y opcionalmente a una conversación (N:1)
- Una propuesta de mejora pertenece a un usuario (N:1)

---

## Sistema de Autenticación

El proyecto utiliza **Manus OAuth** para autenticación. El flujo completo está implementado en `server/_core/oauth.ts` y funciona de la siguiente manera:

**Inicio de sesión:** El usuario hace clic en "Iniciar sesión" y es redirigido a la URL de OAuth de Manus (`VITE_OAUTH_PORTAL_URL`). El estado de la solicitud incluye el origin del frontend y la ruta de retorno.

**Callback:** Después de autenticarse, Manus redirige al usuario a `/api/oauth/callback` con un código de autorización. El servidor intercambia este código por tokens de acceso.

**Creación de sesión:** El servidor crea una sesión firmada con JWT usando `JWT_SECRET` y la almacena en una cookie httpOnly con `sameSite: none` y `secure: true`.

**Verificación:** En cada solicitud a `/api/trpc`, el middleware de contexto (`server/_core/context.ts`) verifica la cookie de sesión, decodifica el JWT y carga el usuario desde la base de datos.

**Procedimientos protegidos:** Los procedimientos tRPC pueden usar `protectedProcedure` para requerir autenticación. Si el usuario no está autenticado, se lanza un error UNAUTHORIZED.

---

## Almacenamiento de Archivos

El sistema utiliza **almacenamiento S3 compatible** para todos los archivos generados y subidos. Los helpers están en `server/storage.ts`:

**storagePut:** Sube un archivo a S3 con una key específica. Acepta Buffer, Uint8Array o string como contenido. Retorna la URL pública del archivo.

**storageGet:** Genera una URL pre-firmada para acceder a un archivo privado (actualmente no se usa porque el bucket es público).

Todos los archivos subidos por usuarios se almacenan con keys en formato `user-{userId}/uploads/{filename}-{random}.ext` para evitar colisiones y enumeración. Las URLs se guardan en la base de datos para referencia futura.

---

## API tRPC

La API del sistema está completamente definida mediante tRPC en `server/routers.ts`. Los routers principales son:

### Router auth

- `me`: Retorna el usuario actual autenticado (o null si no hay sesión)
- `logout`: Limpia la cookie de sesión y cierra la sesión del usuario

### Router chat

- `sendMessage`: Envía un mensaje al agente y ejecuta el loop de razonamiento. Retorna la respuesta completa con pasos ejecutados.
- `getConversations`: Lista todas las conversaciones del usuario actual
- `getMessages`: Obtiene todos los mensajes de una conversación específica
- `createConversation`: Crea una nueva conversación vacía
- `deleteConversation`: Elimina una conversación y todos sus mensajes

### Router improvements

- `list`: Lista todas las propuestas de mejora del usuario con filtros por estado
- `approve`: Marca una propuesta como aprobada
- `reject`: Marca una propuesta como rechazada
- `applyImprovement`: Aplica una mejora aprobada al código del sistema
- `rollback`: Revierte una mejora aplicada (restaura desde backup)

### Router files

- `upload`: Sube un archivo a S3 y guarda metadata en la base de datos
- `list`: Lista todos los archivos subidos por el usuario
- `delete`: Elimina un archivo de S3 y la base de datos

---

## Frontend

### Estructura de Componentes

La interfaz de usuario está organizada en páginas y componentes reutilizables:

**Páginas principales:**

- `Chat.tsx`: Interfaz principal de chat con el agente. Muestra historial de mensajes, indicadores de herramientas en ejecución, y permite enviar mensajes y subir archivos.
- `Improvements.tsx`: Página de revisión de propuestas de mejora. Muestra lista filtrable de propuestas con detalles expandibles y botones de acción.
- `NotFound.tsx`: Página 404 para rutas no encontradas.

**Componentes reutilizables:**

- `FileUpload.tsx`: Componente de subida de archivos con drag & drop y previsualizaciones.
- `ImprovementProposalCard.tsx`: Tarjeta individual de propuesta de mejora con diff de código y acciones.
- `ErrorBoundary.tsx`: Captura errores de React y muestra UI de fallback.
- `DashboardLayout.tsx`: Layout con sidebar para aplicaciones tipo dashboard (no usado actualmente).

### Gestión de Estado

El estado de la aplicación se gestiona principalmente a través de:

- **React Query (via tRPC):** Gestiona el estado del servidor, caché de datos y sincronización automática.
- **React useState:** Estado local de componentes (input de chat, archivos seleccionados, etc.).
- **useAuth hook:** Hook personalizado que encapsula la lógica de autenticación y proporciona `user`, `loading`, `isAuthenticated` y `logout`.

### Estilización

El proyecto usa **Tailwind CSS 4** con un sistema de diseño personalizado definido en `client/src/index.css`. Los colores principales son tonos de púrpura para el tema claro. Los componentes UI de shadcn/ui proporcionan componentes accesibles y estilizados consistentemente.

---

## Despliegue y Configuración

### Variables de Entorno

El sistema requiere las siguientes variables de entorno (inyectadas automáticamente por Manus):

| Variable | Descripción |
|----------|-------------|
| `DATABASE_URL` | Cadena de conexión MySQL/TiDB |
| `JWT_SECRET` | Secreto para firmar tokens de sesión |
| `VITE_APP_ID` | ID de aplicación OAuth de Manus |
| `OAUTH_SERVER_URL` | URL del servidor OAuth de Manus |
| `VITE_OAUTH_PORTAL_URL` | URL del portal de login de Manus |
| `OWNER_OPEN_ID` | OpenID del propietario del proyecto |
| `OWNER_NAME` | Nombre del propietario |
| `BUILT_IN_FORGE_API_URL` | URL de APIs integradas de Manus |
| `BUILT_IN_FORGE_API_KEY` | Token de autenticación para APIs de Manus |
| `VITE_FRONTEND_FORGE_API_KEY` | Token para frontend acceder a APIs de Manus |
| `RUNWAY_API_KEY` | (Opcional) API key de Runway ML para generación de video |

### Scripts de Desarrollo

El proyecto incluye los siguientes scripts npm:

- `pnpm dev`: Inicia el servidor de desarrollo con hot-reload
- `pnpm build`: Compila el proyecto para producción
- `pnpm start`: Ejecuta el servidor en modo producción
- `pnpm check`: Verifica tipos de TypeScript sin compilar
- `pnpm test`: Ejecuta tests con Vitest
- `pnpm db:push`: Genera y aplica migraciones de base de datos

### Proceso de Despliegue

El despliegue se realiza a través de la interfaz de Manus:

1. Crear un checkpoint con `webdev_save_checkpoint`
2. Hacer clic en el botón "Publish" en la UI de Manus
3. Configurar dominio personalizado si es necesario
4. El sistema se despliega automáticamente en la infraestructura de Manus

---

## Extensibilidad

### Agregar Nuevas Herramientas

Para agregar una nueva herramienta al agente:

1. Crear archivo en `server/tools/nombreHerramienta.ts`
2. Exportar función de ejecución y definición de herramienta
3. Importar en `server/agent.ts`
4. Agregar a `AVAILABLE_TOOLS` y `TOOL_FUNCTIONS`
5. Reiniciar servidor

Ejemplo de estructura de herramienta:

```typescript
export interface MiHerramientaInput {
  parametro: string;
}

export interface MiHerramientaOutput {
  resultado: string;
}

export async function ejecutarMiHerramienta(
  input: MiHerramientaInput
): Promise<MiHerramientaOutput> {
  // Lógica de la herramienta
  return { resultado: "..." };
}

export const miHerramientaTool = {
  type: "function" as const,
  function: {
    name: "mi_herramienta",
    description: "Descripción clara de qué hace",
    parameters: {
      type: "object",
      properties: {
        parametro: {
          type: "string",
          description: "Descripción del parámetro",
        },
      },
      required: ["parametro"],
    },
  },
};
```

### Agregar Nuevos Procedimientos tRPC

Para agregar nuevos endpoints API:

1. Abrir `server/routers.ts`
2. Agregar procedimiento al router correspondiente o crear nuevo router
3. Usar `publicProcedure` o `protectedProcedure` según necesidad
4. Definir input con Zod schema
5. Implementar lógica en `.query()` o `.mutation()`

### Agregar Nuevas Tablas

Para agregar nuevas tablas a la base de datos:

1. Editar `drizzle/schema.ts`
2. Definir tabla con `mysqlTable`
3. Exportar tipo con `typeof tabla.$inferSelect`
4. Ejecutar `pnpm db:push` para aplicar cambios
5. Agregar helpers en `server/db.ts` si es necesario

---

## Mantenimiento y Debugging

### Logs

El sistema genera logs en `.manus-logs/`:

- `devserver.log`: Logs del servidor Express y Vite
- `browserConsole.log`: Logs de consola del navegador
- `networkRequests.log`: Logs de peticiones HTTP
- `sessionReplay.log`: Logs de interacciones del usuario

Usar comandos de terminal (grep, tail, awk) para filtrar logs en lugar de leer archivos completos.

### Testing

El proyecto usa Vitest para testing. Los tests están en archivos `*.test.ts` junto al código que prueban. Ejecutar `pnpm test` para correr todos los tests.

### Debugging del Agente

Si el agente no responde correctamente:

1. Verificar logs de consola en `.manus-logs/browserConsole.log`
2. Revisar respuestas del LLM en logs del servidor
3. Verificar que las herramientas retornen el formato esperado
4. Aumentar `maxIterations` si el agente necesita más pasos
5. Simplificar la solicitud del usuario para aislar el problema

---

## Limitaciones Conocidas

El sistema tiene las siguientes limitaciones actuales:

- **Límite de iteraciones:** El agente está limitado a 10 iteraciones por solicitud para evitar loops infinitos.
- **Memoria de contexto:** El historial completo de conversación se mantiene en memoria, lo que puede causar problemas con conversaciones muy largas.
- **Ejecución de código:** El sandbox de ejecución de código tiene acceso limitado al sistema de archivos y red.
- **Generación de video:** Requiere API key de Runway ML (de pago) y puede tardar varios minutos.
- **Concurrencia:** El agente procesa una solicitud a la vez por conversación.

---

## Seguridad

### Consideraciones de Seguridad

El sistema implementa las siguientes medidas de seguridad:

- **Autenticación OAuth:** Todas las operaciones requieren autenticación válida.
- **Cookies httpOnly:** Las sesiones se almacenan en cookies httpOnly para prevenir XSS.
- **CORS configurado:** Solo permite requests desde el origin del frontend.
- **Validación de input:** Todos los inputs se validan con Zod schemas.
- **SQL injection:** Drizzle ORM previene inyección SQL automáticamente.
- **Sandbox de código:** El código ejecutado por el agente corre en proceso aislado.
- **Aprobación de mejoras:** Cambios al código requieren aprobación explícita del usuario.

### Recomendaciones de Seguridad

Para producción, se recomienda:

- Implementar rate limiting en endpoints públicos
- Agregar CAPTCHA en formularios de login
- Configurar Content Security Policy (CSP)
- Implementar logging de auditoría para acciones sensibles
- Agregar 2FA para cuentas de administrador
- Revisar y aprobar manualmente todas las propuestas de auto-mejora

---

## Conclusión

Este documento proporciona una visión completa de la arquitectura, implementación y funcionamiento del Asistente IA Autónomo. El sistema está diseñado para ser extensible, mantenible y seguro. Para continuar el desarrollo, consulta los documentos adicionales: Guía de Arquitectura, Manual de Desarrollo y Archivo de Contexto para IAs.

---

**Documento generado por Manus AI - Febrero 2026**
