import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";
import { CheckCircle2, XCircle, AlertTriangle, Code } from "lucide-react";

interface CodeChange {
  file: string;
  changes: string;
  explanation: string;
}

interface ImprovementProposal {
  id: string;
  title: string;
  description: string;
  reasoning: string;
  codeChanges: CodeChange[];
  benefits: string[];
  risks: string[];
  estimatedImpact: "low" | "medium" | "high";
  status: "pending" | "approved" | "rejected" | "applied" | "failed";
  createdAt: Date;
}

interface ImprovementProposalCardProps {
  proposal: ImprovementProposal;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

const impactColors = {
  low: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  medium: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
  high: "bg-red-500/10 text-red-500 border-red-500/20",
};

const statusColors = {
  pending: "bg-gray-500/10 text-gray-500",
  approved: "bg-green-500/10 text-green-500",
  rejected: "bg-red-500/10 text-red-500",
  applied: "bg-purple-500/10 text-purple-500",
  failed: "bg-orange-500/10 text-orange-500",
};

export function ImprovementProposalCard({
  proposal,
  onApprove,
  onReject,
}: ImprovementProposalCardProps) {
  const isPending = proposal.status === "pending";

  return (
    <Card className="w-full border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="text-xl mb-2">{proposal.title}</CardTitle>
            <CardDescription>{proposal.description}</CardDescription>
          </div>
          <div className="flex flex-col gap-2">
            <Badge className={impactColors[proposal.estimatedImpact]}>
              Impacto: {proposal.estimatedImpact}
            </Badge>
            <Badge className={statusColors[proposal.status]}>
              {proposal.status}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Razonamiento */}
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Razonamiento
          </h4>
          <p className="text-sm text-muted-foreground">{proposal.reasoning}</p>
        </div>

        {/* Beneficios */}
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-500" />
            Beneficios
          </h4>
          <ul className="list-disc list-inside space-y-1">
            {proposal.benefits.map((benefit, idx) => (
              <li key={idx} className="text-sm text-muted-foreground">
                {benefit}
              </li>
            ))}
          </ul>
        </div>

        {/* Riesgos */}
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <XCircle className="w-4 h-4 text-red-500" />
            Riesgos
          </h4>
          <ul className="list-disc list-inside space-y-1">
            {proposal.risks.map((risk, idx) => (
              <li key={idx} className="text-sm text-muted-foreground">
                {risk}
              </li>
            ))}
          </ul>
        </div>

        {/* Cambios de código */}
        <div>
          <h4 className="font-semibold mb-2 flex items-center gap-2">
            <Code className="w-4 h-4" />
            Cambios de Código
          </h4>
          <Accordion type="single" collapsible className="w-full">
            {proposal.codeChanges.map((change, idx) => (
              <AccordionItem key={idx} value={`item-${idx}`}>
                <AccordionTrigger className="text-sm">
                  {change.file}
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">{change.explanation}</p>
                    <pre className="bg-muted p-3 rounded-md text-xs overflow-x-auto">
                      <code>{change.changes}</code>
                    </pre>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </CardContent>

      {isPending && (
        <CardFooter className="flex gap-3">
          <Button
            onClick={() => onApprove(proposal.id)}
            className="flex-1 bg-green-600 hover:bg-green-700"
          >
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Aprobar
          </Button>
          <Button
            onClick={() => onReject(proposal.id)}
            variant="destructive"
            className="flex-1"
          >
            <XCircle className="w-4 h-4 mr-2" />
            Rechazar
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
