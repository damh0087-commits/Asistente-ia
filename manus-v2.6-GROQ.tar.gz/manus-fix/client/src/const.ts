export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

// Local authentication - simple redirect to /auth page
export const getLoginUrl = () => {
  return "/auth";
};
