import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Send, Bot, User, Sparkles, Code, Globe, Search, FileText, BarChart, Paperclip, Settings } from "lucide-react";
import { Link } from "wouter";
import { FileUpload } from "@/components/FileUpload";
import { Streamdown } from "streamdown";

interface Message {
  id: number;
  role: "user" | "assistant" | "system" | "tool";
  content: string;
  createdAt: Date;
}

interface AgentStep {
  type: "thought" | "tool_call" | "tool_result" | "answer";
  content: string;
  toolName?: string;
  toolInput?: any;
  toolOutput?: any;
  timestamp: number;
}

const TOOL_ICONS: Record<string, any> = {
  search_web: Search,
  navigate_to_url: Globe,
  extract_data: Globe,
  execute_code: Code,
  analyze_data: BarChart,
  read_file: FileText,
  write_file: FileText,
  list_files: FileText,
};

export default function Chat() {
  const { user, loading: authLoading } = useAuth();
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<number | undefined>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentSteps, setCurrentSteps] = useState<AgentStep[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<Array<{ url: string; filename: string; mimeType: string }>>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  const sendMessageMutation = trpc.chat.sendMessage.useMutation();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, currentSteps]);

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage = input.trim();
    setInput("");
    setIsProcessing(true);
    setCurrentSteps([]);

    // Agregar mensaje del usuario inmediatamente
    const tempUserMessage: Message = {
      id: Date.now(),
      role: "user",
      content: userMessage,
      createdAt: new Date(),
    };
    setMessages((prev) => [...prev, tempUserMessage]);

    try {
      const result = await sendMessageMutation.mutateAsync({
        conversationId,
        message: userMessage,
      });

      if (!conversationId) {
        setConversationId(result.conversationId);
      }

      // Mostrar pasos del agente
      setCurrentSteps(result.steps || []);

      // Agregar respuesta del asistente
      const assistantMessage: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content: result.answer,
        createdAt: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content: "Lo siento, ocurrió un error al procesar tu mensaje. Por favor, intenta de nuevo.",
        createdAt: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
      setCurrentSteps([]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">Iniciar Sesión</h2>
          <p className="text-muted-foreground mb-6">
            Por favor, inicia sesión para usar el asistente de IA.
          </p>
          <Button asChild>
            <a href="/api/oauth/login">Iniciar Sesión</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gradient-bg">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">Asistente IA Autónomo</h1>
              <p className="text-xs text-muted-foreground">Con modelos gratuitos</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/improvements">
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Mejoras
              </Button>
            </Link>
            <span className="text-sm text-muted-foreground">{user.name}</span>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full" ref={scrollRef}>
          <div className="container max-w-4xl py-8 space-y-6">
            {messages.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-2">¡Hola! Soy tu asistente de IA</h2>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Puedo ayudarte con búsquedas web, análisis de datos, ejecución de código,
                  navegación web y mucho más. ¿En qué puedo ayudarte hoy?
                </p>
              </div>
            )}

            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 message-enter ${
                  message.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                )}
                <Card
                  className={`p-4 max-w-[80%] ${
                    message.role === "user"
                      ? "bg-primary text-primary-foreground"
                      : "glass-card"
                  }`}
                >
                  {message.role === "assistant" ? (
                    <Streamdown>{message.content}</Streamdown>
                  ) : (
                    <p className="whitespace-pre-wrap">{message.content}</p>
                  )}
                </Card>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4 text-accent" />
                  </div>
                )}
              </div>
            ))}

            {/* Agent Steps */}
            {isProcessing && currentSteps.length > 0 && (
              <div className="space-y-2">
                {currentSteps.map((step, index) => (
                  <Card
                    key={index}
                    className={`p-3 glass-card ${
                      step.type === "tool_call" ? "tool-executing" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm">
                      {step.toolName && TOOL_ICONS[step.toolName] && (
                        <span className="text-primary">
                          {(() => {
                            const Icon = TOOL_ICONS[step.toolName];
                            return <Icon className="w-4 h-4" />;
                          })()}
                        </span>
                      )}
                      <span className="font-medium text-muted-foreground">
                        {step.content}
                      </span>
                      {step.type === "tool_call" && (
                        <Loader2 className="w-4 h-4 animate-spin text-primary ml-auto" />
                      )}
                    </div>
                    {step.toolOutput && step.type === "tool_result" && (
                      <div className="mt-2 text-xs text-muted-foreground">
                        <pre className="bg-muted/50 p-2 rounded overflow-x-auto">
                          {JSON.stringify(step.toolOutput, null, 2).slice(0, 200)}
                          {JSON.stringify(step.toolOutput).length > 200 && "..."}
                        </pre>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {isProcessing && currentSteps.length === 0 && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
                <Card className="p-4 glass-card">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span className="text-sm text-muted-foreground">
                      Pensando...
                    </span>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Input Area */}
      <div className="border-t bg-card/80 backdrop-blur-sm">
        <div className="container max-w-4xl py-4">
          <div className="space-y-3">
            {showFileUpload && (
              <FileUpload
                conversationId={conversationId}
                onFileUploaded={(file) => {
                  setUploadedFiles(prev => [...prev, file]);
                  setShowFileUpload(false);
                }}
              />
            )}
            {uploadedFiles.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {uploadedFiles.map((file, idx) => (
                  <div key={idx} className="text-xs bg-muted px-2 py-1 rounded flex items-center gap-1">
                    <Paperclip className="w-3 h-3" />
                    {file.filename}
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowFileUpload(!showFileUpload)}
                disabled={isProcessing}
              >
                <Paperclip className="w-4 h-4" />
              </Button>
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Escribe tu mensaje..."
                disabled={isProcessing}
                className="flex-1"
              />
              <Button
                onClick={handleSend}
                disabled={!input.trim() || isProcessing}
                size="icon"
              >
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            El agente puede usar herramientas de búsqueda, navegación web, ejecución de código, análisis de datos y procesar archivos
          </p>
        </div>
      </div>
    </div>
  );
}
