import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, MessageSquare, Clock, Zap, Database, TrendingUp } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Dashboard() {
  const [stats, setStats] = useState<any>(null);

  // En futuro: usar tRPC para obtener stats del servidor
  // const { data: stats } = trpc.metrics.getStats.useQuery();

  // Por ahora, stats simuladas
  useEffect(() => {
    setStats({
      totalConversations: 42,
      totalMessages: 1256,
      totalToolCalls: 487,
      averageResponseTime: 2.3,
      cacheHitRate: 34.5,
      memoryUsage: 156,
      topTools: [
        { name: "search_web", calls: 156, avgTime: 1.8 },
        { name: "generate_audio", calls: 89, avgTime: 2.1 },
        { name: "execute_code", calls: 67, avgTime: 3.4 },
        { name: "generate_project", calls: 45, avgTime: 5.2 },
        { name: "generate_video_from_text", calls: 34, avgTime: 15.6 },
      ],
      activityByDay: [
        { day: "Lun", messages: 45 },
        { day: "Mar", messages: 67 },
        { day: "Mié", messages: 89 },
        { day: "Jue", messages: 123 },
        { day: "Vie", messages: 98 },
        { day: "Sáb", messages: 34 },
        { day: "Dom", messages: 23 },
      ],
    });
  }, []);

  if (!stats) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Dashboard
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Estadísticas y métricas de uso del sistema
        </p>
      </div>

      {/* Tarjetas de resumen */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversaciones</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalConversations}</div>
            <p className="text-xs text-muted-foreground">
              +12% desde el mes pasado
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mensajes</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMessages}</div>
            <p className="text-xs text-muted-foreground">
              ~{Math.round(stats.totalMessages / stats.totalConversations)} por conversación
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tiempo Respuesta</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.averageResponseTime}s</div>
            <p className="text-xs text-muted-foreground">
              -15% más rápido que antes
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cache Hit Rate</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.cacheHitRate}%</div>
            <p className="text-xs text-muted-foreground">
              {stats.cacheHitRate > 30 ? "Excelente" : "Bueno"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs con diferentes vistas */}
      <Tabs defaultValue="tools" className="space-y-4">
        <TabsList>
          <TabsTrigger value="tools">Herramientas</TabsTrigger>
          <TabsTrigger value="activity">Actividad</TabsTrigger>
          <TabsTrigger value="memory">Memoria</TabsTrigger>
        </TabsList>

        {/* Tab de Herramientas */}
        <TabsContent value="tools" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Herramientas Más Usadas</CardTitle>
              <CardDescription>
                Top 5 herramientas por número de llamadas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats.topTools.map((tool: any, index: number) => (
                  <div key={tool.name} className="flex items-center">
                    <div className="w-8 text-center font-bold text-gray-400">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">{tool.name}</span>
                        <span className="text-sm text-gray-500">
                          {tool.calls} llamadas
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-purple-600 h-2 rounded-full"
                          style={{
                            width: `${(tool.calls / stats.topTools[0].calls) * 100}%`,
                          }}
                        ></div>
                      </div>
                      <span className="text-xs text-gray-500">
                        Tiempo promedio: {tool.avgTime}s
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Actividad */}
        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Actividad por Día</CardTitle>
              <CardDescription>
                Número de mensajes en los últimos 7 días
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {stats.activityByDay.map((day: any) => (
                  <div key={day.day} className="flex items-center">
                    <div className="w-16 text-sm font-medium">{day.day}</div>
                    <div className="flex-1">
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-6">
                        <div
                          className="bg-gradient-to-r from-purple-600 to-blue-600 h-6 rounded-full flex items-center justify-end pr-2"
                          style={{
                            width: `${(day.messages / Math.max(...stats.activityByDay.map((d: any) => d.messages))) * 100}%`,
                          }}
                        >
                          <span className="text-white text-sm font-medium">
                            {day.messages}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Memoria */}
        <TabsContent value="memory" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Uso de Memoria</CardTitle>
              <CardDescription>
                Estado del sistema de memoria y caché
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Database className="h-5 w-5 text-purple-600" />
                  <span className="font-medium">Memoria Total</span>
                </div>
                <span className="text-2xl font-bold">{stats.memoryUsage}MB</span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Caché de Respuestas</span>
                  <span className="font-medium">45MB</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: "29%" }}></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Memoria de Conversaciones</span>
                  <span className="font-medium">89MB</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full" style={{ width: "57%" }}></div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Sistema</span>
                  <span className="font-medium">22MB</span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: "14%" }}></div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Hit Rate de Caché</span>
                  <span className="text-xl font-bold text-green-600">
                    {stats.cacheHitRate}%
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  {stats.cacheHitRate > 30
                    ? "Rendimiento excelente"
                    : "Rendimiento bueno"}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
