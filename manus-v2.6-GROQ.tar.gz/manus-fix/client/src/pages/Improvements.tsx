import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ImprovementProposalCard } from "@/components/ImprovementProposalCard";
import { Loader2, Sparkles, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

export default function Improvements() {
  const { user, loading: authLoading } = useAuth();
  const { data: proposals, isLoading, refetch } = trpc.improvements.list.useQuery(undefined, {
    enabled: !!user,
  });

  const approveMutation = trpc.improvements.approve.useMutation({
    onSuccess: () => {
      toast.success("Propuesta aprobada exitosamente");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Error al aprobar: ${error.message}`);
    },
  });

  const rejectMutation = trpc.improvements.reject.useMutation({
    onSuccess: () => {
      toast.success("Propuesta rechazada");
      refetch();
    },
    onError: (error: any) => {
      toast.error(`Error al rechazar: ${error.message}`);
    },
  });

  const handleApprove = (id: string) => {
    approveMutation.mutate({ id });
  };

  const handleReject = (id: string) => {
    rejectMutation.mutate({ id });
  };

  if (authLoading || isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">Iniciar Sesión</h2>
          <p className="text-muted-foreground mb-6">
            Por favor, inicia sesión para ver las propuestas de mejora.
          </p>
          <Button asChild>
            <a href="/api/oauth/login">Iniciar Sesión</a>
          </Button>
        </Card>
      </div>
    );
  }

  const pendingProposals = proposals?.filter((p: any) => p.status === "pending") || [];
  const approvedProposals = proposals?.filter((p: any) => p.status === "approved") || [];
  const rejectedProposals = proposals?.filter((p: any) => p.status === "rejected") || [];
  const appliedProposals = proposals?.filter((p: any) => p.status === "applied") || [];

  return (
    <div className="min-h-screen bg-gradient-bg">
      {/* Header */}
      <header className="border-b bg-card/80 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-semibold">Propuestas de Mejora</h1>
              <p className="text-xs text-muted-foreground">Sistema de auto-mejora autónoma</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">{user.name}</span>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container max-w-6xl py-8">
        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="pending">
              Pendientes ({pendingProposals.length})
            </TabsTrigger>
            <TabsTrigger value="approved">
              Aprobadas ({approvedProposals.length})
            </TabsTrigger>
            <TabsTrigger value="applied">
              Aplicadas ({appliedProposals.length})
            </TabsTrigger>
            <TabsTrigger value="rejected">
              Rechazadas ({rejectedProposals.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-4 mt-6">
            {pendingProposals.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay propuestas pendientes de revisión
                </p>
              </Card>
            ) : (
              pendingProposals.map((proposal: any) => (
                <ImprovementProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  onApprove={handleApprove}
                  onReject={handleReject}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="approved" className="space-y-4 mt-6">
            {approvedProposals.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay propuestas aprobadas
                </p>
              </Card>
            ) : (
              approvedProposals.map((proposal: any) => (
                <ImprovementProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  onApprove={handleApprove}
                  onReject={handleReject}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="applied" className="space-y-4 mt-6">
            {appliedProposals.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay propuestas aplicadas todavía
                </p>
              </Card>
            ) : (
              appliedProposals.map((proposal: any) => (
                <ImprovementProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  onApprove={handleApprove}
                  onReject={handleReject}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="rejected" className="space-y-4 mt-6">
            {rejectedProposals.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-muted-foreground">
                  No hay propuestas rechazadas
                </p>
              </Card>
            ) : (
              rejectedProposals.map((proposal: any) => (
                <ImprovementProposalCard
                  key={proposal.id}
                  proposal={proposal}
                  onApprove={handleApprove}
                  onReject={handleReject}
                />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
