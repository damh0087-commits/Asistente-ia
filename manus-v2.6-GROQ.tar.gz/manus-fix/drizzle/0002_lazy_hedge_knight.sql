CREATE TABLE `improvement_proposals` (
	`id` varchar(64) NOT NULL,
	`userId` int NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`reasoning` text NOT NULL,
	`codeChanges` text NOT NULL,
	`benefits` text NOT NULL,
	`risks` text NOT NULL,
	`estimatedImpact` enum('low','medium','high') NOT NULL,
	`status` enum('pending','approved','rejected','applied','failed') NOT NULL DEFAULT 'pending',
	`approvedAt` timestamp,
	`appliedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `improvement_proposals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `improvement_proposals` ADD CONSTRAINT `improvement_proposals_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;