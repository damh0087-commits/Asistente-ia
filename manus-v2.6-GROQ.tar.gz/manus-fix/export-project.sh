#!/bin/bash

# Script de Exportación del Proyecto - Asistente IA Autónomo
# Este script empaqueta todo el código y documentación para transferencia

set -e  # Salir si hay errores

echo "==================================="
echo "Exportación del Proyecto"
echo "==================================="
echo ""

# Directorio de salida
OUTPUT_DIR="/home/ubuntu/manus-clone-export"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
EXPORT_NAME="manus-clone-${TIMESTAMP}"
EXPORT_PATH="${OUTPUT_DIR}/${EXPORT_NAME}"

# Crear directorio de exportación
echo "📁 Creando directorio de exportación..."
mkdir -p "${EXPORT_PATH}"

# Copiar código fuente
echo "📦 Copiando código fuente..."
cp -r /home/ubuntu/manus-clone/* "${EXPORT_PATH}/"

# Eliminar directorios y archivos excluidos
echo "🧹 Limpiando archivos excluidos..."
rm -rf "${EXPORT_PATH}/node_modules"
rm -rf "${EXPORT_PATH}/.git"
rm -rf "${EXPORT_PATH}/dist"
rm -rf "${EXPORT_PATH}/.manus-logs"
rm -f "${EXPORT_PATH}"/*.log
rm -f "${EXPORT_PATH}/.env"
rm -rf "${EXPORT_PATH}/tmp"

# Copiar documentación
echo "📄 Copiando documentación..."
cp /home/ubuntu/manus-clone/README.md "${EXPORT_PATH}/"
cp /home/ubuntu/manus-clone/TECHNICAL_DOCUMENTATION.md "${EXPORT_PATH}/"
cp /home/ubuntu/manus-clone/ARCHITECTURE_GUIDE.md "${EXPORT_PATH}/"
cp /home/ubuntu/manus-clone/DEVELOPMENT_MANUAL.md "${EXPORT_PATH}/"
cp /home/ubuntu/manus-clone/AI_CONTEXT.md "${EXPORT_PATH}/"
cp /home/ubuntu/manus-clone/todo.md "${EXPORT_PATH}/"

# Crear archivo de metadatos
echo "📝 Creando archivo de metadatos..."
cat > "${EXPORT_PATH}/EXPORT_METADATA.txt" << EOF
===========================================
METADATOS DE EXPORTACIÓN
===========================================

Fecha de exportación: $(date)
Versión del proyecto: 2.0
Exportado desde: Manus Platform

CONTENIDO DEL PAQUETE:
- Código fuente completo (client/, server/, drizzle/, shared/)
- Documentación técnica completa
- Guía de arquitectura con diagramas
- Manual de desarrollo
- Archivo de contexto para IAs
- Lista de tareas (todo.md)
- Configuración del proyecto (package.json, tsconfig.json, etc.)

ARCHIVOS EXCLUIDOS:
- node_modules/ (reinstalar con: pnpm install)
- dist/ (recompilar con: pnpm build)
- .git/ (historial de Git)
- .env (variables de entorno sensibles)
- Logs y archivos temporales

INSTRUCCIONES DE IMPORTACIÓN:
1. Extraer el paquete en un directorio
2. Ejecutar: pnpm install
3. Configurar variables de entorno (ver README.md)
4. Ejecutar: pnpm dev

DOCUMENTACIÓN:
- README.md: Visión general del proyecto
- TECHNICAL_DOCUMENTATION.md: Documentación técnica completa
- ARCHITECTURE_GUIDE.md: Arquitectura y patrones de diseño
- DEVELOPMENT_MANUAL.md: Manual de desarrollo paso a paso
- AI_CONTEXT.md: Contexto estructurado para IAs
- todo.md: Estado de funcionalidades

CONTACTO:
Creador: damh0087@gmail.com
Soporte Manus: https://help.manus.im

===========================================
EOF

# Crear archivo de instrucciones rápidas
echo "📋 Creando guía de inicio rápido..."
cat > "${EXPORT_PATH}/QUICK_START.md" << 'EOF'
# Guía de Inicio Rápido

## Para Desarrolladores Humanos

### 1. Instalación

```bash
# Instalar dependencias
pnpm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales
```

### 2. Desarrollo

```bash
# Iniciar servidor de desarrollo
pnpm dev

# Abrir navegador en http://localhost:3000
```

### 3. Base de Datos

```bash
# Aplicar migraciones
pnpm db:push
```

### 4. Testing

```bash
# Ejecutar tests
pnpm test
```

### 5. Producción

```bash
# Compilar para producción
pnpm build

# Iniciar servidor de producción
pnpm start
```

## Para IAs

### 1. Leer Documentación

Comienza leyendo en este orden:
1. `AI_CONTEXT.md` - Contexto estructurado
2. `TECHNICAL_DOCUMENTATION.md` - Documentación completa
3. `ARCHITECTURE_GUIDE.md` - Arquitectura del sistema
4. `DEVELOPMENT_MANUAL.md` - Instrucciones paso a paso

### 2. Explorar Código

Archivos clave para entender el sistema:
- `server/agent.ts` - Motor del agente autónomo
- `server/routers.ts` - API tRPC completa
- `server/tools/*.ts` - Herramientas del agente
- `drizzle/schema.ts` - Esquema de base de datos
- `client/src/pages/Chat.tsx` - Interfaz principal

### 3. Consultar Tareas

`todo.md` contiene el estado de todas las funcionalidades:
- `[x]` = Completado
- `[ ]` = Pendiente

### 4. Continuar Desarrollo

Sigue las mejores prácticas en `DEVELOPMENT_MANUAL.md`:
- Validar inputs con Zod
- Manejar errores con try-catch
- Escribir tests para nuevas funcionalidades
- Documentar funciones complejas
- Crear checkpoints antes de cambios grandes

## Estructura del Proyecto

```
manus-clone/
├── client/          # Frontend React
├── server/          # Backend Express + tRPC
├── drizzle/         # Esquema de base de datos
├── shared/          # Código compartido
├── docs/            # Documentación
└── package.json     # Dependencias
```

## Comandos Útiles

```bash
pnpm dev             # Desarrollo
pnpm build           # Compilar
pnpm start           # Producción
pnpm test            # Tests
pnpm check           # Verificar tipos
pnpm db:push         # Migrar base de datos
```

## Soporte

- Documentación completa: Ver archivos .md en la raíz
- Problemas conocidos: Ver AI_CONTEXT.md sección "Problemas Conocidos"
- Contacto: damh0087@gmail.com
- Soporte Manus: https://help.manus.im
EOF

# Crear lista de archivos
echo "📋 Generando lista de archivos..."
find "${EXPORT_PATH}" -type f > "${EXPORT_PATH}/FILE_LIST.txt"

# Comprimir todo
echo "🗜️  Comprimiendo paquete..."
cd "${OUTPUT_DIR}"
tar -czf "${EXPORT_NAME}.tar.gz" "${EXPORT_NAME}"

# Calcular checksum
echo "🔐 Calculando checksum..."
sha256sum "${EXPORT_NAME}.tar.gz" > "${EXPORT_NAME}.tar.gz.sha256"

# Limpiar directorio temporal
echo "🧹 Limpiando archivos temporales..."
rm -rf "${EXPORT_PATH}"

echo ""
echo "==================================="
echo "✅ Exportación completada"
echo "==================================="
echo ""
echo "Paquete creado: ${OUTPUT_DIR}/${EXPORT_NAME}.tar.gz"
echo "Checksum: ${OUTPUT_DIR}/${EXPORT_NAME}.tar.gz.sha256"
echo ""
echo "Para extraer:"
echo "  tar -xzf ${EXPORT_NAME}.tar.gz"
echo ""
echo "Tamaño del paquete:"
ls -lh "${OUTPUT_DIR}/${EXPORT_NAME}.tar.gz"
echo ""
