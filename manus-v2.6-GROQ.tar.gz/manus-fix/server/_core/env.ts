export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? process.env.SESSION_SECRET ?? "manus-secret-2025",
  databaseUrl: process.env.DATABASE_URL ?? "file:./data/manus.db",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  // ✅ Groq API (reemplaza Ollama local)
  groqApiKey: process.env.GROQ_API_KEY ?? "",
  groqApiUrl: process.env.OLLAMA_URL ?? "https://api.groq.com/openai/v1",
  groqModel: process.env.OLLAMA_MODEL ?? "llama-3.1-8b-instant",
};
