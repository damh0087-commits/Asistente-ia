import { ENV } from "./env";

export type Role = "system" | "user" | "assistant" | "tool" | "function";
export type TextContent = { type: "text"; text: string };
export type ImageContent = { type: "image_url"; image_url: { url: string; detail?: "auto" | "low" | "high" } };
export type FileContent = { type: "file_url"; file_url: { url: string; mime_type?: string } };
export type MessageContent = string | TextContent | ImageContent | FileContent;
export type Message = { role: Role; content: MessageContent | MessageContent[]; name?: string; tool_call_id?: string };
export type Tool = { type: "function"; function: { name: string; description?: string; parameters?: Record<string, unknown> } };
export type ToolChoicePrimitive = "none" | "auto" | "required";
export type ToolChoiceByName = { name: string };
export type ToolChoiceExplicit = { type: "function"; function: { name: string } };
export type ToolChoice = ToolChoicePrimitive | ToolChoiceByName | ToolChoiceExplicit;
export type JsonSchema = { name: string; schema: Record<string, unknown>; strict?: boolean };
export type OutputSchema = JsonSchema;
export type ResponseFormat = { type: "text" } | { type: "json_object" } | { type: "json_schema"; json_schema: JsonSchema };

export type InvokeParams = {
  messages: Message[];
  tools?: Tool[];
  toolChoice?: ToolChoice;
  tool_choice?: ToolChoice;
  maxTokens?: number;
  max_tokens?: number;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
};

export type ToolCall = { id: string; type: "function"; function: { name: string; arguments: string } };
export type InvokeResult = {
  id: string; created: number; model: string;
  choices: Array<{ index: number; message: { role: Role; content: string; tool_calls?: ToolCall[] }; finish_reason: string | null }>;
  usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
};

const normalizeMessage = (message: Message) => {
  const { role, name, tool_call_id } = message;
  const content = Array.isArray(message.content)
    ? message.content.map(p => typeof p === "string" ? p : (p as any).text || JSON.stringify(p)).join("\n")
    : typeof message.content === "string" ? message.content : JSON.stringify(message.content);
  return { role, name, tool_call_id, content };
};

/**
 * ✅ GROQ — reemplaza Ollama local, funciona en Railway sin localhost
 */
export async function invokeLLM(params: InvokeParams): Promise<InvokeResult> {
  const { messages, tools, toolChoice, tool_choice, maxTokens, max_tokens } = params;

  // Usar Groq si hay API key, si no intentar Manus Forge
  if (ENV.groqApiKey) {
    return await invokeLLMWithGroq(params);
  }

  // Fallback a Manus Forge si hay key
  if (ENV.forgeApiKey) {
    return await invokeLLMWithForge(params);
  }

  throw new Error("No hay API key configurada. Agrega GROQ_API_KEY en las variables de Railway.");
}

async function invokeLLMWithGroq(params: InvokeParams): Promise<InvokeResult> {
  const { messages, tools, toolChoice, tool_choice, maxTokens, max_tokens } = params;

  const payload: Record<string, unknown> = {
    model: ENV.groqModel,
    messages: messages.map(normalizeMessage),
    max_tokens: maxTokens || max_tokens || 2048,
    temperature: 0.7,
  };

  if (tools && tools.length > 0) {
    payload.tools = tools.map(t => ({
      type: "function",
      function: {
        name: t.function.name,
        description: t.function.description || "",
        parameters: t.function.parameters || { type: "object", properties: {} },
      }
    }));
    payload.tool_choice = "auto";
  }

  const response = await fetch(`${ENV.groqApiUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${ENV.groqApiKey}`,
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(60000),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Groq API error: ${response.status} — ${err}`);
  }

  const data = await response.json() as InvokeResult;
  console.log(`✅ Groq respondió: ${data.model} (${data.usage?.total_tokens || 0} tokens)`);
  return data;
}

async function invokeLLMWithForge(params: InvokeParams): Promise<InvokeResult> {
  const { messages, tools, maxTokens, max_tokens } = params;

  const payload: Record<string, unknown> = {
    model: "gemini-2.5-flash",
    messages: messages.map(normalizeMessage),
    max_tokens: maxTokens || max_tokens || 2048,
  };

  if (tools && tools.length > 0) {
    payload.tools = tools;
    payload.tool_choice = "auto";
  }

  const forgeUrl = ENV.forgeApiUrl
    ? `${ENV.forgeApiUrl.replace(/\/$/, "")}/v1/chat/completions`
    : "https://forge.manus.im/v1/chat/completions";

  const response = await fetch(forgeUrl, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "authorization": `Bearer ${ENV.forgeApiKey}`,
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Forge API error: ${response.status} — ${err}`);
  }

  return await response.json() as InvokeResult;
}

export function setLLMMode(mode: "ollama" | "forge"): void {
  console.log(`Modo LLM: ${mode}`);
}

export function getLLMMode(): "ollama" | "forge" {
  return "ollama";
}
