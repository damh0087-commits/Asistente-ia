/**
 * SISTEMA DE AUTENTICACIÓN LOCAL SIMPLE
 * 
 * Reemplaza OAuth de Manus con autenticación local
 * - Registro de usuarios
 * - Login con email/password
 * - Sin dependencias externas
 */

import type { Express, Request, Response } from "express";
import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./cookies";
import * as db from "../db";
import { nanoid } from "nanoid";
import { createHash } from "crypto";

// Hash simple de contraseña (en producción usa bcrypt)
function hashPassword(password: string): string {
  return createHash("sha256").update(password + "SALT_SECRET").digest("hex");
}

// Genera un token de sesión
function generateSessionToken(): string {
  return nanoid(64);
}

// Store de sesiones en memoria (en producción usa Redis o DB)
const sessions = new Map<string, { openId: string; expiresAt: Date }>();

/**
 * Registra rutas de autenticación local
 */
export function registerLocalAuthRoutes(app: Express) {
  
  // ========================================
  // REGISTRO DE USUARIO
  // ========================================
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, name } = req.body;

      // Validaciones
      if (!email || !password) {
        res.status(400).json({ 
          error: "Email y contraseña son requeridos" 
        });
        return;
      }

      if (password.length < 6) {
        res.status(400).json({ 
          error: "La contraseña debe tener al menos 6 caracteres" 
        });
        return;
      }

      // Verificar si el usuario ya existe
      const database = await db.getDb();
      if (!database) {
        res.status(500).json({ error: "Base de datos no disponible" });
        return;
      }

      const existingUser = await database.query.users.findFirst({
        where: (users, { eq }) => eq(users.email, email),
      });

      if (existingUser) {
        res.status(400).json({ 
          error: "El email ya está registrado" 
        });
        return;
      }

      // Crear usuario
      const openId = `local_${nanoid(16)}`;
      const hashedPassword = hashPassword(password);

      await db.upsertUser({
        openId,
        email,
        name: name || email.split("@")[0],
        loginMethod: "local",
        lastSignedIn: new Date(),
        // Guardamos el hash en un campo custom (necesitarás agregarlo al schema)
        // Por ahora lo guardamos en openId con prefijo
        openId: `${openId}:${hashedPassword}`,
      });

      // Crear sesión
      const sessionToken = generateSessionToken();
      sessions.set(sessionToken, {
        openId,
        expiresAt: new Date(Date.now() + ONE_YEAR_MS),
      });

      // Establecer cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { 
        ...cookieOptions, 
        maxAge: ONE_YEAR_MS 
      });

      res.json({
        success: true,
        user: {
          email,
          name: name || email.split("@")[0],
        },
      });
    } catch (error) {
      console.error("[LocalAuth] Register failed", error);
      res.status(500).json({ 
        error: "Error al registrar usuario" 
      });
    }
  });

  // ========================================
  // LOGIN
  // ========================================
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;

      // Validaciones
      if (!email || !password) {
        res.status(400).json({ 
          error: "Email y contraseña son requeridos" 
        });
        return;
      }

      // Buscar usuario
      const database = await db.getDb();
      if (!database) {
        res.status(500).json({ error: "Base de datos no disponible" });
        return;
      }

      const user = await database.query.users.findFirst({
        where: (users, { eq }) => eq(users.email, email),
      });

      if (!user) {
        res.status(401).json({ 
          error: "Email o contraseña incorrectos" 
        });
        return;
      }

      // Verificar contraseña
      const [storedOpenId, storedHash] = user.openId.split(":");
      const inputHash = hashPassword(password);

      if (storedHash !== inputHash) {
        res.status(401).json({ 
          error: "Email o contraseña incorrectos" 
        });
        return;
      }

      // Actualizar último login
      await database
        .update(db.users)
        .set({ lastSignedIn: new Date() })
        .where(db.eq(db.users.openId, user.openId));

      // Crear sesión
      const sessionToken = generateSessionToken();
      sessions.set(sessionToken, {
        openId: storedOpenId,
        expiresAt: new Date(Date.now() + ONE_YEAR_MS),
      });

      // Establecer cookie
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { 
        ...cookieOptions, 
        maxAge: ONE_YEAR_MS 
      });

      res.json({
        success: true,
        user: {
          email: user.email,
          name: user.name,
        },
      });
    } catch (error) {
      console.error("[LocalAuth] Login failed", error);
      res.status(500).json({ 
        error: "Error al iniciar sesión" 
      });
    }
  });

  // ========================================
  // LOGOUT
  // ========================================
  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    try {
      const sessionToken = req.cookies[COOKIE_NAME];

      if (sessionToken) {
        sessions.delete(sessionToken);
      }

      res.clearCookie(COOKIE_NAME);
      res.json({ success: true });
    } catch (error) {
      console.error("[LocalAuth] Logout failed", error);
      res.status(500).json({ 
        error: "Error al cerrar sesión" 
      });
    }
  });

  // ========================================
  // VERIFICAR SESIÓN (ME)
  // ========================================
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      const sessionToken = req.cookies[COOKIE_NAME];

      if (!sessionToken) {
        res.status(401).json({ error: "No autenticado" });
        return;
      }

      const session = sessions.get(sessionToken);

      if (!session || session.expiresAt < new Date()) {
        sessions.delete(sessionToken);
        res.clearCookie(COOKIE_NAME);
        res.status(401).json({ error: "Sesión expirada" });
        return;
      }

      // Buscar usuario
      const database = await db.getDb();
      if (!database) {
        res.status(500).json({ error: "Base de datos no disponible" });
        return;
      }

      const user = await database.query.users.findFirst({
        where: (users, { like }) => like(users.openId, `${session.openId}%`),
      });

      if (!user) {
        sessions.delete(sessionToken);
        res.clearCookie(COOKIE_NAME);
        res.status(401).json({ error: "Usuario no encontrado" });
        return;
      }

      res.json({
        openId: session.openId,
        email: user.email,
        name: user.name,
      });
    } catch (error) {
      console.error("[LocalAuth] Me check failed", error);
      res.status(500).json({ 
        error: "Error al verificar sesión" 
      });
    }
  });
}

/**
 * Middleware para proteger rutas (usar en tRPC)
 */
export async function requireAuth(req: Request): Promise<{ openId: string } | null> {
  const sessionToken = req.cookies[COOKIE_NAME];

  if (!sessionToken) {
    return null;
  }

  const session = sessions.get(sessionToken);

  if (!session || session.expiresAt < new Date()) {
    sessions.delete(sessionToken);
    return null;
  }

  return { openId: session.openId };
}
