import { invokeLLM } from "./_core/llm";
import { searchWeb, searchToolDefinition } from "./tools/search";
import {
  navigateToUrl,
  extractData,
  navigateToolDefinition,
  extractDataToolDefinition,
} from "./tools/browser";
import {
  executeCode,
  codeExecutorToolDefinition,
} from "./tools/codeExecutor";
import {
  analyzeData,
  dataAnalyzerToolDefinition,
} from "./tools/dataAnalyzer";
import {
  readFileFromWorkspace,
  writeFileToWorkspace,
  listFilesInWorkspace,
  fileReadToolDefinition,
  fileWriteToolDefinition,
  fileListToolDefinition,
} from "./tools/fileSystem";
// ✅ NUEVAS HERRAMIENTAS AGREGADAS
import {
  generateTextToSpeech,
  textToSpeechToolDefinition,
} from "./tools/textToSpeech";
import {
  generateProject,
  generateProjectToolDefinition,
} from "./tools/projectGenerator";
import {
  executeSelfImprovement,
  selfImprovementTool,
} from "./tools/selfImprovement";
import {
  generateTextToVideo,
  textToVideoToolDefinition,
} from "./tools/textToVideo";
// ✅ NUEVOS SISTEMAS
import { executeToolWithCache } from "./toolCache";
import { validateToolInput } from "./toolValidation";
// ✅ SISTEMAS V2.4 - MEMORIA Y VELOCIDAD
import {
  initializeMemory,
  addMessageToMemory,
  getOptimizedContext,
  extractFacts,
  getMemoryStats,
} from "./memorySystem";
import {
  getCachedResponse,
  cacheResponse,
  preloadCommonResponses,
  getCacheStats,
} from "./responseCache";
// ❌ REMOVIDOS IMPORTS DE HERRAMIENTAS NO GRATUITAS:
// - imageGenerator (requiere API paga)
// - audioTranscriber (requiere API paga)
// - videoGenerator (requiere API paga)
// - webScraper (duplicado)
// - selfImprovement (peligroso)

export interface Message {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
}

/**
 * Herramientas disponibles para el agente
 * ✅ TODAS 100% GRATUITAS
 */
const AVAILABLE_TOOLS = [
  searchToolDefinition,
  navigateToolDefinition,
  extractDataToolDefinition,
  codeExecutorToolDefinition,
  dataAnalyzerToolDefinition,
  fileReadToolDefinition,
  fileWriteToolDefinition,
  fileListToolDefinition,
  // ✅ HERRAMIENTAS V2.1
  textToSpeechToolDefinition,     // Generación de audio/voz desde texto
  generateProjectToolDefinition,   // Generación de proyectos completos
  selfImprovementTool,             // Auto-mejora segura del sistema
  // ✅ NUEVA HERRAMIENTA V2.3
  textToVideoToolDefinition,       // Generación de video desde texto (SIN GPU)
];

/**
 * Mapa de funciones de herramientas
 * ✅ TODAS 100% GRATUITAS
 */
const TOOL_FUNCTIONS: Record<string, (input: any) => Promise<any>> = {
  search_web: searchWeb,
  navigate_to_url: navigateToUrl,
  extract_data: extractData,
  execute_code: executeCode,
  analyze_data: analyzeData,
  read_file: readFileFromWorkspace,
  write_file: writeFileToWorkspace,
  list_files: listFilesInWorkspace,
  // ✅ FUNCIONES V2.1
  generate_audio: generateTextToSpeech,           // TTS con pyttsx3
  generate_project: generateProject,               // Proyectos completos
  propose_self_improvement: executeSelfImprovement, // Auto-mejora segura
  // ✅ NUEVA FUNCIÓN V2.3
  generate_video_from_text: generateTextToVideo,   // Video desde texto (SIN GPU)
};

export interface AgentStep {
  type: "thought" | "tool_call" | "tool_result" | "answer";
  content: string;
  toolName?: string;
  toolInput?: any;
  toolOutput?: any;
  timestamp: number;
}

export interface AgentExecutionResult {
  answer: string;
  steps: AgentStep[];
  conversationHistory: Message[];
}

/**
 * Ejecuta una herramienta con reintentos automáticos y caché
 */
async function executeToolWithRetry(
  toolName: string,
  toolInput: any,
  toolFunction: (input: any) => Promise<any>,
  maxRetries: number = 3
): Promise<any> {
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      // Ejecutar con caché automático
      return await executeToolWithCache(
        toolName,
        toolInput,
        () => toolFunction(toolInput),
        {
          avgExecutionTime: attempt > 1 ? 2000 : undefined, // Estimar tiempo si es reintento
        }
      );
    } catch (error) {
      lastError = error as Error;

      // Si es error de validación, no reintentar
      if (error instanceof Error && error.message.includes("Parámetros inválidos")) {
        throw error;
      }

      // Si es el último intento, lanzar error
      if (attempt === maxRetries) {
        break;
      }

      // Esperar antes de reintentar (backoff exponencial)
      const waitTime = Math.min(1000 * Math.pow(2, attempt - 1), 5000);
      console.log(`⚠️  Intento ${attempt} falló para ${toolName}, reintentando en ${waitTime}ms...`);
      await new Promise((resolve) => setTimeout(resolve, waitTime));
    }
  }

  throw lastError || new Error(`Fallo al ejecutar ${toolName} después de ${maxRetries} intentos`);
}

/**
 * Sistema de prompt mejorado para el agente
 */
const SYSTEM_PROMPT = `Eres un asistente de IA autónomo altamente capaz. Tu objetivo es ayudar al usuario a completar tareas complejas de manera independiente usando herramientas especializadas.

🛠️ HERRAMIENTAS DISPONIBLES (100% GRATUITAS):
- search_web: Buscar información actualizada en la web (DuckDuckGo mejorado)
- navigate_to_url: Navegar a una URL y extraer su contenido de texto
- extract_data: Extraer datos específicos de páginas web con selectores CSS
- execute_code: Ejecutar código Python o JavaScript en un entorno seguro
- analyze_data: Analizar datos con Pandas (estadísticas, filtros, gráficos)
- read_file: Leer archivos del workspace
- write_file: Escribir archivos en el workspace
- list_files: Listar archivos disponibles en el workspace
- generate_audio: Generar audio/voz desde texto (TTS multiidioma) - ¡V2.1!
- generate_project: Generar proyectos completos de software (React, Express, Android, etc.) - ¡V2.1!
- propose_self_improvement: Buscar y proponer mejoras seguras al sistema - ¡V2.1!
- generate_video_from_text: Generar videos profesionales desde texto con audio narrado - ¡V2.3 NUEVO!

📋 PROCESO DE RAZONAMIENTO (sigue estos pasos):
1. ANÁLISIS: ¿Qué pide exactamente el usuario?
2. PLANIFICACIÓN: ¿Qué herramientas necesito y en qué orden?
3. EJECUCIÓN: Usa las herramientas paso a paso
4. VERIFICACIÓN: ¿Los resultados son correctos? ¿Necesito hacer algo más?
5. RESPUESTA: Proporciona una respuesta completa y útil

⚠️ REGLAS IMPORTANTES:
- USA SOLO las herramientas listadas arriba, no inventes otras
- Si una herramienta falla, intenta un enfoque alternativo (sé creativo)
- Verifica SIEMPRE los resultados antes de continuar
- Si los parámetros son inválidos, lee el mensaje de error y corrígelos
- Explica tu razonamiento al usuario de manera clara
- Sé persistente: no te rindas ante el primer error

💡 CONSEJOS PARA NUEVAS CAPACIDADES:
- Para audio: Puedes crear narraciones, podcasts, tutoriales en audio, mensajes de voz
- Para proyectos: Genera estructuras completas (React apps, APIs REST, apps Android con instrucciones de compilación, Chrome extensions, etc.)
- Para auto-mejora: Busca en GitHub mejoras reales aplicables, valida en sandbox, espera aprobación del usuario
- Para videos: Crea videos con narración automática, usa estilos 'ken-burns' para efecto profesional, 'slideshow' para múltiples imágenes, 'text-overlay' para texto animado

Recuerda: Eres inteligente, creativo y persistente. ¡Puedes resolver problemas complejos!`;

/**
 * Ejecuta el agente autónomo
 */
export async function executeAgent(
  userMessage: string,
  conversationHistory: Message[] = [],
  maxIterations: number = 20 // ✅ AUMENTADO de 10 a 20 para tareas más complejas
): Promise<AgentExecutionResult> {
  const steps: AgentStep[] = [];
  const messages: Message[] = [
    { role: "system", content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: "user", content: userMessage },
  ];

  let iteration = 0;
  let finalAnswer = "";

  while (iteration < maxIterations) {
    iteration++;

    try {
      // Paso 1: Obtener respuesta del LLM
      const response = await invokeLLM({
        messages: messages.map((m) => ({
          role: m.role as any,
          content: m.content,
        })),
        tools: AVAILABLE_TOOLS as any,
        tool_choice: "auto",
      });

      if (!response.choices || response.choices.length === 0) {
        console.error("Respuesta del LLM sin choices:", JSON.stringify(response, null, 2));
        throw new Error("No se recibieron choices del LLM");
      }
      
      const assistantMessage = response.choices[0]?.message;
      if (!assistantMessage) {
        throw new Error("No se recibió respuesta del LLM");
      }

      // Agregar mensaje del asistente
      const content = typeof assistantMessage.content === "string" 
        ? assistantMessage.content 
        : JSON.stringify(assistantMessage.content);
      
      messages.push({
        role: "assistant",
        content: content || "",
      });

      // Paso 2: Verificar si hay llamadas a herramientas
      if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
        // Ejecutar cada herramienta
        for (const toolCall of assistantMessage.tool_calls) {
          const toolName = toolCall.function.name;
          const toolInput = JSON.parse(toolCall.function.arguments);

          steps.push({
            type: "tool_call",
            content: `Usando herramienta: ${toolName}`,
            toolName,
            toolInput,
            timestamp: Date.now(),
          });

          try {
            // Ejecutar la herramienta
            const toolFunction = TOOL_FUNCTIONS[toolName];
            if (!toolFunction) {
              throw new Error(`Herramienta no encontrada: ${toolName}`);
            }

            // ✅ EJECUTAR CON CACHÉ Y REINTENTOS
            const toolOutput = await executeToolWithRetry(
              toolName,
              toolInput,
              toolFunction
            );

            steps.push({
              type: "tool_result",
              content: `Resultado de ${toolName}`,
              toolName,
              toolOutput,
              timestamp: Date.now(),
            });

            // Agregar resultado a la conversación
            messages.push({
              role: "tool",
              content: JSON.stringify(toolOutput),
            });
          } catch (error) {
            const errorMessage =
              error instanceof Error ? error.message : "Error desconocido";

            // ✅ MEJORADO: Mensaje de error más claro para el LLM
            const errorForLLM = `❌ Error en ${toolName}: ${errorMessage}\n\n` +
              `Sugerencias:\n` +
              `- Verifica que los parámetros sean correctos\n` +
              `- Si es un error de red, espera un momento e intenta de nuevo\n` +
              `- Si el error persiste, intenta un enfoque alternativo`;

            steps.push({
              type: "tool_result",
              content: errorForLLM,
              toolName,
              toolOutput: { error: errorMessage },
              timestamp: Date.now(),
            });

            messages.push({
              role: "tool",
              content: JSON.stringify({ 
                error: errorMessage,
                suggestions: "Verifica los parámetros o intenta un enfoque alternativo"
              }),
            });
          }
        }
      } else {
        // No hay más herramientas que ejecutar, tenemos la respuesta final
        finalAnswer = typeof assistantMessage.content === "string"
          ? assistantMessage.content
          : JSON.stringify(assistantMessage.content) || "No se generó respuesta";

        steps.push({
          type: "answer",
          content: finalAnswer,
          timestamp: Date.now(),
        });

        break;
      }

      // Verificar si hemos alcanzado el límite de iteraciones
      if (iteration >= maxIterations) {
        finalAnswer =
          "He alcanzado el límite de iteraciones. Aquí está lo que he logrado hasta ahora:\n\n" +
          (assistantMessage.content || "No se pudo completar la tarea completamente.");

        steps.push({
          type: "answer",
          content: finalAnswer,
          timestamp: Date.now(),
        });
      }
    } catch (error) {
      console.error("Error en iteración del agente:", error);

      // Si es la primera iteración y falla, retornar error
      if (iteration === 1) {
        finalAnswer = `Lo siento, ocurrió un error al procesar tu solicitud: ${
          error instanceof Error ? error.message : "Error desconocido"
        }`;

        steps.push({
          type: "answer",
          content: finalAnswer,
          timestamp: Date.now(),
        });

        break;
      }

      // Si no es la primera iteración, intentar continuar
      continue;
    }
  }

  return {
    answer: finalAnswer,
    steps,
    conversationHistory: messages,
  };
}

/**
 * Ejecuta el agente con streaming de pasos
 */
export async function* executeAgentStreaming(
  userMessage: string,
  conversationHistory: Message[] = [],
  maxIterations: number = 20 // ✅ AUMENTADO de 10 a 20
): AsyncGenerator<AgentStep> {
  const messages: Message[] = [
    { role: "system", content: SYSTEM_PROMPT },
    ...conversationHistory,
    { role: "user", content: userMessage },
  ];

  let iteration = 0;

  while (iteration < maxIterations) {
    iteration++;

    yield {
      type: "thought",
      content: `Iteración ${iteration}: Analizando y planificando...`,
      timestamp: Date.now(),
    };

    try {
      const response = await invokeLLM({
        messages: messages.map((m) => ({
          role: m.role as any,
          content: m.content,
        })),
        tools: AVAILABLE_TOOLS as any,
        tool_choice: "auto",
      });

      if (!response.choices || response.choices.length === 0) {
        console.error("Respuesta del LLM sin choices:", JSON.stringify(response, null, 2));
        throw new Error("No se recibieron choices del LLM");
      }
      
      const assistantMessage = response.choices[0]?.message;
      if (!assistantMessage) {
        throw new Error("No se recibió respuesta del LLM");
      }

      const content = typeof assistantMessage.content === "string" 
        ? assistantMessage.content 
        : JSON.stringify(assistantMessage.content);
      
      messages.push({
        role: "assistant",
        content: content || "",
      });

      if (assistantMessage.tool_calls && assistantMessage.tool_calls.length > 0) {
        for (const toolCall of assistantMessage.tool_calls) {
          const toolName = toolCall.function.name;
          const toolInput = JSON.parse(toolCall.function.arguments);

          yield {
            type: "tool_call",
            content: `Ejecutando: ${toolName}`,
            toolName,
            toolInput,
            timestamp: Date.now(),
          };

          try {
            const toolFunction = TOOL_FUNCTIONS[toolName];
            if (!toolFunction) {
              throw new Error(`Herramienta no encontrada: ${toolName}`);
            }

            // ✅ EJECUTAR CON CACHÉ Y REINTENTOS
            const toolOutput = await executeToolWithRetry(
              toolName,
              toolInput,
              toolFunction
            );

            yield {
              type: "tool_result",
              content: `Completado: ${toolName}`,
              toolName,
              toolOutput,
              timestamp: Date.now(),
            };

            messages.push({
              role: "tool",
              content: JSON.stringify(toolOutput),
            });
          } catch (error) {
            const errorMessage =
              error instanceof Error ? error.message : "Error desconocido";

            const errorForLLM = `❌ Error en ${toolName}: ${errorMessage}\n\n` +
              `Sugerencias: Verifica parámetros o intenta un enfoque alternativo`;

            yield {
              type: "tool_result",
              content: errorForLLM,
              toolName,
              toolOutput: { error: errorMessage },
              timestamp: Date.now(),
            });

            messages.push({
              role: "tool",
              content: JSON.stringify({ 
                error: errorMessage,
                suggestions: "Verifica los parámetros o intenta un enfoque alternativo"
              }),
            });
          }
        }
      } else {
        const answerContent = typeof assistantMessage.content === "string"
          ? assistantMessage.content
          : JSON.stringify(assistantMessage.content);
        
        yield {
          type: "answer",
          content: answerContent || "No se generó respuesta",
          timestamp: Date.now(),
        };
        break;
      }

      if (iteration >= maxIterations) {
        yield {
          type: "answer",
          content:
            "Límite de iteraciones alcanzado. Tarea parcialmente completada.",
          timestamp: Date.now(),
        };
      }
    } catch (error) {
      yield {
        type: "answer",
        content: `Error: ${error instanceof Error ? error.message : "Error desconocido"}`,
        timestamp: Date.now(),
      };
      break;
    }
  }
}
