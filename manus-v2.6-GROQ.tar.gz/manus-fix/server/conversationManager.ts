/**
 * SISTEMA DE GESTIÓN DE CONVERSACIONES MÚLTIPLES
 * 
 * Funcionalidades:
 * - Crear, renombrar, eliminar conversaciones
 * - Buscar en historial
 * - Exportar conversaciones (JSON, TXT, MD)
 * - Favoritos y etiquetas
 * - Estadísticas por conversación
 */

import * as db from "./db";
import { nanoid } from "nanoid";

export interface ConversationMetadata {
  id: number;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  messageCount: number;
  favorite: boolean;
  tags: string[];
  summary?: string;
}

export interface SearchResult {
  conversationId: number;
  conversationTitle: string;
  messageId: number;
  messageContent: string;
  messageRole: string;
  timestamp: Date;
  highlights: string[];
}

/**
 * Crear nueva conversación
 */
export async function createConversation(
  userId: number,
  title?: string
): Promise<number> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  const defaultTitle = `Chat ${new Date().toLocaleDateString()}`;

  const result = await database.insert(db.conversations).values({
    userId,
    title: title || defaultTitle,
  });

  console.log(`✅ Created conversation: ${title || defaultTitle}`);

  return Number(result.insertId);
}

/**
 * Renombrar conversación
 */
export async function renameConversation(
  conversationId: number,
  newTitle: string
): Promise<void> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  await database
    .update(db.conversations)
    .set({ title: newTitle })
    .where(db.eq(db.conversations.id, conversationId));

  console.log(`✅ Renamed conversation ${conversationId} to: ${newTitle}`);
}

/**
 * Eliminar conversación (y todos sus mensajes)
 */
export async function deleteConversation(
  conversationId: number
): Promise<void> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  // Los mensajes se eliminan en cascada gracias al schema
  await database
    .delete(db.conversations)
    .where(db.eq(db.conversations.id, conversationId));

  console.log(`🗑️  Deleted conversation ${conversationId}`);
}

/**
 * Obtener todas las conversaciones de un usuario
 */
export async function getUserConversations(
  userId: number
): Promise<ConversationMetadata[]> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  const conversations = await database.query.conversations.findMany({
    where: (conversations, { eq }) => eq(conversations.userId, userId),
    orderBy: (conversations, { desc }) => [desc(conversations.createdAt)],
    with: {
      messages: true,
    },
  });

  return conversations.map((conv) => ({
    id: conv.id,
    title: conv.title,
    createdAt: conv.createdAt,
    updatedAt: conv.updatedAt,
    messageCount: conv.messages?.length || 0,
    favorite: false, // TODO: Agregar campo a schema
    tags: [], // TODO: Agregar campo a schema
  }));
}

/**
 * Buscar en el historial de conversaciones
 */
export async function searchConversations(
  userId: number,
  query: string
): Promise<SearchResult[]> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  // Obtener todas las conversaciones del usuario
  const conversations = await database.query.conversations.findMany({
    where: (conversations, { eq }) => eq(conversations.userId, userId),
    with: {
      messages: true,
    },
  });

  const results: SearchResult[] = [];
  const queryLower = query.toLowerCase();

  conversations.forEach((conv) => {
    // Buscar en título
    if (conv.title.toLowerCase().includes(queryLower)) {
      results.push({
        conversationId: conv.id,
        conversationTitle: conv.title,
        messageId: 0,
        messageContent: `Conversación: ${conv.title}`,
        messageRole: "system",
        timestamp: conv.createdAt,
        highlights: [conv.title],
      });
    }

    // Buscar en mensajes
    conv.messages?.forEach((msg) => {
      if (msg.content.toLowerCase().includes(queryLower)) {
        // Extraer contexto alrededor de la coincidencia
        const index = msg.content.toLowerCase().indexOf(queryLower);
        const start = Math.max(0, index - 50);
        const end = Math.min(msg.content.length, index + query.length + 50);
        const highlight = msg.content.substring(start, end);

        results.push({
          conversationId: conv.id,
          conversationTitle: conv.title,
          messageId: msg.id,
          messageContent: msg.content,
          messageRole: msg.role,
          timestamp: msg.createdAt,
          highlights: [highlight],
        });
      }
    });
  });

  return results;
}

/**
 * Exportar conversación en diferentes formatos
 */
export async function exportConversation(
  conversationId: number,
  format: "json" | "txt" | "md" = "json"
): Promise<string> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  const conversation = await database.query.conversations.findFirst({
    where: (conversations, { eq }) => eq(conversations.id, conversationId),
    with: {
      messages: {
        orderBy: (messages, { asc }) => [asc(messages.createdAt)],
      },
    },
  });

  if (!conversation) {
    throw new Error("Conversation not found");
  }

  switch (format) {
    case "json":
      return exportAsJSON(conversation);
    case "txt":
      return exportAsTXT(conversation);
    case "md":
      return exportAsMarkdown(conversation);
    default:
      throw new Error(`Unknown format: ${format}`);
  }
}

function exportAsJSON(conversation: any): string {
  return JSON.stringify(
    {
      title: conversation.title,
      createdAt: conversation.createdAt,
      updatedAt: conversation.updatedAt,
      messages: conversation.messages.map((msg: any) => ({
        role: msg.role,
        content: msg.content,
        createdAt: msg.createdAt,
      })),
    },
    null,
    2
  );
}

function exportAsTXT(conversation: any): string {
  let output = `=== ${conversation.title} ===\n`;
  output += `Creado: ${conversation.createdAt.toLocaleString()}\n\n`;

  conversation.messages.forEach((msg: any) => {
    const role =
      msg.role === "user"
        ? "Usuario"
        : msg.role === "assistant"
          ? "Asistente"
          : "Sistema";
    output += `[${role}] ${msg.createdAt.toLocaleTimeString()}\n`;
    output += `${msg.content}\n\n`;
  });

  return output;
}

function exportAsMarkdown(conversation: any): string {
  let output = `# ${conversation.title}\n\n`;
  output += `**Creado:** ${conversation.createdAt.toLocaleString()}\n`;
  output += `**Actualizado:** ${conversation.updatedAt.toLocaleString()}\n\n`;
  output += `---\n\n`;

  conversation.messages.forEach((msg: any) => {
    if (msg.role === "user") {
      output += `### 👤 Usuario\n\n`;
    } else if (msg.role === "assistant") {
      output += `### 🤖 Asistente\n\n`;
    } else {
      output += `### ⚙️ Sistema\n\n`;
    }

    output += `${msg.content}\n\n`;
    output += `_${msg.createdAt.toLocaleString()}_\n\n`;
    output += `---\n\n`;
  });

  return output;
}

/**
 * Obtener estadísticas de una conversación
 */
export async function getConversationStats(conversationId: number): Promise<{
  messageCount: number;
  userMessages: number;
  assistantMessages: number;
  toolMessages: number;
  firstMessage: Date;
  lastMessage: Date;
  averageResponseTime: number; // TODO: Calcular si guardamos timestamps
  totalTokensEstimate: number;
}> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  const conversation = await database.query.conversations.findFirst({
    where: (conversations, { eq }) => eq(conversations.id, conversationId),
    with: {
      messages: {
        orderBy: (messages, { asc }) => [asc(messages.createdAt)],
      },
    },
  });

  if (!conversation || !conversation.messages) {
    throw new Error("Conversation not found");
  }

  const messages = conversation.messages;
  const userMessages = messages.filter((m) => m.role === "user").length;
  const assistantMessages = messages.filter(
    (m) => m.role === "assistant"
  ).length;
  const toolMessages = messages.filter((m) => m.role === "tool").length;

  // Estimar tokens (aproximado: 4 chars = 1 token)
  const totalTokensEstimate = messages.reduce((sum, msg) => {
    return sum + Math.ceil(msg.content.length / 4);
  }, 0);

  return {
    messageCount: messages.length,
    userMessages,
    assistantMessages,
    toolMessages,
    firstMessage: messages[0]?.createdAt || new Date(),
    lastMessage: messages[messages.length - 1]?.createdAt || new Date(),
    averageResponseTime: 0, // TODO
    totalTokensEstimate,
  };
}

/**
 * Marcar conversación como favorita
 */
export async function toggleFavorite(
  conversationId: number
): Promise<boolean> {
  // TODO: Agregar campo 'favorite' al schema de conversations
  console.log(`TODO: Toggle favorite for conversation ${conversationId}`);
  return true;
}

/**
 * Agregar etiqueta a conversación
 */
export async function addTag(
  conversationId: number,
  tag: string
): Promise<void> {
  // TODO: Agregar tabla de tags
  console.log(`TODO: Add tag '${tag}' to conversation ${conversationId}`);
}

/**
 * Duplicar conversación
 */
export async function duplicateConversation(
  conversationId: number,
  userId: number
): Promise<number> {
  const database = await db.getDb();
  if (!database) throw new Error("Database not available");

  const original = await database.query.conversations.findFirst({
    where: (conversations, { eq }) => eq(conversations.id, conversationId),
    with: {
      messages: true,
    },
  });

  if (!original) {
    throw new Error("Conversation not found");
  }

  // Crear nueva conversación
  const newConvId = await createConversation(
    userId,
    `${original.title} (copia)`
  );

  // Copiar mensajes
  if (original.messages) {
    for (const msg of original.messages) {
      await database.insert(db.messages).values({
        conversationId: newConvId,
        role: msg.role,
        content: msg.content,
      });
    }
  }

  console.log(`✅ Duplicated conversation ${conversationId} → ${newConvId}`);

  return newConvId;
}
