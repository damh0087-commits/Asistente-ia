import { storagePut } from "./storage";
import { createGeneratedFile } from "./db";
import { randomBytes } from "crypto";
import { readFile } from "fs/promises";

/**
 * Sube un archivo al almacenamiento S3 y registra en la base de datos
 */
export async function uploadGeneratedFile(params: {
  conversationId: number;
  messageId?: number;
  filename: string;
  content: Buffer | string;
  mimeType?: string;
}): Promise<{ url: string; fileKey: string }> {
  const { conversationId, messageId, filename, content, mimeType } = params;

  // Generar clave única para el archivo
  const randomSuffix = randomBytes(8).toString("hex");
  const fileKey = `agent-files/${conversationId}/${filename}-${randomSuffix}`;

  // Subir a S3
  const { url } = await storagePut(
    fileKey,
    typeof content === "string" ? Buffer.from(content, "utf-8") : content,
    mimeType || "application/octet-stream"
  );

  // Registrar en la base de datos
  const size = typeof content === "string" ? Buffer.byteLength(content) : content.length;

  await createGeneratedFile({
    conversationId,
    messageId,
    filename,
    fileKey,
    url,
    mimeType,
    size,
  });

  return { url, fileKey };
}

/**
 * Sube un archivo desde el workspace del agente a S3
 */
export async function uploadWorkspaceFile(params: {
  conversationId: number;
  messageId?: number;
  workspacePath: string;
  filename?: string;
  mimeType?: string;
}): Promise<{ url: string; fileKey: string }> {
  const { conversationId, messageId, workspacePath, filename, mimeType } = params;

  // Leer archivo del workspace
  const WORKSPACE_DIR = "/tmp/agent-workspace";
  const fullPath = `${WORKSPACE_DIR}/${workspacePath}`;
  const content = await readFile(fullPath);

  // Usar el nombre del archivo del workspace si no se proporciona uno
  const finalFilename = filename || workspacePath.split("/").pop() || "file";

  return uploadGeneratedFile({
    conversationId,
    messageId,
    filename: finalFilename,
    content,
    mimeType,
  });
}

/**
 * Detecta el tipo MIME basado en la extensión del archivo
 */
export function detectMimeType(filename: string): string {
  const ext = filename.split(".").pop()?.toLowerCase();

  const mimeTypes: Record<string, string> = {
    // Texto
    txt: "text/plain",
    md: "text/markdown",
    json: "application/json",
    csv: "text/csv",
    xml: "application/xml",

    // Código
    js: "text/javascript",
    ts: "text/typescript",
    py: "text/x-python",
    html: "text/html",
    css: "text/css",

    // Imágenes
    png: "image/png",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    gif: "image/gif",
    svg: "image/svg+xml",
    webp: "image/webp",

    // Documentos
    pdf: "application/pdf",
    doc: "application/msword",
    docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    xls: "application/vnd.ms-excel",
    xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

    // Archivos comprimidos
    zip: "application/zip",
    tar: "application/x-tar",
    gz: "application/gzip",
  };

  return mimeTypes[ext || ""] || "application/octet-stream";
}
