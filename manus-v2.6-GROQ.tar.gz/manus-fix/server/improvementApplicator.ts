import { promises as fs } from "fs";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export interface ApplyImprovementResult {
  success: boolean;
  message: string;
  backupPath?: string;
  error?: string;
}

/**
 * Aplica una mejora de código al sistema
 * Crea un backup antes de aplicar y permite rollback si falla
 */
export async function applyImprovement(
  proposalId: number,
  changes: Array<{ filePath: string; originalCode: string; newCode: string }>
): Promise<ApplyImprovementResult> {
  const backupDir = path.join(process.cwd(), ".backups", `proposal-${proposalId}-${Date.now()}`);
  
  try {
    // Paso 1: Crear directorio de backup
    await fs.mkdir(backupDir, { recursive: true });
    
    // Paso 2: Hacer backup de archivos afectados
    for (const change of changes) {
      const filePath = path.join(process.cwd(), change.filePath);
      const backupFilePath = path.join(backupDir, change.filePath);
      
      // Crear directorio del backup si no existe
      await fs.mkdir(path.dirname(backupFilePath), { recursive: true });
      
      // Copiar archivo original
      try {
        await fs.copyFile(filePath, backupFilePath);
      } catch (error) {
        // Si el archivo no existe, crear uno vacío en el backup
        await fs.writeFile(backupFilePath, "", "utf-8");
      }
    }
    
    // Paso 3: Aplicar cambios
    for (const change of changes) {
      const filePath = path.join(process.cwd(), change.filePath);
      
      // Leer contenido actual
      let currentContent = "";
      try {
        currentContent = await fs.readFile(filePath, "utf-8");
      } catch (error) {
        // Si el archivo no existe, usar string vacío
        currentContent = "";
      }
      
      // Verificar que el código original coincide (si existe)
      if (change.originalCode && currentContent.includes(change.originalCode)) {
        // Reemplazar código original con nuevo código
        const newContent = currentContent.replace(change.originalCode, change.newCode);
        await fs.writeFile(filePath, newContent, "utf-8");
      } else if (!change.originalCode) {
        // Si no hay código original, es un archivo nuevo
        await fs.mkdir(path.dirname(filePath), { recursive: true });
        await fs.writeFile(filePath, change.newCode, "utf-8");
      } else {
        throw new Error(
          `El código original no coincide en ${change.filePath}. El archivo puede haber sido modificado.`
        );
      }
    }
    
    // Paso 4: Validar sintaxis (compilar TypeScript)
    try {
      await execAsync("pnpm run check", { cwd: process.cwd() });
    } catch (error: any) {
      // Si falla la validación, hacer rollback
      await rollbackImprovement(backupDir, changes);
      return {
        success: false,
        message: "Error de sintaxis detectado, cambios revertidos",
        error: error.message,
      };
    }
    
    // Paso 5: Reiniciar servidor (opcional, se puede hacer manualmente)
    // await execAsync("pnpm run dev", { cwd: process.cwd() });
    
    return {
      success: true,
      message: "Mejora aplicada exitosamente",
      backupPath: backupDir,
    };
  } catch (error: any) {
    // Si algo falla, intentar rollback
    try {
      await rollbackImprovement(backupDir, changes);
    } catch (rollbackError) {
      console.error("Error durante rollback:", rollbackError);
    }
    
    return {
      success: false,
      message: "Error al aplicar mejora",
      error: error.message,
    };
  }
}

/**
 * Revierte cambios usando el backup
 */
async function rollbackImprovement(
  backupDir: string,
  changes: Array<{ filePath: string; originalCode: string; newCode: string }>
): Promise<void> {
  for (const change of changes) {
    const filePath = path.join(process.cwd(), change.filePath);
    const backupFilePath = path.join(backupDir, change.filePath);
    
    try {
      // Restaurar archivo desde backup
      await fs.copyFile(backupFilePath, filePath);
    } catch (error) {
      console.error(`Error restaurando ${filePath}:`, error);
    }
  }
}

/**
 * Rollback manual de una mejora usando su backup
 */
export async function manualRollback(backupPath: string): Promise<ApplyImprovementResult> {
  try {
    // Listar todos los archivos en el backup
    const files = await listFilesRecursive(backupPath);
    
    for (const file of files) {
      const relativePath = path.relative(backupPath, file);
      const targetPath = path.join(process.cwd(), relativePath);
      
      // Restaurar archivo
      await fs.mkdir(path.dirname(targetPath), { recursive: true });
      await fs.copyFile(file, targetPath);
    }
    
    return {
      success: true,
      message: "Rollback completado exitosamente",
    };
  } catch (error: any) {
    return {
      success: false,
      message: "Error durante rollback",
      error: error.message,
    };
  }
}

/**
 * Lista todos los archivos en un directorio recursivamente
 */
async function listFilesRecursive(dir: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files: string[] = [];
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await listFilesRecursive(fullPath)));
    } else {
      files.push(fullPath);
    }
  }
  
  return files;
}
