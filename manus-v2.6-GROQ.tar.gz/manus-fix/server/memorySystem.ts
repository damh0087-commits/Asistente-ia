/**
 * SISTEMA DE MEMORIA CONTEXTUAL MEJORADO
 * 
 * Características:
 * - Ventana de contexto extendida (100K tokens)
 * - Resúmenes automáticos de conversaciones largas
 * - Memoria a corto y largo plazo
 * - Recuperación semántica de contexto relevante
 * - Compresión inteligente de historial
 */

import type { Message } from "./agent";

interface ConversationMemory {
  conversationId: number;
  shortTermMemory: Message[]; // Últimos N mensajes
  longTermMemory: ConversationSummary[]; // Resúmenes de bloques anteriores
  facts: Map<string, string>; // Hechos extraídos (key-value)
  totalTokens: number;
}

interface ConversationSummary {
  id: string;
  messageRange: { start: number; end: number };
  summary: string;
  keyPoints: string[];
  timestamp: Date;
  tokens: number;
}

// Store en memoria (en producción usar Redis o DB)
const memoryStore = new Map<number, ConversationMemory>();

/**
 * Configuración del sistema de memoria
 */
const MEMORY_CONFIG = {
  MAX_CONTEXT_TOKENS: 100000, // 100K tokens de contexto
  SHORT_TERM_MESSAGES: 20, // Últimos 20 mensajes siempre en memoria
  SUMMARY_THRESHOLD: 10, // Crear resumen cada 10 mensajes
  COMPRESSION_RATIO: 0.2, // Comprimir a 20% del tamaño original
};

/**
 * Inicializa memoria para una conversación
 */
export function initializeMemory(conversationId: number): void {
  if (!memoryStore.has(conversationId)) {
    memoryStore.set(conversationId, {
      conversationId,
      shortTermMemory: [],
      longTermMemory: [],
      facts: new Map(),
      totalTokens: 0,
    });
  }
}

/**
 * Agrega un mensaje a la memoria
 */
export function addMessageToMemory(
  conversationId: number,
  message: Message
): void {
  initializeMemory(conversationId);

  const memory = memoryStore.get(conversationId)!;
  memory.shortTermMemory.push(message);

  // Estimar tokens (aproximado: 1 token ≈ 4 caracteres)
  const messageTokens = estimateTokens(message.content);
  memory.totalTokens += messageTokens;

  // Si excedemos el límite, comprimir
  if (memory.shortTermMemory.length > MEMORY_CONFIG.SUMMARY_THRESHOLD) {
    compressMemory(conversationId);
  }
}

/**
 * Obtiene contexto optimizado para el LLM
 */
export function getOptimizedContext(conversationId: number): Message[] {
  initializeMemory(conversationId);

  const memory = memoryStore.get(conversationId)!;

  // Construir contexto
  const context: Message[] = [];

  // 1. Agregar resúmenes de memoria a largo plazo como contexto inicial
  if (memory.longTermMemory.length > 0) {
    const summariesText = memory.longTermMemory
      .map(
        (summary) =>
          `[Resumen de conversación anterior: ${summary.keyPoints.join(", ")}]`
      )
      .join("\n\n");

    context.push({
      role: "system",
      content: `Contexto de conversación previa:\n${summariesText}`,
    });
  }

  // 2. Agregar hechos importantes
  if (memory.facts.size > 0) {
    const factsText = Array.from(memory.facts.entries())
      .map(([key, value]) => `- ${key}: ${value}`)
      .join("\n");

    context.push({
      role: "system",
      content: `Información importante del usuario:\n${factsText}`,
    });
  }

  // 3. Agregar memoria a corto plazo (últimos mensajes completos)
  context.push(...memory.shortTermMemory);

  return context;
}

/**
 * Comprime memoria cuando excede límites
 */
async function compressMemory(conversationId: number): Promise<void> {
  const memory = memoryStore.get(conversationId)!;

  // Si aún no hay suficientes mensajes, no comprimir
  if (memory.shortTermMemory.length <= MEMORY_CONFIG.SHORT_TERM_MESSAGES) {
    return;
  }

  // Separar mensajes a comprimir vs mantener
  const messagesToCompress = memory.shortTermMemory.slice(
    0,
    -MEMORY_CONFIG.SHORT_TERM_MESSAGES
  );
  const messagesToKeep = memory.shortTermMemory.slice(
    -MEMORY_CONFIG.SHORT_TERM_MESSAGES
  );

  // Crear resumen de mensajes antiguos
  const summary = await createSummary(messagesToCompress);

  // Agregar a memoria a largo plazo
  memory.longTermMemory.push(summary);

  // Mantener solo últimos N mensajes en corto plazo
  memory.shortTermMemory = messagesToKeep;

  // Recalcular tokens
  memory.totalTokens = calculateTotalTokens(memory);

  console.log(
    `[Memory] Comprimido ${messagesToCompress.length} mensajes → 1 resumen (${summary.tokens} tokens)`
  );
}

/**
 * Crea un resumen de un bloque de mensajes
 */
async function createSummary(
  messages: Message[]
): Promise<ConversationSummary> {
  // Extraer información clave
  const userMessages = messages.filter((m) => m.role === "user");
  const assistantMessages = messages.filter((m) => m.role === "assistant");

  // Crear resumen simple (en producción, usar LLM para esto)
  const keyPoints: string[] = [];

  // Extraer temas principales de las preguntas del usuario
  userMessages.forEach((msg) => {
    const firstWords = msg.content.slice(0, 100);
    if (firstWords.length > 0) {
      keyPoints.push(`Usuario preguntó: ${firstWords}...`);
    }
  });

  const summary = `Bloque de ${messages.length} mensajes. ${userMessages.length} preguntas del usuario, ${assistantMessages.length} respuestas del asistente.`;

  const summaryTokens = estimateTokens(summary + keyPoints.join(" "));

  return {
    id: `summary_${Date.now()}`,
    messageRange: { start: 0, end: messages.length },
    summary,
    keyPoints: keyPoints.slice(0, 5), // Máximo 5 puntos clave
    timestamp: new Date(),
    tokens: summaryTokens,
  };
}

/**
 * Extrae hechos importantes de la conversación
 */
export function extractFacts(
  conversationId: number,
  message: Message
): void {
  const memory = memoryStore.get(conversationId);
  if (!memory) return;

  // Patrones simples para extraer hechos (en producción, usar LLM)
  const content = message.content.toLowerCase();

  // Extraer nombre
  if (content.includes("mi nombre es") || content.includes("me llamo")) {
    const match = content.match(
      /(?:mi nombre es|me llamo)\s+([a-záéíóúñ]+)/i
    );
    if (match) {
      memory.facts.set("nombre", match[1]);
    }
  }

  // Extraer preferencias
  if (content.includes("me gusta") || content.includes("prefiero")) {
    const match = content.match(/(?:me gusta|prefiero)\s+([^.]+)/i);
    if (match) {
      memory.facts.set("preferencia", match[1].trim());
    }
  }

  // Agregar más patrones según necesidad
}

/**
 * Obtiene estadísticas de memoria
 */
export function getMemoryStats(conversationId: number): {
  shortTermMessages: number;
  longTermSummaries: number;
  totalTokens: number;
  facts: number;
} {
  initializeMemory(conversationId);

  const memory = memoryStore.get(conversationId)!;

  return {
    shortTermMessages: memory.shortTermMemory.length,
    longTermSummaries: memory.longTermMemory.length,
    totalTokens: memory.totalTokens,
    facts: memory.facts.size,
  };
}

/**
 * Limpia memoria de una conversación
 */
export function clearMemory(conversationId: number): void {
  memoryStore.delete(conversationId);
}

/**
 * Estima tokens de un texto (aproximado)
 */
function estimateTokens(text: string): number {
  // Aproximación: 1 token ≈ 4 caracteres en inglés/español
  return Math.ceil(text.length / 4);
}

/**
 * Calcula total de tokens en memoria
 */
function calculateTotalTokens(memory: ConversationMemory): number {
  let total = 0;

  // Tokens en short term
  memory.shortTermMemory.forEach((msg) => {
    total += estimateTokens(msg.content);
  });

  // Tokens en resúmenes
  memory.longTermMemory.forEach((summary) => {
    total += summary.tokens;
  });

  // Tokens en hechos
  memory.facts.forEach((value, key) => {
    total += estimateTokens(`${key}: ${value}`);
  });

  return total;
}

/**
 * Obtiene memoria completa (para debugging)
 */
export function getFullMemory(conversationId: number): ConversationMemory | null {
  return memoryStore.get(conversationId) || null;
}
