/**
 * SISTEMA DE MÉTRICAS Y MONITOREO
 * 
 * Tracking de uso de herramientas, tasa de éxito, performance
 */

interface ToolMetric {
  toolName: string;
  totalCalls: number;
  successfulCalls: number;
  failedCalls: number;
  totalExecutionTime: number; // ms
  averageExecutionTime: number; // ms
  minExecutionTime: number; // ms
  maxExecutionTime: number; // ms
  lastUsed: Date;
  errorMessages: Map<string, number>; // error message -> count
}

interface AgentMetrics {
  totalConversations: number;
  totalMessages: number;
  totalToolCalls: number;
  averageToolsPerConversation: number;
  averageIterationsPerMessage: number;
  totalErrors: number;
  uptime: number; // ms
  toolMetrics: Map<string, ToolMetric>;
}

class MetricsCollector {
  private toolMetrics: Map<string, ToolMetric> = new Map();
  private startTime: Date = new Date();
  private totalConversations: number = 0;
  private totalMessages: number = 0;
  private totalToolCalls: number = 0;
  private totalErrors: number = 0;
  private conversationToolCounts: number[] = [];
  private messageIterationCounts: number[] = [];

  /**
   * Registra el uso de una herramienta
   */
  recordToolCall(
    toolName: string,
    executionTime: number,
    success: boolean,
    errorMessage?: string
  ): void {
    this.totalToolCalls++;

    if (!this.toolMetrics.has(toolName)) {
      this.toolMetrics.set(toolName, {
        toolName,
        totalCalls: 0,
        successfulCalls: 0,
        failedCalls: 0,
        totalExecutionTime: 0,
        averageExecutionTime: 0,
        minExecutionTime: Infinity,
        maxExecutionTime: 0,
        lastUsed: new Date(),
        errorMessages: new Map(),
      });
    }

    const metric = this.toolMetrics.get(toolName)!;
    metric.totalCalls++;
    metric.lastUsed = new Date();
    metric.totalExecutionTime += executionTime;
    metric.averageExecutionTime = metric.totalExecutionTime / metric.totalCalls;
    metric.minExecutionTime = Math.min(metric.minExecutionTime, executionTime);
    metric.maxExecutionTime = Math.max(metric.maxExecutionTime, executionTime);

    if (success) {
      metric.successfulCalls++;
    } else {
      metric.failedCalls++;
      this.totalErrors++;

      if (errorMessage) {
        const count = metric.errorMessages.get(errorMessage) || 0;
        metric.errorMessages.set(errorMessage, count + 1);
      }
    }
  }

  /**
   * Registra una conversación
   */
  recordConversation(toolsUsed: number): void {
    this.totalConversations++;
    this.conversationToolCounts.push(toolsUsed);
  }

  /**
   * Registra un mensaje
   */
  recordMessage(iterations: number): void {
    this.totalMessages++;
    this.messageIterationCounts.push(iterations);
  }

  /**
   * Obtiene métricas completas
   */
  getMetrics(): AgentMetrics {
    const avgToolsPerConv =
      this.conversationToolCounts.length > 0
        ? this.conversationToolCounts.reduce((a, b) => a + b, 0) /
          this.conversationToolCounts.length
        : 0;

    const avgIterations =
      this.messageIterationCounts.length > 0
        ? this.messageIterationCounts.reduce((a, b) => a + b, 0) /
          this.messageIterationCounts.length
        : 0;

    return {
      totalConversations: this.totalConversations,
      totalMessages: this.totalMessages,
      totalToolCalls: this.totalToolCalls,
      averageToolsPerConversation: parseFloat(avgToolsPerConv.toFixed(2)),
      averageIterationsPerMessage: parseFloat(avgIterations.toFixed(2)),
      totalErrors: this.totalErrors,
      uptime: Date.now() - this.startTime.getTime(),
      toolMetrics: this.toolMetrics,
    };
  }

  /**
   * Obtiene métricas de una herramienta específica
   */
  getToolMetrics(toolName: string): ToolMetric | null {
    return this.toolMetrics.get(toolName) || null;
  }

  /**
   * Obtiene top N herramientas más usadas
   */
  getTopTools(n: number = 10): ToolMetric[] {
    return Array.from(this.toolMetrics.values())
      .sort((a, b) => b.totalCalls - a.totalCalls)
      .slice(0, n);
  }

  /**
   * Obtiene herramientas con más fallos
   */
  getFailingTools(minFailures: number = 1): ToolMetric[] {
    return Array.from(this.toolMetrics.values())
      .filter((m) => m.failedCalls >= minFailures)
      .sort((a, b) => b.failedCalls - a.failedCalls);
  }

  /**
   * Obtiene herramientas más lentas
   */
  getSlowestTools(n: number = 10): ToolMetric[] {
    return Array.from(this.toolMetrics.values())
      .sort((a, b) => b.averageExecutionTime - a.averageExecutionTime)
      .slice(0, n);
  }

  /**
   * Genera reporte de métricas en texto
   */
  generateReport(): string {
    const metrics = this.getMetrics();
    const topTools = this.getTopTools(5);
    const failingTools = this.getFailingTools(1);
    const slowestTools = this.getSlowestTools(5);

    const uptimeHours = (metrics.uptime / (1000 * 60 * 60)).toFixed(2);

    let report = `
📊 REPORTE DE MÉTRICAS DEL AGENTE
═══════════════════════════════════════

⏱️  TIEMPO DE ACTIVIDAD
   ${uptimeHours} horas

📈 ESTADÍSTICAS GENERALES
   Conversaciones: ${metrics.totalConversations}
   Mensajes: ${metrics.totalMessages}
   Llamadas a herramientas: ${metrics.totalToolCalls}
   Errores totales: ${metrics.totalErrors}
   
   Promedio herramientas/conversación: ${metrics.averageToolsPerConversation}
   Promedio iteraciones/mensaje: ${metrics.averageIterationsPerMessage}

🔧 TOP 5 HERRAMIENTAS MÁS USADAS
`;

    topTools.forEach((tool, i) => {
      const successRate = (
        (tool.successfulCalls / tool.totalCalls) *
        100
      ).toFixed(1);
      report += `   ${i + 1}. ${tool.toolName}
      Llamadas: ${tool.totalCalls}
      Éxito: ${successRate}%
      Tiempo promedio: ${tool.averageExecutionTime.toFixed(0)}ms
\n`;
    });

    if (failingTools.length > 0) {
      report += `\n⚠️  HERRAMIENTAS CON FALLOS\n`;
      failingTools.forEach((tool) => {
        const failureRate = (
          (tool.failedCalls / tool.totalCalls) *
          100
        ).toFixed(1);
        report += `   - ${tool.toolName}: ${tool.failedCalls} fallos (${failureRate}%)\n`;

        // Mostrar top 3 errores
        const topErrors = Array.from(tool.errorMessages.entries())
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3);

        topErrors.forEach(([msg, count]) => {
          const shortMsg = msg.length > 60 ? msg.substring(0, 60) + "..." : msg;
          report += `     • ${shortMsg} (${count}x)\n`;
        });
      });
    }

    report += `\n🐌 TOP 5 HERRAMIENTAS MÁS LENTAS\n`;
    slowestTools.forEach((tool, i) => {
      report += `   ${i + 1}. ${tool.toolName}
      Promedio: ${tool.averageExecutionTime.toFixed(0)}ms
      Mín/Máx: ${tool.minExecutionTime.toFixed(0)}ms / ${tool.maxExecutionTime.toFixed(0)}ms
\n`;
    });

    return report;
  }

  /**
   * Genera métricas en formato JSON para dashboard
   */
  generateDashboardData(): any {
    const metrics = this.getMetrics();
    const toolsArray = Array.from(metrics.toolMetrics.values()).map((t) => ({
      name: t.toolName,
      calls: t.totalCalls,
      success: t.successfulCalls,
      failed: t.failedCalls,
      avgTime: parseFloat(t.averageExecutionTime.toFixed(2)),
      lastUsed: t.lastUsed.toISOString(),
    }));

    return {
      summary: {
        conversations: metrics.totalConversations,
        messages: metrics.totalMessages,
        toolCalls: metrics.totalToolCalls,
        errors: metrics.totalErrors,
        uptimeMs: metrics.uptime,
      },
      tools: toolsArray,
      charts: {
        toolUsage: toolsArray.map((t) => ({
          name: t.name,
          value: t.calls,
        })),
        toolPerformance: toolsArray.map((t) => ({
          name: t.name,
          avgTime: t.avgTime,
        })),
        toolSuccessRate: toolsArray.map((t) => ({
          name: t.name,
          rate: t.calls > 0 ? ((t.success / t.calls) * 100).toFixed(1) : 0,
        })),
      },
    };
  }

  /**
   * Resetea todas las métricas
   */
  reset(): void {
    this.toolMetrics.clear();
    this.startTime = new Date();
    this.totalConversations = 0;
    this.totalMessages = 0;
    this.totalToolCalls = 0;
    this.totalErrors = 0;
    this.conversationToolCounts = [];
    this.messageIterationCounts = [];
  }
}

// Singleton instance
export const metricsCollector = new MetricsCollector();

/**
 * Helper para wrappear ejecución de herramienta con tracking
 */
export async function executeWithMetrics<T>(
  toolName: string,
  executor: () => Promise<T>
): Promise<T> {
  const startTime = Date.now();
  let success = true;
  let errorMessage: string | undefined;

  try {
    const result = await executor();
    return result;
  } catch (error) {
    success = false;
    errorMessage = error instanceof Error ? error.message : "Unknown error";
    throw error;
  } finally {
    const executionTime = Date.now() - startTime;
    metricsCollector.recordToolCall(toolName, executionTime, success, errorMessage);
  }
}

// Exportar funciones útiles
export {
  MetricsCollector,
  type AgentMetrics,
  type ToolMetric,
};
