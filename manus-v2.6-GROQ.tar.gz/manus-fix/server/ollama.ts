import axios from "axios";

/**
 * Cliente para comunicación con Ollama API local
 * Ollama debe estar corriendo en http://localhost:11434
 */

const OLLAMA_BASE_URL = process.env.OLLAMA_URL || "http://localhost:11434";

export interface OllamaMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_calls?: Array<{
    id: string;
    type: "function";
    function: {
      name: string;
      arguments: string;
    };
  }>;
}

export interface OllamaChatRequest {
  model: string;
  messages: OllamaMessage[];
  stream?: boolean;
  tools?: Array<{
    type: "function";
    function: {
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    };
  }>;
}

export interface OllamaChatResponse {
  model: string;
  created_at: string;
  message: OllamaMessage;
  done: boolean;
}

/**
 * Envía una solicitud de chat a Ollama
 */
export async function chatWithOllama(
  request: OllamaChatRequest
): Promise<OllamaChatResponse> {
  try {
    const response = await axios.post<OllamaChatResponse>(
      `${OLLAMA_BASE_URL}/api/chat`,
      request,
      {
        headers: {
          "Content-Type": "application/json",
        },
        timeout: 120000, // 2 minutos
      }
    );

    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(
        `Ollama API error: ${error.response?.data?.error || error.message}`
      );
    }
    throw error;
  }
}

/**
 * Envía una solicitud de chat con streaming a Ollama
 */
export async function* streamChatWithOllama(
  request: OllamaChatRequest
): AsyncGenerator<OllamaChatResponse> {
  try {
    const response = await axios.post(
      `${OLLAMA_BASE_URL}/api/chat`,
      { ...request, stream: true },
      {
        headers: {
          "Content-Type": "application/json",
        },
        responseType: "stream",
        timeout: 120000,
      }
    );

    const stream = response.data;
    let buffer = "";

    for await (const chunk of stream) {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (line.trim()) {
          try {
            const data = JSON.parse(line);
            yield data;
          } catch (e) {
            console.error("Error parsing Ollama stream:", e);
          }
        }
      }
    }

    // Procesar el último fragmento
    if (buffer.trim()) {
      try {
        const data = JSON.parse(buffer);
        yield data;
      } catch (e) {
        console.error("Error parsing final Ollama chunk:", e);
      }
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(
        `Ollama streaming error: ${error.response?.data?.error || error.message}`
      );
    }
    throw error;
  }
}

/**
 * Lista los modelos disponibles en Ollama
 */
export async function listOllamaModels(): Promise<
  Array<{ name: string; size: number; modified_at: string }>
> {
  try {
    const response = await axios.get(`${OLLAMA_BASE_URL}/api/tags`);
    return response.data.models || [];
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(
        `Error listing Ollama models: ${error.response?.data?.error || error.message}`
      );
    }
    throw error;
  }
}

/**
 * Verifica si Ollama está disponible
 */
export async function checkOllamaHealth(): Promise<boolean> {
  try {
    await axios.get(`${OLLAMA_BASE_URL}/api/tags`, { timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

/**
 * Modelo por defecto a usar (DeepSeek-R1 si está disponible, sino qwen3)
 */
export const DEFAULT_MODEL = process.env.OLLAMA_MODEL || "deepseek-r1:8b";
