/**
 * SISTEMA DE PERSISTENCIA CON SQLITE
 * 
 * Soluciona el problema de que memoria y caché se pierden al reiniciar
 * Usa SQLite (archivo local) en lugar de Redis
 * 
 * Características:
 * - Memoria persiste entre reinicios
 * - Caché persiste entre reinicios
 * - No requiere Redis
 * - Archivo local: data/persistence.db
 */

import { Database } from "bun:sqlite";
import { existsSync, mkdirSync } from "fs";
import { join } from "path";

// Ruta de la base de datos
const DB_DIR = join(process.cwd(), "data");
const DB_PATH = join(DB_DIR, "persistence.db");

// Crear directorio si no existe
if (!existsSync(DB_DIR)) {
  mkdirSync(DB_DIR, { recursive: true });
}

// Inicializar base de datos
const db = new Database(DB_PATH);

// Crear tablas si no existen
db.exec(`
  CREATE TABLE IF NOT EXISTS memory_facts (
    conversation_id INTEGER,
    fact_key TEXT,
    fact_value TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (conversation_id, fact_key)
  );

  CREATE TABLE IF NOT EXISTS memory_summaries (
    id TEXT PRIMARY KEY,
    conversation_id INTEGER,
    summary TEXT,
    key_points TEXT,
    start_message INTEGER,
    end_message INTEGER,
    tokens INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS response_cache (
    cache_key TEXT PRIMARY KEY,
    query TEXT,
    response TEXT,
    hits INTEGER DEFAULT 0,
    average_response_time REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_memory_conversation ON memory_facts(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_summaries_conversation ON memory_summaries(conversation_id);
  CREATE INDEX IF NOT EXISTS idx_cache_created ON response_cache(created_at);
`);

console.log("✅ Persistence database initialized at:", DB_PATH);

/**
 * ====================
 * FUNCIONES DE MEMORIA
 * ====================
 */

export function saveMemoryFact(
  conversationId: number,
  key: string,
  value: string
): void {
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO memory_facts (conversation_id, fact_key, fact_value)
    VALUES (?, ?, ?)
  `);

  stmt.run(conversationId, key, value);
}

export function getMemoryFacts(conversationId: number): Map<string, string> {
  const stmt = db.prepare(`
    SELECT fact_key, fact_value
    FROM memory_facts
    WHERE conversation_id = ?
  `);

  const rows = stmt.all(conversationId) as Array<{
    fact_key: string;
    fact_value: string;
  }>;

  const facts = new Map<string, string>();
  rows.forEach((row) => {
    facts.set(row.fact_key, row.fact_value);
  });

  return facts;
}

export function saveMemorySummary(
  id: string,
  conversationId: number,
  summary: string,
  keyPoints: string[],
  startMessage: number,
  endMessage: number,
  tokens: number
): void {
  const stmt = db.prepare(`
    INSERT INTO memory_summaries (id, conversation_id, summary, key_points, start_message, end_message, tokens)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run(
    id,
    conversationId,
    summary,
    JSON.stringify(keyPoints),
    startMessage,
    endMessage,
    tokens
  );
}

export function getMemorySummaries(conversationId: number): Array<{
  id: string;
  summary: string;
  keyPoints: string[];
  startMessage: number;
  endMessage: number;
  tokens: number;
}> {
  const stmt = db.prepare(`
    SELECT id, summary, key_points, start_message, end_message, tokens
    FROM memory_summaries
    WHERE conversation_id = ?
    ORDER BY created_at ASC
  `);

  const rows = stmt.all(conversationId) as Array<{
    id: string;
    summary: string;
    key_points: string;
    start_message: number;
    end_message: number;
    tokens: number;
  }>;

  return rows.map((row) => ({
    id: row.id,
    summary: row.summary,
    keyPoints: JSON.parse(row.key_points),
    startMessage: row.start_message,
    endMessage: row.end_message,
    tokens: row.tokens,
  }));
}

export function clearMemoryForConversation(conversationId: number): void {
  db.exec(`DELETE FROM memory_facts WHERE conversation_id = ${conversationId}`);
  db.exec(
    `DELETE FROM memory_summaries WHERE conversation_id = ${conversationId}`
  );
}

/**
 * ====================
 * FUNCIONES DE CACHÉ
 * ====================
 */

export function saveCachedResponse(
  cacheKey: string,
  query: string,
  response: string,
  responseTime: number
): void {
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO response_cache (cache_key, query, response, hits, average_response_time, updated_at)
    VALUES (
      ?,
      ?,
      ?,
      COALESCE((SELECT hits FROM response_cache WHERE cache_key = ?), 0),
      ?,
      CURRENT_TIMESTAMP
    )
  `);

  stmt.run(cacheKey, query, response, cacheKey, responseTime);
}

export function getCachedResponse(cacheKey: string): {
  query: string;
  response: string;
  hits: number;
  averageResponseTime: number;
} | null {
  const stmt = db.prepare(`
    SELECT query, response, hits, average_response_time
    FROM response_cache
    WHERE cache_key = ?
  `);

  const row = stmt.get(cacheKey) as
    | {
        query: string;
        response: string;
        hits: number;
        average_response_time: number;
      }
    | undefined;

  return row || null;
}

export function incrementCacheHit(cacheKey: string): void {
  const stmt = db.prepare(`
    UPDATE response_cache
    SET hits = hits + 1, updated_at = CURRENT_TIMESTAMP
    WHERE cache_key = ?
  `);

  stmt.run(cacheKey);
}

export function getAllCachedQueries(): Array<{
  cacheKey: string;
  query: string;
}> {
  const stmt = db.prepare(`
    SELECT cache_key, query
    FROM response_cache
    ORDER BY hits DESC, updated_at DESC
  `);

  return stmt.all() as Array<{ cacheKey: string; query: string }>;
}

export function cleanExpiredCache(ttlMs: number): number {
  const expiryDate = new Date(Date.now() - ttlMs).toISOString();

  const stmt = db.prepare(`
    DELETE FROM response_cache
    WHERE updated_at < ?
  `);

  const result = stmt.run(expiryDate);
  return result.changes;
}

export function getCacheStats(): {
  totalEntries: number;
  totalHits: number;
  totalSize: number;
} {
  const stmt = db.prepare(`
    SELECT
      COUNT(*) as total_entries,
      SUM(hits) as total_hits,
      SUM(LENGTH(query) + LENGTH(response)) as total_size
    FROM response_cache
  `);

  const row = stmt.get() as {
    total_entries: number;
    total_hits: number;
    total_size: number;
  };

  return {
    totalEntries: row.total_entries,
    totalHits: row.total_hits || 0,
    totalSize: row.total_size || 0,
  };
}

export function clearAllCache(): void {
  db.exec("DELETE FROM response_cache");
}

/**
 * ====================
 * FUNCIONES DE UTILIDAD
 * ====================
 */

export function getDbStats(): {
  memoryFacts: number;
  memorySummaries: number;
  cacheEntries: number;
  dbSizeMB: number;
} {
  const factsCount = (
    db.prepare("SELECT COUNT(*) as count FROM memory_facts").get() as {
      count: number;
    }
  ).count;

  const summariesCount = (
    db.prepare("SELECT COUNT(*) as count FROM memory_summaries").get() as {
      count: number;
    }
  ).count;

  const cacheCount = (
    db.prepare("SELECT COUNT(*) as count FROM response_cache").get() as {
      count: number;
    }
  ).count;

  // Tamaño del archivo de base de datos
  const stats = require("fs").statSync(DB_PATH);
  const dbSizeMB = stats.size / (1024 * 1024);

  return {
    memoryFacts: factsCount,
    memorySummaries: summariesCount,
    cacheEntries: cacheCount,
    dbSizeMB: parseFloat(dbSizeMB.toFixed(2)),
  };
}

export function vacuumDatabase(): void {
  db.exec("VACUUM");
  console.log("✅ Database vacuumed");
}

// Limpiar caché expirado cada hora
setInterval(() => {
  const cleaned = cleanExpiredCache(1000 * 60 * 60 * 24); // 24 horas
  if (cleaned > 0) {
    console.log(`🧹 Cleaned ${cleaned} expired cache entries`);
  }
}, 1000 * 60 * 60); // Cada hora

// Vacuum database cada 24 horas
setInterval(
  () => {
    vacuumDatabase();
  },
  1000 * 60 * 60 * 24
); // Cada 24 horas

// Exportar la instancia de base de datos para uso directo si es necesario
export { db };
