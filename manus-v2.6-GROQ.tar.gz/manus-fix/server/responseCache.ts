/**
 * SISTEMA DE CACHÉ DE RESPUESTAS RÁPIDAS
 * 
 * Mejora la velocidad de respuesta cacheando:
 * - Respuestas a preguntas frecuentes
 * - Resultados de búsquedas recientes
 * - Outputs de herramientas costosas
 * - Respuestas similares semánticamente
 */

import { createHash } from "crypto";

interface CachedResponse {
  query: string;
  response: string;
  timestamp: Date;
  hits: number;
  averageResponseTime: number;
}

interface CacheStats {
  totalEntries: number;
  totalHits: number;
  totalMisses: number;
  hitRate: number;
  averageResponseTime: number;
  cacheSize: number;
}

// Cache en memoria (en producción usar Redis)
const responseCache = new Map<string, CachedResponse>();

// Estadísticas
let totalHits = 0;
let totalMisses = 0;

/**
 * Configuración del caché
 */
const CACHE_CONFIG = {
  MAX_ENTRIES: 1000, // Máximo 1000 respuestas en caché
  TTL_MS: 1000 * 60 * 60 * 24, // 24 horas
  SIMILARITY_THRESHOLD: 0.85, // 85% de similitud para considerar match
  ENABLE_SEMANTIC_MATCHING: true, // Buscar respuestas similares
};

/**
 * Genera una key única para una query
 */
function generateCacheKey(query: string): string {
  // Normalizar query
  const normalized = query.toLowerCase().trim();

  // Hash SHA-256
  return createHash("sha256").update(normalized).digest("hex");
}

/**
 * Intenta obtener respuesta del caché
 */
export async function getCachedResponse(
  query: string
): Promise<string | null> {
  const key = generateCacheKey(query);
  const cached = responseCache.get(key);

  if (cached) {
    // Verificar TTL
    const age = Date.now() - cached.timestamp.getTime();
    if (age > CACHE_CONFIG.TTL_MS) {
      // Expirado, eliminar
      responseCache.delete(key);
      totalMisses++;
      return null;
    }

    // Hit!
    cached.hits++;
    totalHits++;

    console.log(
      `[ResponseCache] HIT: "${query.slice(0, 50)}..." (${cached.hits} hits)`
    );

    return cached.response;
  }

  // Si no hay match exacto, buscar similar (si está habilitado)
  if (CACHE_CONFIG.ENABLE_SEMANTIC_MATCHING) {
    const similar = findSimilarQuery(query);
    if (similar) {
      similar.hits++;
      totalHits++;

      console.log(
        `[ResponseCache] SIMILAR HIT: "${query.slice(0, 30)}..." → "${similar.query.slice(0, 30)}..."`
      );

      return similar.response;
    }
  }

  totalMisses++;
  return null;
}

/**
 * Guarda respuesta en caché
 */
export function cacheResponse(
  query: string,
  response: string,
  responseTime: number
): void {
  const key = generateCacheKey(query);

  // Si ya existe, actualizar
  const existing = responseCache.get(key);
  if (existing) {
    existing.response = response;
    existing.timestamp = new Date();
    existing.averageResponseTime =
      (existing.averageResponseTime * existing.hits + responseTime) /
      (existing.hits + 1);
    return;
  }

  // Verificar límite de entradas
  if (responseCache.size >= CACHE_CONFIG.MAX_ENTRIES) {
    // Eliminar entrada más antigua con menos hits
    evictLeastValuable();
  }

  // Agregar nueva entrada
  responseCache.set(key, {
    query,
    response,
    timestamp: new Date(),
    hits: 0,
    averageResponseTime: responseTime,
  });

  console.log(`[ResponseCache] CACHED: "${query.slice(0, 50)}..."`);
}

/**
 * Busca una query similar en el caché
 */
function findSimilarQuery(query: string): CachedResponse | null {
  const queryNormalized = query.toLowerCase().trim();
  let bestMatch: CachedResponse | null = null;
  let bestScore = 0;

  for (const cached of responseCache.values()) {
    const cachedNormalized = cached.query.toLowerCase().trim();
    const similarity = calculateSimilarity(queryNormalized, cachedNormalized);

    if (
      similarity >= CACHE_CONFIG.SIMILARITY_THRESHOLD &&
      similarity > bestScore
    ) {
      bestMatch = cached;
      bestScore = similarity;
    }
  }

  return bestMatch;
}

/**
 * Calcula similitud entre dos strings (Jaccard similarity)
 */
function calculateSimilarity(str1: string, str2: string): number {
  const words1 = new Set(str1.split(/\s+/));
  const words2 = new Set(str2.split(/\s+/));

  const intersection = new Set([...words1].filter((x) => words2.has(x)));
  const union = new Set([...words1, ...words2]);

  return intersection.size / union.size;
}

/**
 * Elimina la entrada menos valiosa del caché
 */
function evictLeastValuable(): void {
  let leastValuable: string | null = null;
  let lowestScore = Infinity;

  for (const [key, cached] of responseCache.entries()) {
    // Score = hits / age_in_hours
    const ageHours = (Date.now() - cached.timestamp.getTime()) / (1000 * 60 * 60);
    const score = cached.hits / Math.max(ageHours, 0.1);

    if (score < lowestScore) {
      lowestScore = score;
      leastValuable = key;
    }
  }

  if (leastValuable) {
    responseCache.delete(leastValuable);
    console.log(`[ResponseCache] EVICTED least valuable entry`);
  }
}

/**
 * Obtiene estadísticas del caché
 */
export function getCacheStats(): CacheStats {
  let totalResponseTime = 0;
  let entriesWithHits = 0;

  for (const cached of responseCache.values()) {
    if (cached.hits > 0) {
      totalResponseTime += cached.averageResponseTime * cached.hits;
      entriesWithHits += cached.hits;
    }
  }

  const total = totalHits + totalMisses;
  const hitRate = total > 0 ? totalHits / total : 0;
  const avgResponseTime =
    entriesWithHits > 0 ? totalResponseTime / entriesWithHits : 0;

  return {
    totalEntries: responseCache.size,
    totalHits,
    totalMisses,
    hitRate: parseFloat((hitRate * 100).toFixed(2)),
    averageResponseTime: parseFloat(avgResponseTime.toFixed(2)),
    cacheSize: calculateCacheSize(),
  };
}

/**
 * Calcula tamaño del caché en MB
 */
function calculateCacheSize(): number {
  let totalChars = 0;

  for (const cached of responseCache.values()) {
    totalChars += cached.query.length + cached.response.length;
  }

  // Aproximación: 2 bytes por carácter
  return parseFloat(((totalChars * 2) / (1024 * 1024)).toFixed(2));
}

/**
 * Limpia el caché completo
 */
export function clearCache(): void {
  responseCache.clear();
  totalHits = 0;
  totalMisses = 0;
  console.log("[ResponseCache] Cache cleared");
}

/**
 * Limpia entradas expiradas
 */
export function cleanupExpiredEntries(): void {
  const now = Date.now();
  let cleaned = 0;

  for (const [key, cached] of responseCache.entries()) {
    const age = now - cached.timestamp.getTime();
    if (age > CACHE_CONFIG.TTL_MS) {
      responseCache.delete(key);
      cleaned++;
    }
  }

  if (cleaned > 0) {
    console.log(`[ResponseCache] Cleaned up ${cleaned} expired entries`);
  }
}

// Limpieza automática cada hora
setInterval(cleanupExpiredEntries, 1000 * 60 * 60);

/**
 * Precarga respuestas frecuentes
 */
export function preloadCommonResponses(): void {
  const commonQueries = [
    {
      query: "¿Qué puedes hacer?",
      response:
        "Soy un asistente de IA con 12 herramientas. Puedo buscar en la web, ejecutar código, analizar datos, generar audio, crear videos, generar proyectos completos y más. ¿En qué puedo ayudarte?",
    },
    {
      query: "Hola",
      response:
        "¡Hola! Soy tu asistente de IA. Puedo ayudarte con búsquedas web, análisis de datos, ejecución de código, generación de audio y video, y mucho más. ¿Qué necesitas?",
    },
    {
      query: "¿Cómo funcionas?",
      response:
        "Funciono como un agente autónomo con 12 herramientas especializadas. Analizo tu petición, decido qué herramientas usar, las ejecuto y te doy una respuesta completa. Puedo buscar información, ejecutar código, crear proyectos y más.",
    },
  ];

  commonQueries.forEach(({ query, response }) => {
    cacheResponse(query, response, 0);
  });

  console.log(
    `[ResponseCache] Preloaded ${commonQueries.length} common responses`
  );
}
