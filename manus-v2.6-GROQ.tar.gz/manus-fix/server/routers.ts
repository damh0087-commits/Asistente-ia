import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    sendMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().optional(),
          message: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { executeAgent } = await import("./agent");
        const {
          createConversation,
          createMessage,
          getMessagesByConversationId,
        } = await import("./db");

        // Crear conversación si no existe
        let conversationId = input.conversationId;
        if (!conversationId) {
          conversationId = await createConversation(ctx.user.id);
        }

        // Guardar mensaje del usuario
        await createMessage(conversationId, "user", input.message);

        // Obtener historial de mensajes
        const history = await getMessagesByConversationId(conversationId);
        const ollamaHistory = history.map((msg) => ({
          role: msg.role as "user" | "assistant" | "system" | "tool",
          content: msg.content,
        }));

        // Ejecutar agente
        const result = await executeAgent(input.message, ollamaHistory);

        // Guardar respuesta del asistente
        await createMessage(conversationId, "assistant", result.answer);

        // Notificar al propietario si la tarea fue compleja (más de 3 pasos)
        if (result.steps.length > 3) {
          try {
            const { notifyOwner } = await import("./_core/notification");
            await notifyOwner({
              title: "Tarea completada por el agente",
              content: `El usuario ${ctx.user.name} completó una tarea con ${result.steps.length} pasos. Mensaje: "${input.message.slice(0, 100)}..."`,
            });
          } catch (error) {
            console.error("Error enviando notificación:", error);
          }
        }

        return {
          conversationId,
          answer: result.answer,
          steps: result.steps,
        };
      }),

    getConversations: protectedProcedure.query(async ({ ctx }) => {
      const { getConversationsByUserId } = await import("./db");
      return getConversationsByUserId(ctx.user.id);
    }),

    getMessages: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        const { getMessagesByConversationId } = await import("./db");
        return getMessagesByConversationId(input.conversationId);
      }),

    getGeneratedFiles: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        const { getGeneratedFilesByConversationId } = await import("./db");
        return getGeneratedFilesByConversationId(input.conversationId);
      }),
  }),

  improvements: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const { getDb } = await import("./db");
      const db = await getDb();
      if (!db) return [];
      const { improvementProposals } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      const results = await db.select().from(improvementProposals).where(eq(improvementProposals.userId, ctx.user.id));
      return results.map(r => ({
        ...r,
        codeChanges: JSON.parse(r.codeChanges),
        benefits: JSON.parse(r.benefits),
        risks: JSON.parse(r.risks),
      }));
    }),
    approve: protectedProcedure.input(z.object({ id: z.string() })).mutation(async ({ ctx, input }) => {
      const { getDb } = await import("./db");
      const db = await getDb();
      if (!db) throw new Error("Database not available");
      const { improvementProposals } = await import("../drizzle/schema");
      const { eq, and } = await import("drizzle-orm");
      await db.update(improvementProposals)
        .set({ status: "approved", approvedAt: new Date() })
        .where(and(eq(improvementProposals.id, input.id), eq(improvementProposals.userId, ctx.user.id)));
      return { success: true };
    }),

    reject: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        const { improvementProposals } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        await db.update(improvementProposals)
          .set({ status: "rejected" })
          .where(and(eq(improvementProposals.id, input.id), eq(improvementProposals.userId, ctx.user.id)));
        return { success: true };
      }),

    applyImprovement: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        
        const { improvementProposals } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        
        // Obtener propuesta
        const proposals = await db.select().from(improvementProposals).where(
          and(eq(improvementProposals.id, input.id), eq(improvementProposals.userId, ctx.user.id))
        );
        
        if (proposals.length === 0) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Proposal not found" });
        }
        
        const proposal = proposals[0];
        
        if (proposal.status !== "approved") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Only approved proposals can be applied" });
        }
        
        // Aplicar mejora
        const { applyImprovement } = await import("./improvementApplicator");
        const result = await applyImprovement(
          parseInt(input.id),
          JSON.parse(proposal.codeChanges || "[]")
        );
        
        if (result.success) {
          // Actualizar estado a "applied"
          await db.update(improvementProposals)
            .set({ 
              status: "applied",
              appliedAt: new Date(),
            })
            .where(eq(improvementProposals.id, input.id));
          
          // Notificar al propietario
          const { notifyOwner } = await import("./_core/notification");
          await notifyOwner({
            title: "Mejora aplicada exitosamente",
            content: `La mejora "${proposal.title}" ha sido aplicada al sistema.`,
          });
        }
        
        return result;
      }),

    rollback: protectedProcedure
      .input(z.object({ id: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        
        const { improvementProposals } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        
        // Obtener propuesta
        const proposals = await db.select().from(improvementProposals).where(
          and(eq(improvementProposals.id, input.id), eq(improvementProposals.userId, ctx.user.id))
        );
        
        if (proposals.length === 0) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Proposal not found" });
        }
        
        const proposal = proposals[0];
        
        if (proposal.status !== "applied") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Only applied proposals can be rolled back" });
        }
        
        // TODO: Implementar rollback usando backupPath
        // const { manualRollback } = await import("./improvementApplicator");
        // const result = await manualRollback(proposal.backupPath);
        
        // Por ahora, solo cambiar el estado
        await db.update(improvementProposals)
          .set({ status: "approved" })
          .where(eq(improvementProposals.id, input.id));
        
        return { success: true, message: "Rollback completado" };
      }),
  }),

  files: router({
    upload: protectedProcedure
      .input(
        z.object({
          conversationId: z.number().optional(),
          filename: z.string(),
          mimeType: z.string(),
          size: z.number(),
          data: z.string(), // base64
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { storagePut } = await import("./storage");
        const { nanoid } = await import("nanoid");
        
        // Decodificar base64
        const buffer = Buffer.from(input.data, "base64");
        
        // Generar key único para S3
        const fileKey = `uploads/${ctx.user.id}/${nanoid()}-${input.filename}`;
        
        // Subir a S3
        const { url } = await storagePut(fileKey, buffer, input.mimeType);
        
        // Guardar en base de datos
        const { getDb } = await import("./db");
        const db = await getDb();
        if (db) {
          const { uploadedFiles } = await import("../drizzle/schema");
          await db.insert(uploadedFiles).values({
            conversationId: input.conversationId || 0,
            userId: ctx.user.id,
            filename: input.filename,
            fileKey,
            url,
            mimeType: input.mimeType,
            size: input.size,
          });
        }
        
        return {
          url,
          filename: input.filename,
          mimeType: input.mimeType,
        };
      }),

    list: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const { getDb } = await import("./db");
        const db = await getDb();
        if (!db) return [];
        const { uploadedFiles } = await import("../drizzle/schema");
        const { eq, and } = await import("drizzle-orm");
        return db.select().from(uploadedFiles).where(
          and(
            eq(uploadedFiles.conversationId, input.conversationId),
            eq(uploadedFiles.userId, ctx.user.id)
          )
        );
      }),
  }),
});

export type AppRouter = typeof appRouter;
