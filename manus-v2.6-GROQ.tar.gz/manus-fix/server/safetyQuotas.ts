/**
 * ✅ MÓDULO DE LÍMITES DE TASA Y CUOTAS DE SEGURIDAD
 * 
 * Características:
 * - Límites de mejoras por período
 * - Período de observación obligatorio
 * - Aprobación de admin para cambios de alto impacto
 * - Alertas automáticas
 * - Historial de violaciones
 */

export interface SafetyQuotas {
  maxImprovementsPerDay: number;
  maxImprovementsPerWeek: number;
  minObservationPeriodHours: number;
  requiresAdminApprovalForHighImpact: boolean;
  highImpactThreshold: "medium" | "high"; // Qué nivel requiere aprobación admin
}

export interface ImprovementRecord {
  id: string;
  proposalId: string;
  userId: number;
  appliedAt: Date;
  impact: "low" | "medium" | "high";
  status: "success" | "failed" | "rolled_back";
  metrics?: {
    performanceImpact: number; // % cambio en latencia
    errorRateChange: number; // % cambio en tasa de errores
    memoryImpact: number; // % cambio en memoria
  };
}

export interface QuotaStatus {
  userId: number;
  improvementsToday: number;
  improvementsThisWeek: number;
  lastImprovementAt: Date | null;
  hoursUntilNextAllowed: number;
  canApplyImprovement: boolean;
  requiresAdminApproval: boolean;
  reason?: string;
}

/**
 * Configuración de cuotas de seguridad
 */
const DEFAULT_QUOTAS: SafetyQuotas = {
  maxImprovementsPerDay: 1,
  maxImprovementsPerWeek: 3,
  minObservationPeriodHours: 24,
  requiresAdminApprovalForHighImpact: true,
  highImpactThreshold: "high",
};

/**
 * Historial de mejoras aplicadas
 */
let improvementHistory: ImprovementRecord[] = [];

/**
 * Verifica si se puede aplicar una mejora según las cuotas
 */
export async function checkSafetyQuotas(
  userId: number,
  proposalId: string,
  impactLevel: "low" | "medium" | "high",
  quotas: SafetyQuotas = DEFAULT_QUOTAS
): Promise<QuotaStatus> {
  const now = new Date();
  const status: QuotaStatus = {
    userId,
    improvementsToday: 0,
    improvementsThisWeek: 0,
    lastImprovementAt: null,
    hoursUntilNextAllowed: 0,
    canApplyImprovement: true,
    requiresAdminApproval: false,
  };

  // Obtener mejoras recientes del usuario
  const userImprovements = improvementHistory.filter(
    (record) => record.userId === userId && record.status === "success"
  );

  // Contar mejoras hoy
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  status.improvementsToday = userImprovements.filter(
    (record) => record.appliedAt >= today
  ).length;

  // Contar mejoras esta semana
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  status.improvementsThisWeek = userImprovements.filter(
    (record) => record.appliedAt >= weekAgo
  ).length;

  // Obtener última mejora
  if (userImprovements.length > 0) {
    status.lastImprovementAt = userImprovements[0].appliedAt;
  }

  // Verificar límite diario
  if (status.improvementsToday >= quotas.maxImprovementsPerDay) {
    status.canApplyImprovement = false;
    status.reason = `Límite diario alcanzado (${quotas.maxImprovementsPerDay} mejora(s) por día)`;
    console.warn(
      `[SafetyQuotas] ⚠️ Usuario ${userId} alcanzó límite diario para propuesta ${proposalId}`
    );
    return status;
  }

  // Verificar límite semanal
  if (status.improvementsThisWeek >= quotas.maxImprovementsPerWeek) {
    status.canApplyImprovement = false;
    status.reason = `Límite semanal alcanzado (${quotas.maxImprovementsPerWeek} mejoras por semana)`;
    console.warn(
      `[SafetyQuotas] ⚠️ Usuario ${userId} alcanzó límite semanal para propuesta ${proposalId}`
    );
    return status;
  }

  // Verificar período de observación
  if (status.lastImprovementAt) {
    const hoursSinceLastImprovement =
      (now.getTime() - status.lastImprovementAt.getTime()) / (1000 * 60 * 60);

    if (hoursSinceLastImprovement < quotas.minObservationPeriodHours) {
      status.canApplyImprovement = false;
      status.hoursUntilNextAllowed = Math.ceil(
        quotas.minObservationPeriodHours - hoursSinceLastImprovement
      );
      status.reason = `Período de observación activo. Próxima mejora disponible en ${status.hoursUntilNextAllowed} horas`;
      console.warn(
        `[SafetyQuotas] ⚠️ Usuario ${userId} necesita esperar período de observación para propuesta ${proposalId}`
      );
      return status;
    }
  }

  // Verificar si requiere aprobación de admin para impacto alto
  if (
    quotas.requiresAdminApprovalForHighImpact &&
    impactLevel === quotas.highImpactThreshold
  ) {
    status.requiresAdminApproval = true;
    console.log(
      `[SafetyQuotas] 👮 Propuesta ${proposalId} requiere aprobación de admin (impacto: ${impactLevel})`
    );
  }

  console.log(
    `[SafetyQuotas] ✅ Usuario ${userId} puede aplicar mejora para propuesta ${proposalId}`
  );
  return status;
}

/**
 * Registra una mejora aplicada
 */
export async function recordImprovementApplication(
  userId: number,
  proposalId: string,
  impactLevel: "low" | "medium" | "high",
  status: "success" | "failed" | "rolled_back",
  metrics?: {
    performanceImpact: number;
    errorRateChange: number;
    memoryImpact: number;
  }
): Promise<ImprovementRecord> {
  const record: ImprovementRecord = {
    id: `imp-${Date.now()}-${Math.random().toString(36).substring(7)}`,
    proposalId,
    userId,
    appliedAt: new Date(),
    impact: impactLevel,
    status,
    metrics,
  };

  improvementHistory.push(record);

  // Mantener solo últimos 1000 registros en memoria
  if (improvementHistory.length > 1000) {
    improvementHistory = improvementHistory.slice(-1000);
  }

  console.log(
    `[SafetyQuotas] 📝 Mejora registrada: ${record.id} (Usuario: ${userId}, Propuesta: ${proposalId}, Estado: ${status})`
  );

  return record;
}

/**
 * Obtiene estadísticas de cuotas para un usuario
 */
export function getUserQuotaStats(userId: number): {
  totalApplied: number;
  totalFailed: number;
  totalRolledBack: number;
  averageImpact: number;
  successRate: number;
  lastAppliedDate: Date | null;
} {
  const userRecords = improvementHistory.filter((record) => record.userId === userId);

  const successCount = userRecords.filter((r) => r.status === "success").length;
  const failedCount = userRecords.filter((r) => r.status === "failed").length;
  const rolledBackCount = userRecords.filter((r) => r.status === "rolled_back").length;

  const impactValues = userRecords
    .filter((r) => r.status === "success")
    .map((r) => {
      switch (r.impact) {
        case "low":
          return 1;
        case "medium":
          return 2;
        case "high":
          return 3;
      }
    });

  const averageImpact =
    impactValues.length > 0
      ? impactValues.reduce((a, b) => a + b, 0) / impactValues.length
      : 0;

  const successRate =
    userRecords.length > 0 ? (successCount / userRecords.length) * 100 : 0;

  return {
    totalApplied: successCount,
    totalFailed: failedCount,
    totalRolledBack: rolledBackCount,
    averageImpact,
    successRate,
    lastAppliedDate:
      userRecords.length > 0
        ? userRecords.sort((a, b) => b.appliedAt.getTime() - a.appliedAt.getTime())[0]
            .appliedAt
        : null,
  };
}

/**
 * Obtiene historial de mejoras para un usuario
 */
export function getUserImprovementHistory(
  userId: number,
  limit: number = 20
): ImprovementRecord[] {
  return improvementHistory
    .filter((record) => record.userId === userId)
    .sort((a, b) => b.appliedAt.getTime() - a.appliedAt.getTime())
    .slice(0, limit);
}

/**
 * Genera reporte de cuotas
 */
export function generateQuotasReport(userId: number): string {
  const stats = getUserQuotaStats(userId);
  const history = getUserImprovementHistory(userId, 10);

  let report = `
╔════════════════════════════════════════════════════════════════╗
║                  REPORTE DE CUOTAS Y SEGURIDAD                ║
╚════════════════════════════════════════════════════════════════╝

👤 Usuario: ${userId}

📊 ESTADÍSTICAS GENERALES:
  • Total aplicadas: ${stats.totalApplied}
  • Fallidas: ${stats.totalFailed}
  • Revertidas: ${stats.totalRolledBack}
  • Tasa de éxito: ${stats.successRate.toFixed(2)}%
  • Impacto promedio: ${stats.averageImpact.toFixed(2)}/3
  • Última aplicada: ${stats.lastAppliedDate ? stats.lastAppliedDate.toLocaleString() : "Nunca"}

📋 ÚLTIMAS MEJORAS (últimas 10):
`;

  for (const record of history) {
    const statusEmoji =
      record.status === "success"
        ? "✅"
        : record.status === "failed"
          ? "❌"
          : "↩️ ";
    const impactEmoji =
      record.impact === "low" ? "🟢" : record.impact === "medium" ? "🟡" : "🔴";

    report += `
  ${statusEmoji} ${record.proposalId}
     Fecha: ${record.appliedAt.toLocaleString()}
     Impacto: ${impactEmoji} ${record.impact}
     Estado: ${record.status}`;

    if (record.metrics) {
      report += `
     Métricas:
       - Rendimiento: ${record.metrics.performanceImpact > 0 ? "+" : ""}${record.metrics.performanceImpact.toFixed(2)}%
       - Tasa de errores: ${record.metrics.errorRateChange > 0 ? "+" : ""}${record.metrics.errorRateChange.toFixed(2)}%
       - Memoria: ${record.metrics.memoryImpact > 0 ? "+" : ""}${record.metrics.memoryImpact.toFixed(2)}%`;
    }
  }

  return report;
}

/**
 * Verifica si hay violaciones de seguridad
 */
export function checkSecurityViolations(userId: number): string[] {
  const violations: string[] = [];
  const stats = getUserQuotaStats(userId);

  // Detectar tasa de fallo alta
  if (stats.totalApplied > 0 && stats.successRate < 50) {
    violations.push(
      `⚠️ Tasa de éxito baja (${stats.successRate.toFixed(2)}%). Revisar propuestas.`
    );
  }

  // Detectar patrón de cambios de alto impacto
  const recentHighImpact = improvementHistory
    .filter((r) => r.userId === userId && r.impact === "high")
    .filter((r) => {
      const dayAgo = new Date();
      dayAgo.setDate(dayAgo.getDate() - 1);
      return r.appliedAt >= dayAgo;
    });

  if (recentHighImpact.length > 1) {
    violations.push(
      `⚠️ Múltiples cambios de alto impacto en 24 horas (${recentHighImpact.length}). Proceder con cautela.`
    );
  }

  // Detectar rollbacks frecuentes
  const recentRollbacks = improvementHistory
    .filter((r) => r.userId === userId && r.status === "rolled_back")
    .filter((r) => {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return r.appliedAt >= weekAgo;
    });

  if (recentRollbacks.length > 2) {
    violations.push(
      `⚠️ Múltiples rollbacks esta semana (${recentRollbacks.length}). Revisar calidad de propuestas.`
    );
  }

  return violations;
}
