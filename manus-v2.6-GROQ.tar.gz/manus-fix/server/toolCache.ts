import { createHash } from "crypto";

/**
 * SISTEMA DE CACHÉ PARA HERRAMIENTAS
 * Evita ejecutar herramientas repetidamente - AHORRA TIEMPO Y RECURSOS
 */

interface CacheEntry<T = any> {
  result: T;
  timestamp: number;
  ttl: number;
  hits: number;
}

interface CacheStats {
  totalEntries: number;
  totalHits: number;
  totalMisses: number;
  hitRate: number;
  savedTime: number; // segundos ahorrados
}

/**
 * TTL por herramienta (en segundos)
 */
const DEFAULT_TTL: Record<string, number> = {
  search_web: 3600, // 1 hora
  navigate_to_url: 1800, // 30 minutos
  extract_data: 1800, // 30 minutos
  analyze_data: 7200, // 2 horas
  read_file: 300, // 5 minutos
  execute_code: 0, // NO cachear (side effects)
  list_files: 60, // 1 minuto
};

class ToolCache {
  private cache: Map<string, CacheEntry>;
  private hits: number = 0;
  private misses: number = 0;
  private savedTime: number = 0; // en milisegundos

  constructor() {
    this.cache = new Map();
    
    // Limpiar caché cada 5 minutos
    setInterval(() => this.cleanup(), 5 * 60 * 1000);
  }

  /**
   * Genera key única para herramienta + input
   */
  private generateKey(toolName: string, input: any): string {
    const inputStr = JSON.stringify(input, Object.keys(input).sort());
    const hash = createHash("sha256")
      .update(inputStr)
      .digest("hex")
      .substring(0, 16);
    return `${toolName}:${hash}`;
  }

  /**
   * Obtiene resultado del caché si existe y es válido
   */
  get<T = any>(
    toolName: string,
    input: any,
    avgExecutionTime?: number
  ): T | null {
    const key = this.generateKey(toolName, input);
    const entry = this.cache.get(key);

    if (!entry) {
      this.misses++;
      return null;
    }

    // Verificar si expiró
    const age = (Date.now() - entry.timestamp) / 1000;
    if (age > entry.ttl) {
      this.cache.delete(key);
      this.misses++;
      return null;
    }

    // ¡HIT! Incrementar contador
    entry.hits++;
    this.hits++;
    
    // Calcular tiempo ahorrado
    if (avgExecutionTime) {
      this.savedTime += avgExecutionTime;
    }

    console.log(
      `✅ Cache HIT: ${toolName} (age: ${Math.round(age)}s, hits: ${entry.hits}, saved: ${avgExecutionTime ? avgExecutionTime + 'ms' : 'N/A'})`
    );

    return entry.result as T;
  }

  /**
   * Guarda resultado en caché
   */
  set<T = any>(
    toolName: string,
    input: any,
    result: T,
    customTtl?: number
  ): void {
    const key = this.generateKey(toolName, input);
    const ttl = customTtl ?? DEFAULT_TTL[toolName] ?? 3600;

    // No cachear si TTL es 0
    if (ttl === 0) {
      return;
    }

    this.cache.set(key, {
      result,
      timestamp: Date.now(),
      ttl,
      hits: 0,
    });

    console.log(`💾 Cacheado: ${toolName} (TTL: ${ttl}s)`);
  }

  /**
   * Invalida caché de una herramienta
   */
  invalidate(toolName: string): void {
    const keysToDelete: string[] = [];

    for (const [key] of this.cache) {
      if (key.startsWith(`${toolName}:`)) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach((key) => this.cache.delete(key));
    
    if (keysToDelete.length > 0) {
      console.log(`🗑️  Invalidadas ${keysToDelete.length} entradas de ${toolName}`);
    }
  }

  /**
   * Limpia entradas expiradas
   */
  cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];

    for (const [key, entry] of this.cache) {
      const age = (now - entry.timestamp) / 1000;
      if (age > entry.ttl) {
        keysToDelete.push(key);
      }
    }

    keysToDelete.forEach((key) => this.cache.delete(key));

    if (keysToDelete.length > 0) {
      console.log(`🧹 Limpiadas ${keysToDelete.length} entradas expiradas`);
    }
  }

  /**
   * Limpia todo el caché
   */
  clear(): void {
    const size = this.cache.size;
    this.cache.clear();
    this.hits = 0;
    this.misses = 0;
    this.savedTime = 0;
    console.log(`🗑️  Caché limpiado completamente (${size} entradas)`);
  }

  /**
   * Obtiene estadísticas
   */
  getStats(): CacheStats {
    const totalRequests = this.hits + this.misses;
    const hitRate = totalRequests > 0 ? (this.hits / totalRequests) * 100 : 0;

    return {
      totalEntries: this.cache.size,
      totalHits: this.hits,
      totalMisses: this.misses,
      hitRate: parseFloat(hitRate.toFixed(2)),
      savedTime: parseFloat((this.savedTime / 1000).toFixed(2)), // convertir a segundos
    };
  }

  /**
   * Imprime estadísticas
   */
  printStats(): void {
    const stats = this.getStats();
    console.log("\n📊 Estadísticas del Caché:");
    console.log(`   Entradas: ${stats.totalEntries}`);
    console.log(`   Hits: ${stats.totalHits}`);
    console.log(`   Misses: ${stats.totalMisses}`);
    console.log(`   Hit Rate: ${stats.hitRate}%`);
    console.log(`   Tiempo Ahorrado: ${stats.savedTime}s\n`);
  }
}

// Instancia singleton
export const toolCache = new ToolCache();

/**
 * Ejecuta herramienta con caché automático
 */
export async function executeToolWithCache<T = any>(
  toolName: string,
  input: any,
  executor: () => Promise<T>,
  options?: {
    ttl?: number;
    skipCache?: boolean;
    avgExecutionTime?: number; // tiempo promedio de ejecución en ms
  }
): Promise<T> {
  // Si skipCache o no debe cachearse
  if (options?.skipCache || DEFAULT_TTL[toolName] === 0) {
    return await executor();
  }

  // Intentar obtener del caché
  const cachedResult = toolCache.get<T>(
    toolName,
    input,
    options?.avgExecutionTime
  );
  if (cachedResult !== null) {
    return cachedResult;
  }

  // No está en caché, ejecutar
  const startTime = Date.now();
  const result = await executor();
  const executionTime = Date.now() - startTime;

  // Guardar en caché
  toolCache.set(toolName, input, result, options?.ttl);

  console.log(`⏱️  ${toolName} ejecutado en ${executionTime}ms`);

  return result;
}

/**
 * Middleware para agregar caché a una herramienta
 */
export function withCache<TInput = any, TOutput = any>(
  toolName: string,
  toolFunction: (input: TInput) => Promise<TOutput>,
  ttl?: number
): (input: TInput) => Promise<TOutput> {
  return async (input: TInput): Promise<TOutput> => {
    return executeToolWithCache(
      toolName,
      input,
      () => toolFunction(input),
      { ttl }
    );
  };
}

// Exportar funciones útiles
export function getCacheStats(): CacheStats {
  return toolCache.getStats();
}

export function clearCache(): void {
  toolCache.clear();
}

export function invalidateToolCache(toolName: string): void {
  toolCache.invalidate(toolName);
}

export function printCacheStats(): void {
  toolCache.printStats();
}
