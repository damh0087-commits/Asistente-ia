import { describe, it, expect, beforeAll } from "vitest";
import {
  TextToSpeechInputSchema,
  GenerateProjectInputSchema,
  SelfImprovementInputSchema,
  validateToolInput,
} from "./toolValidation";

describe("Tool Validation", () => {
  describe("TextToSpeechInputSchema", () => {
    it("should validate correct input", () => {
      const input = { text: "Hello world" };
      const result = validateToolInput(
        TextToSpeechInputSchema,
        input,
        "generate_audio"
      );
      expect(result.text).toBe("Hello world");
      expect(result.language).toBe("es"); // default
    });

    it("should reject empty text", () => {
      const input = { text: "" };
      expect(() =>
        validateToolInput(TextToSpeechInputSchema, input, "generate_audio")
      ).toThrow("El texto no puede estar vacío");
    });

    it("should reject text too long", () => {
      const input = { text: "a".repeat(10001) };
      expect(() =>
        validateToolInput(TextToSpeechInputSchema, input, "generate_audio")
      ).toThrow("demasiado largo");
    });

    it("should validate language", () => {
      const input = { text: "Hello", language: "en" as const };
      const result = validateToolInput(
        TextToSpeechInputSchema,
        input,
        "generate_audio"
      );
      expect(result.language).toBe("en");
    });

    it("should reject invalid language", () => {
      const input = { text: "Hello", language: "invalid" };
      expect(() =>
        validateToolInput(TextToSpeechInputSchema, input, "generate_audio")
      ).toThrow("Idioma debe ser");
    });

    it("should validate rate range", () => {
      const input = { text: "Hello", rate: 200 };
      const result = validateToolInput(
        TextToSpeechInputSchema,
        input,
        "generate_audio"
      );
      expect(result.rate).toBe(200);
    });

    it("should reject rate out of range", () => {
      const input = { text: "Hello", rate: 400 };
      expect(() =>
        validateToolInput(TextToSpeechInputSchema, input, "generate_audio")
      ).toThrow("velocidad máxima");
    });
  });

  describe("GenerateProjectInputSchema", () => {
    it("should validate correct input", () => {
      const input = {
        template: "react-app" as const,
        projectName: "my-app",
      };
      const result = validateToolInput(
        GenerateProjectInputSchema,
        input,
        "generate_project"
      );
      expect(result.template).toBe("react-app");
      expect(result.projectName).toBe("my-app");
    });

    it("should reject invalid template", () => {
      const input = { template: "invalid-template", projectName: "my-app" };
      expect(() =>
        validateToolInput(GenerateProjectInputSchema, input, "generate_project")
      ).toThrow("Template debe ser");
    });

    it("should reject empty project name", () => {
      const input = { template: "react-app", projectName: "" };
      expect(() =>
        validateToolInput(GenerateProjectInputSchema, input, "generate_project")
      ).toThrow("no puede estar vacío");
    });

    it("should reject invalid characters in project name", () => {
      const input = { template: "react-app", projectName: "my app!" };
      expect(() =>
        validateToolInput(GenerateProjectInputSchema, input, "generate_project")
      ).toThrow("solo puede contener");
    });

    it("should accept valid project names", () => {
      const validNames = [
        "my-app",
        "my_app",
        "MyApp",
        "app123",
        "my-cool-app_v2",
      ];

      validNames.forEach((name) => {
        const input = { template: "react-app" as const, projectName: name };
        const result = validateToolInput(
          GenerateProjectInputSchema,
          input,
          "generate_project"
        );
        expect(result.projectName).toBe(name);
      });
    });
  });

  describe("SelfImprovementInputSchema", () => {
    it("should validate correct input", () => {
      const input = { query: "optimize cache performance" };
      const result = validateToolInput(
        SelfImprovementInputSchema,
        input,
        "propose_self_improvement"
      );
      expect(result.query).toBe("optimize cache performance");
    });

    it("should reject query too short", () => {
      const input = { query: "opt" };
      expect(() =>
        validateToolInput(
          SelfImprovementInputSchema,
          input,
          "propose_self_improvement"
        )
      ).toThrow("al menos 5 caracteres");
    });

    it("should reject query too long", () => {
      const input = { query: "a".repeat(501) };
      expect(() =>
        validateToolInput(
          SelfImprovementInputSchema,
          input,
          "propose_self_improvement"
        )
      ).toThrow("demasiado larga");
    });

    it("should accept optional context", () => {
      const input = {
        query: "improve error handling",
        context: "Current system uses basic try-catch",
      };
      const result = validateToolInput(
        SelfImprovementInputSchema,
        input,
        "propose_self_improvement"
      );
      expect(result.context).toBe("Current system uses basic try-catch");
    });
  });
});

describe("Integration Tests (require external dependencies)", () => {
  // Estos tests requieren pyttsx3, navegador, etc.
  // Se marcan como skip si las dependencias no están disponibles

  it.skip("textToSpeech should generate audio file", async () => {
    // Test requiere pyttsx3 instalado
    const { generateTextToSpeech } = await import("./tools/textToSpeech");

    const result = await generateTextToSpeech({
      text: "Test audio generation",
      language: "en",
    });

    expect(result.success).toBe(true);
    expect(result.audioPath).toBeDefined();
  });

  it.skip("projectGenerator should create files", async () => {
    // Test requiere sistema de archivos
    const { generateProject } = await import("./tools/projectGenerator");

    const result = await generateProject({
      template: "react-app",
      projectName: "test-app",
    });

    expect(result.success).toBe(true);
    expect(result.filesCreated).toBeGreaterThan(0);
  });
});
