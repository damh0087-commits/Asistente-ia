import { z } from "zod";

/**
 * SISTEMA DE VALIDACIÓN CON ZOD PARA HERRAMIENTAS
 * Valida inputs y proporciona mensajes de error claros al LLM
 */

// ============================================================================
// SCHEMAS DE VALIDACIÓN
// ============================================================================

export const SearchInputSchema = z.object({
  query: z
    .string()
    .min(1, "La query no puede estar vacía")
    .max(500, "La query es demasiado larga (máximo 500 caracteres)"),
  maxResults: z
    .number()
    .int("maxResults debe ser un entero")
    .min(1, "Debes solicitar al menos 1 resultado")
    .max(20, "Máximo 20 resultados por búsqueda")
    .default(5)
    .optional(),
});

export const NavigateInputSchema = z.object({
  url: z
    .string()
    .url("Debe ser una URL válida (ej: https://example.com)")
    .refine(
      (url) => url.startsWith("http://") || url.startsWith("https://"),
      "La URL debe comenzar con http:// o https://"
    ),
  waitForSelector: z
    .string()
    .optional()
    .describe("Selector CSS a esperar antes de extraer contenido"),
});

export const ExtractDataInputSchema = z.object({
  url: z.string().url("Debe ser una URL válida"),
  selectors: z
    .record(z.string(), z.string())
    .describe("Mapa de nombre -> selector CSS")
    .refine(
      (selectors) => Object.keys(selectors).length > 0,
      "Debes proporcionar al menos un selector"
    ),
});

export const ExecuteCodeInputSchema = z.object({
  language: z.enum(["python", "javascript"], {
    errorMap: () => ({
      message: "El lenguaje debe ser 'python' o 'javascript'",
    }),
  }),
  code: z
    .string()
    .min(1, "El código no puede estar vacío")
    .max(50000, "El código es demasiado largo (máximo 50000 caracteres)"),
  timeout: z
    .number()
    .int()
    .min(1, "El timeout mínimo es 1 segundo")
    .max(60, "El timeout máximo es 60 segundos")
    .default(10)
    .optional(),
});

export const AnalyzeDataInputSchema = z.object({
  data: z.union([
    z.string().describe("Datos en formato CSV o JSON string"),
    z.array(z.record(z.unknown())).describe("Array de objetos"),
  ]),
  operation: z.enum(
    ["describe", "filter", "aggregate", "correlate", "plot"],
    {
      errorMap: () => ({
        message:
          "Operación debe ser: 'describe', 'filter', 'aggregate', 'correlate', o 'plot'",
      }),
    }
  ),
  parameters: z
    .record(z.unknown())
    .optional()
    .describe("Parámetros específicos de la operación"),
});

export const FileReadInputSchema = z.object({
  filename: z
    .string()
    .min(1, "El nombre de archivo no puede estar vacío")
    .max(255, "El nombre de archivo es demasiado largo")
    .refine(
      (name) => !name.includes("..") && !name.startsWith("/"),
      "Nombre de archivo no válido (no se permiten '..' o rutas absolutas)"
    ),
});

export const FileWriteInputSchema = z.object({
  filename: z
    .string()
    .min(1, "El nombre de archivo no puede estar vacío")
    .max(255, "El nombre de archivo es demasiado largo")
    .refine(
      (name) => !name.includes("..") && !name.startsWith("/"),
      "Nombre de archivo no válido (no se permiten '..' o rutas absolutas)"
    ),
  content: z
    .string()
    .max(10000000, "El contenido es demasiado grande (máximo 10MB)"),
  encoding: z
    .enum(["utf-8", "base64"])
    .default("utf-8")
    .optional(),
});

export const FileListInputSchema = z.object({
  path: z
    .string()
    .default("")
    .optional()
    .refine(
      (path) => !path || (!path.includes("..") && !path.startsWith("/")),
      "Path no válido (no se permiten '..' o rutas absolutas)"
    ),
});

// ✅ NUEVOS SCHEMAS PARA HERRAMIENTAS V2.1

export const TextToSpeechInputSchema = z.object({
  text: z
    .string()
    .min(1, "El texto no puede estar vacío")
    .max(10000, "El texto es demasiado largo (máximo 10,000 caracteres)"),
  language: z
    .enum(["es", "en", "fr", "de", "it", "pt"], {
      errorMap: () => ({
        message: "Idioma debe ser: 'es', 'en', 'fr', 'de', 'it', o 'pt'",
      }),
    })
    .default("es")
    .optional(),
  rate: z
    .number()
    .int("rate debe ser un entero")
    .min(50, "La velocidad mínima es 50")
    .max(300, "La velocidad máxima es 300")
    .default(150)
    .optional(),
  volume: z
    .number()
    .min(0, "El volumen mínimo es 0.0")
    .max(1, "El volumen máximo es 1.0")
    .default(1.0)
    .optional(),
  voice: z
    .enum(["male", "female"], {
      errorMap: () => ({
        message: "Voz debe ser: 'male' o 'female'",
      }),
    })
    .default("female")
    .optional(),
});

export const GenerateProjectInputSchema = z.object({
  template: z.enum(
    [
      "react-app",
      "express-api",
      "flask-app",
      "chrome-extension",
      "electron-app",
      "react-native",
      "android-app",
      "cli-tool",
      "discord-bot",
      "web-scraper",
      "nextjs-app",
      "vue-app",
      "fastapi",
      "django-rest-api",
      "telegram-bot",
      "svelte-app",
      "gatsby-blog",
      "wordpress-plugin",
      "unity-game",
      "ios-app",
    ],
    {
      errorMap: () => ({
        message:
          "Template debe ser uno de: react-app, express-api, flask-app, chrome-extension, electron-app, react-native, android-app, cli-tool, discord-bot, web-scraper, nextjs-app, vue-app, fastapi, django-rest-api, telegram-bot, svelte-app, gatsby-blog, wordpress-plugin, unity-game, ios-app",
      }),
    }
  ),
  projectName: z
    .string()
    .min(1, "El nombre del proyecto no puede estar vacío")
    .max(100, "El nombre del proyecto es demasiado largo")
    .regex(
      /^[a-zA-Z0-9-_]+$/,
      "El nombre del proyecto solo puede contener letras, números, guiones y guiones bajos"
    ),
  description: z
    .string()
    .max(500, "La descripción es demasiado larga (máximo 500 caracteres)")
    .optional(),
  features: z.array(z.string()).optional(),
});

export const SelfImprovementInputSchema = z.object({
  query: z
    .string()
    .min(5, "La query debe tener al menos 5 caracteres")
    .max(500, "La query es demasiado larga (máximo 500 caracteres)"),
  context: z
    .string()
    .max(2000, "El contexto es demasiado largo (máximo 2000 caracteres)")
    .optional(),
});

// ============================================================================
// TIPOS TYPESCRIPT INFERIDOS
// ============================================================================

export type SearchInput = z.infer<typeof SearchInputSchema>;
export type NavigateInput = z.infer<typeof NavigateInputSchema>;
export type ExtractDataInput = z.infer<typeof ExtractDataInputSchema>;
export type ExecuteCodeInput = z.infer<typeof ExecuteCodeInputSchema>;
export type AnalyzeDataInput = z.infer<typeof AnalyzeDataInputSchema>;
export type FileReadInput = z.infer<typeof FileReadInputSchema>;
export type FileWriteInput = z.infer<typeof FileWriteInputSchema>;
export type FileListInput = z.infer<typeof FileListInputSchema>;
export type TextToSpeechInput = z.infer<typeof TextToSpeechInputSchema>;
export type GenerateProjectInput = z.infer<typeof GenerateProjectInputSchema>;
export type SelfImprovementInput = z.infer<typeof SelfImprovementInputSchema>;

// ============================================================================
// HELPER PARA VALIDACIÓN
// ============================================================================

/**
 * Valida input y retorna resultado type-safe
 * Si falla, lanza error con mensaje claro para el LLM
 */
export function validateToolInput<T extends z.ZodType>(
  schema: T,
  input: unknown,
  toolName: string
): z.infer<T> {
  try {
    return schema.parse(input);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const issues = error.issues
        .map((issue) => {
          const path = issue.path.join(".");
          return `- ${path || "root"}: ${issue.message}`;
        })
        .join("\n");

      throw new Error(
        `❌ Parámetros inválidos para ${toolName}:\n${issues}\n\n` +
          `Por favor, corrige los parámetros y vuelve a intentar.`
      );
    }
    throw error;
  }
}
