import { describe, expect, it } from "vitest";

describe("Agent Tools", () => {
  describe("Image Generator", () => {
    it("should have correct tool definition", async () => {
      const { imageGeneratorTool } = await import("./tools/imageGenerator");
      
      expect(imageGeneratorTool.type).toBe("function");
      expect(imageGeneratorTool.function.name).toBe("generate_image");
      expect(imageGeneratorTool.function.parameters.required).toContain("prompt");
    });
  });

  describe("Audio Transcriber", () => {
    it("should have correct tool definition", async () => {
      const { audioTranscriberTool } = await import("./tools/audioTranscriber");
      
      expect(audioTranscriberTool.type).toBe("function");
      expect(audioTranscriberTool.function.name).toBe("transcribe_audio");
      expect(audioTranscriberTool.function.parameters.required).toContain("audioUrl");
    });
  });

  describe("Web Scraper", () => {
    it("should have correct tool definition", async () => {
      const { webScraperTool } = await import("./tools/webScraper");
      
      expect(webScraperTool.type).toBe("function");
      expect(webScraperTool.function.name).toBe("scrape_web");
      expect(webScraperTool.function.parameters.required).toContain("url");
    });
  });

  describe("Self Improvement", () => {
    it("should have correct tool definition", async () => {
      const { selfImprovementTool } = await import("./tools/selfImprovement");
      
      expect(selfImprovementTool.type).toBe("function");
      expect(selfImprovementTool.function.name).toBe("propose_self_improvement");
      expect(selfImprovementTool.function.parameters.required).toContain("query");
    });
  });
});
