import { chromium, Browser, Page } from "playwright";

let browserInstance: Browser | null = null;

/**
 * Obtiene o crea una instancia del navegador
 */
async function getBrowser(): Promise<Browser> {
  if (!browserInstance || !browserInstance.isConnected()) {
    browserInstance = await chromium.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
  }
  return browserInstance;
}

export interface NavigateToolInput {
  url: string;
  waitForSelector?: string;
}

export interface NavigateToolOutput {
  title: string;
  url: string;
  content: string;
  screenshot?: string;
}

/**
 * Navega a una URL y extrae el contenido
 */
export async function navigateToUrl(
  input: NavigateToolInput
): Promise<NavigateToolOutput> {
  const { url, waitForSelector } = input;
  let page: Page | null = null;

  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });

    if (waitForSelector) {
      await page.waitForSelector(waitForSelector, { timeout: 10000 });
    }

    const title = await page.title();
    const content = await page.evaluate(() => {
      // Extraer texto visible del body
      const body = document.body;
      return body.innerText || body.textContent || "";
    });

    return {
      title,
      url: page.url(),
      content: content.slice(0, 5000), // Limitar a 5000 caracteres
    };
  } catch (error) {
    throw new Error(
      `Error navegando a ${url}: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  } finally {
    if (page) {
      await page.close();
    }
  }
}

export interface ExtractDataToolInput {
  url: string;
  selector: string;
}

export interface ExtractDataToolOutput {
  data: string[];
}

/**
 * Extrae datos de una página usando un selector CSS
 */
export async function extractData(
  input: ExtractDataToolInput
): Promise<ExtractDataToolOutput> {
  const { url, selector } = input;
  let page: Page | null = null;

  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });
    await page.waitForSelector(selector, { timeout: 10000 });

    const data = await page.evaluate((sel) => {
      const elements = document.querySelectorAll(sel);
      return Array.from(elements).map((el) => el.textContent?.trim() || "");
    }, selector);

    return { data };
  } catch (error) {
    throw new Error(
      `Error extrayendo datos de ${url}: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  } finally {
    if (page) {
      await page.close();
    }
  }
}

/**
 * Cierra el navegador
 */
export async function closeBrowser(): Promise<void> {
  if (browserInstance) {
    await browserInstance.close();
    browserInstance = null;
  }
}

/**
 * Definición de la herramienta de navegación para el agente
 */
export const navigateToolDefinition = {
  type: "function" as const,
  function: {
    name: "navigate_to_url",
    description:
      "Navega a una URL y extrae el contenido de texto de la página. Útil para leer artículos, documentación, páginas web, etc.",
    parameters: {
      type: "object",
      properties: {
        url: {
          type: "string",
          description: "La URL a visitar",
        },
        waitForSelector: {
          type: "string",
          description:
            "Selector CSS opcional para esperar antes de extraer contenido",
        },
      },
      required: ["url"],
    },
  },
};

/**
 * Definición de la herramienta de extracción para el agente
 */
export const extractDataToolDefinition = {
  type: "function" as const,
  function: {
    name: "extract_data",
    description:
      "Extrae datos específicos de una página web usando un selector CSS. Útil para scraping de listas, tablas, etc.",
    parameters: {
      type: "object",
      properties: {
        url: {
          type: "string",
          description: "La URL de la página",
        },
        selector: {
          type: "string",
          description: "Selector CSS para encontrar los elementos",
        },
      },
      required: ["url", "selector"],
    },
  },
};
