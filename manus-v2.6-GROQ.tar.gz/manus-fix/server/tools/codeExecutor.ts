import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, unlink, mkdir } from "fs/promises";
import { join } from "path";
import { randomBytes } from "crypto";

const execAsync = promisify(exec);

export interface CodeExecutorInput {
  code: string;
  language?: "python" | "javascript" | "bash";
  timeout?: number;
}

export interface CodeExecutorOutput {
  stdout: string;
  stderr: string;
  exitCode: number;
  executionTime: number;
}

/**
 * Ejecuta código Python en un sandbox seguro
 */
export async function executePythonCode(
  input: CodeExecutorInput
): Promise<CodeExecutorOutput> {
  const { code, timeout = 30000 } = input;
  const startTime = Date.now();

  // Crear directorio temporal si no existe
  const tmpDir = "/tmp/agent-code-execution";
  try {
    await mkdir(tmpDir, { recursive: true });
  } catch {
    // Directorio ya existe
  }

  // Generar nombre de archivo único
  const fileName = `script_${randomBytes(8).toString("hex")}.py`;
  const filePath = join(tmpDir, fileName);

  try {
    // Escribir código a archivo temporal
    await writeFile(filePath, code, "utf-8");

    // Ejecutar con timeout
    const { stdout, stderr } = await execAsync(
      `python3.11 "${filePath}"`,
      {
        timeout,
        maxBuffer: 1024 * 1024 * 10, // 10MB
        env: {
          ...process.env,
          PYTHONUNBUFFERED: "1",
        },
      }
    );

    const executionTime = Date.now() - startTime;

    return {
      stdout: stdout || "",
      stderr: stderr || "",
      exitCode: 0,
      executionTime,
    };
  } catch (error: any) {
    const executionTime = Date.now() - startTime;

    return {
      stdout: error.stdout || "",
      stderr: error.stderr || error.message || "Error desconocido",
      exitCode: error.code || 1,
      executionTime,
    };
  } finally {
    // Limpiar archivo temporal
    try {
      await unlink(filePath);
    } catch {
      // Ignorar errores de limpieza
    }
  }
}

/**
 * Ejecuta código JavaScript/Node.js
 */
export async function executeJavaScriptCode(
  input: CodeExecutorInput
): Promise<CodeExecutorOutput> {
  const { code, timeout = 30000 } = input;
  const startTime = Date.now();

  const tmpDir = "/tmp/agent-code-execution";
  try {
    await mkdir(tmpDir, { recursive: true });
  } catch {
    // Directorio ya existe
  }

  const fileName = `script_${randomBytes(8).toString("hex")}.js`;
  const filePath = join(tmpDir, fileName);

  try {
    await writeFile(filePath, code, "utf-8");

    const { stdout, stderr } = await execAsync(
      `node "${filePath}"`,
      {
        timeout,
        maxBuffer: 1024 * 1024 * 10,
      }
    );

    const executionTime = Date.now() - startTime;

    return {
      stdout: stdout || "",
      stderr: stderr || "",
      exitCode: 0,
      executionTime,
    };
  } catch (error: any) {
    const executionTime = Date.now() - startTime;

    return {
      stdout: error.stdout || "",
      stderr: error.stderr || error.message || "Error desconocido",
      exitCode: error.code || 1,
      executionTime,
    };
  } finally {
    try {
      await unlink(filePath);
    } catch {
      // Ignorar errores de limpieza
    }
  }
}

/**
 * Ejecuta código según el lenguaje especificado
 */
export async function executeCode(
  input: CodeExecutorInput
): Promise<CodeExecutorOutput> {
  const { language = "python" } = input;

  switch (language) {
    case "python":
      return executePythonCode(input);
    case "javascript":
      return executeJavaScriptCode(input);
    case "bash":
      throw new Error("Ejecución de bash no permitida por seguridad");
    default:
      throw new Error(`Lenguaje no soportado: ${language}`);
  }
}

/**
 * Definición de la herramienta para el agente
 */
export const codeExecutorToolDefinition = {
  type: "function" as const,
  function: {
    name: "execute_code",
    description:
      "Ejecuta código Python o JavaScript en un entorno seguro. Útil para cálculos, procesamiento de datos, análisis, generación de gráficos, etc. El código se ejecuta con acceso a bibliotecas estándar.",
    parameters: {
      type: "object",
      properties: {
        code: {
          type: "string",
          description: "El código a ejecutar",
        },
        language: {
          type: "string",
          enum: ["python", "javascript"],
          description: "Lenguaje de programación (por defecto: python)",
        },
        timeout: {
          type: "number",
          description: "Timeout en milisegundos (por defecto: 30000)",
        },
      },
      required: ["code"],
    },
  },
};
