import { executePythonCode } from "./codeExecutor";

export interface DataAnalyzerInput {
  data: string; // CSV, JSON, o path a archivo
  operation:
    | "describe"
    | "plot"
    | "filter"
    | "aggregate"
    | "correlate"
    | "custom";
  parameters?: Record<string, any>;
}

export interface DataAnalyzerOutput {
  result: string;
  visualization?: string; // Base64 de imagen si se genera gráfico
  error?: string;
}

/**
 * Analiza datos usando Pandas
 */
export async function analyzeData(
  input: DataAnalyzerInput
): Promise<DataAnalyzerOutput> {
  const { data, operation, parameters = {} } = input;

  // Generar código Python según la operación
  let pythonCode = "";

  switch (operation) {
    case "describe":
      pythonCode = `
import pandas as pd
import json

# Cargar datos
data_str = '''${data}'''
try:
    df = pd.read_json(data_str)
except:
    from io import StringIO
    df = pd.read_csv(StringIO(data_str))

# Describir datos
description = df.describe().to_dict()
info = {
    'shape': df.shape,
    'columns': list(df.columns),
    'dtypes': {k: str(v) for k, v in df.dtypes.items()},
    'description': description
}
print(json.dumps(info, indent=2))
`;
      break;

    case "plot":
      pythonCode = `
import pandas as pd
import matplotlib.pyplot as plt
import base64
from io import BytesIO, StringIO

data_str = '''${data}'''
try:
    df = pd.read_json(data_str)
except:
    df = pd.read_csv(StringIO(data_str))

# Crear gráfico
plt.figure(figsize=(10, 6))
plot_type = '${parameters.plotType || "line"}'

if plot_type == 'line':
    df.plot(kind='line')
elif plot_type == 'bar':
    df.plot(kind='bar')
elif plot_type == 'scatter' and len(df.columns) >= 2:
    plt.scatter(df.iloc[:, 0], df.iloc[:, 1])
elif plot_type == 'hist':
    df.plot(kind='hist', alpha=0.7)
else:
    df.plot()

plt.title('${parameters.title || "Data Visualization"}')
plt.tight_layout()

# Guardar como base64
buffer = BytesIO()
plt.savefig(buffer, format='png', dpi=100)
buffer.seek(0)
img_base64 = base64.b64encode(buffer.read()).decode()
print(f"PLOT_DATA:{img_base64}")
plt.close()
`;
      break;

    case "filter":
      pythonCode = `
import pandas as pd
from io import StringIO

data_str = '''${data}'''
try:
    df = pd.read_json(data_str)
except:
    df = pd.read_csv(StringIO(data_str))

# Filtrar datos
condition = "${parameters.condition || 'True'}"
filtered_df = df.query(condition) if condition != 'True' else df

print(filtered_df.to_json(orient='records', indent=2))
`;
      break;

    case "aggregate":
      pythonCode = `
import pandas as pd
from io import StringIO

data_str = '''${data}'''
try:
    df = pd.read_json(data_str)
except:
    df = pd.read_csv(StringIO(data_str))

# Agregar datos
group_by = ${JSON.stringify(parameters.groupBy || [])}
agg_func = '${parameters.aggFunc || "mean"}'

if group_by:
    result = df.groupby(group_by).agg(agg_func)
else:
    result = df.agg(agg_func)

print(result.to_json(indent=2))
`;
      break;

    case "correlate":
      pythonCode = `
import pandas as pd
from io import StringIO

data_str = '''${data}'''
try:
    df = pd.read_json(data_str)
except:
    df = pd.read_csv(StringIO(data_str))

# Calcular correlaciones
numeric_df = df.select_dtypes(include=['number'])
correlation = numeric_df.corr()

print(correlation.to_json(indent=2))
`;
      break;

    case "custom":
      pythonCode = parameters.code || "print('No custom code provided')";
      break;

    default:
      throw new Error(`Operación no soportada: ${operation}`);
  }

  try {
    const result = await executePythonCode({ code: pythonCode });

    if (result.exitCode !== 0) {
      return {
        result: "",
        error: result.stderr,
      };
    }

    // Extraer visualización si existe
    const stdout = result.stdout;
    const plotMatch = stdout.match(/PLOT_DATA:([A-Za-z0-9+/=]+)/);

    if (plotMatch) {
      return {
        result: stdout.replace(/PLOT_DATA:[A-Za-z0-9+/=]+/, "").trim(),
        visualization: plotMatch[1],
      };
    }

    return {
      result: stdout,
    };
  } catch (error) {
    return {
      result: "",
      error: error instanceof Error ? error.message : "Error desconocido",
    };
  }
}

/**
 * Definición de la herramienta para el agente
 */
export const dataAnalyzerToolDefinition = {
  type: "function" as const,
  function: {
    name: "analyze_data",
    description:
      "Analiza datos usando Pandas. Puede describir estadísticas, crear gráficos, filtrar, agregar, calcular correlaciones o ejecutar código personalizado. Acepta datos en formato CSV o JSON.",
    parameters: {
      type: "object",
      properties: {
        data: {
          type: "string",
          description: "Datos en formato CSV o JSON",
        },
        operation: {
          type: "string",
          enum: ["describe", "plot", "filter", "aggregate", "correlate", "custom"],
          description: "Tipo de análisis a realizar",
        },
        parameters: {
          type: "object",
          description:
            "Parámetros adicionales según la operación (plotType, condition, groupBy, aggFunc, code, etc.)",
        },
      },
      required: ["data", "operation"],
    },
  },
};
