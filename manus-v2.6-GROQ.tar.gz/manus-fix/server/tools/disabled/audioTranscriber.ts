import { transcribeAudio } from "../_core/voiceTranscription";

export interface AudioTranscriberInput {
  audioUrl: string;
  language?: string;
  prompt?: string;
}

export interface AudioTranscriberOutput {
  success: boolean;
  text?: string;
  language?: string;
  segments?: Array<{
    start: number;
    end: number;
    text: string;
  }>;
  error?: string;
}

/**
 * Herramienta de transcripción de audio usando Whisper API
 */
export async function executeAudioTranscriber(
  input: AudioTranscriberInput
): Promise<AudioTranscriberOutput> {
  try {
    console.log(`[AudioTranscriber] Transcribiendo audio: ${input.audioUrl}`);

    const result = await transcribeAudio({
      audioUrl: input.audioUrl,
      language: input.language,
      prompt: input.prompt,
    });

    console.log(`[AudioTranscriber] Transcripción completada: ${(result as any).text.substring(0, 100)}...`);

    return {
      success: true,
      text: (result as any).text,
      language: (result as any).language,
      segments: (result as any).segments?.map((seg: any) => ({
        start: seg.start,
        end: seg.end,
        text: seg.text,
      })),
    };
  } catch (error: any) {
    console.error("[AudioTranscriber] Error:", error);
    return {
      success: false,
      error: error.message || "Error al transcribir el audio",
    };
  }
}

export const audioTranscriberTool = {
  type: "function" as const,
  function: {
    name: "transcribe_audio",
    description:
      "Transcribe audio a texto usando Whisper API. Soporta múltiples idiomas y formatos (webm, mp3, wav, ogg, m4a). Útil para transcribir entrevistas, podcasts, reuniones, notas de voz, etc.",
    parameters: {
      type: "object",
      properties: {
        audioUrl: {
          type: "string",
          description: "URL del archivo de audio a transcribir (debe ser accesible públicamente)",
        },
        language: {
          type: "string",
          description:
            "Código de idioma ISO-639-1 (opcional, ej: 'es', 'en', 'fr'). Ayuda a mejorar la precisión.",
        },
        prompt: {
          type: "string",
          description:
            "Contexto opcional para mejorar la transcripción (ej: 'Transcripción de reunión sobre IA')",
        },
      },
      required: ["audioUrl"],
    },
  },
};
