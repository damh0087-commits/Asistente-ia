import { generateImage } from "../_core/imageGeneration";

export interface ImageGeneratorInput {
  prompt: string;
  originalImages?: Array<{
    url: string;
    mimeType: string;
  }>;
}

export interface ImageGeneratorOutput {
  success: boolean;
  imageUrl?: string;
  error?: string;
}

/**
 * Herramienta de generación de imágenes usando el servicio integrado de Manus
 */
export async function executeImageGenerator(
  input: ImageGeneratorInput
): Promise<ImageGeneratorOutput> {
  try {
    console.log(`[ImageGenerator] Generando imagen: "${input.prompt}"`);

    const result = await generateImage({
      prompt: input.prompt,
      originalImages: input.originalImages,
    });

    console.log(`[ImageGenerator] Imagen generada exitosamente: ${result.url}`);

    return {
      success: true,
      imageUrl: result.url,
    };
  } catch (error: any) {
    console.error("[ImageGenerator] Error:", error);
    return {
      success: false,
      error: error.message || "Error al generar la imagen",
    };
  }
}

export const imageGeneratorTool = {
  type: "function" as const,
  function: {
    name: "generate_image",
    description:
      "Genera una imagen a partir de una descripción en texto. Útil para crear visualizaciones, ilustraciones, arte conceptual, diseños, etc. También puede editar imágenes existentes si se proporciona una imagen original.",
    parameters: {
      type: "object",
      properties: {
        prompt: {
          type: "string",
          description:
            "Descripción detallada de la imagen a generar. Sé específico sobre colores, estilo, composición, iluminación, etc.",
        },
        originalImages: {
          type: "array",
          description:
            "Opcional: Array de imágenes originales para editar. Cada imagen debe tener url y mimeType.",
          items: {
            type: "object",
            properties: {
              url: { type: "string" },
              mimeType: { type: "string" },
            },
            required: ["url", "mimeType"],
          },
        },
      },
      required: ["prompt"],
    },
  },
};
