import axios from "axios";

export interface VideoGeneratorInput {
  prompt: string;
  duration?: number; // segundos, por defecto 5
}

export interface VideoGeneratorOutput {
  success: boolean;
  videoUrl?: string;
  taskId?: string;
  message: string;
  error?: string;
}

/**
 * Genera un video desde texto usando Runway ML API
 * Requiere RUNWAY_API_KEY en variables de entorno
 */
export async function generateVideo(input: VideoGeneratorInput): Promise<VideoGeneratorOutput> {
  const apiKey = process.env.RUNWAY_API_KEY;
  
  if (!apiKey) {
    return {
      success: false,
      message: "Runway ML API key no configurada. Por favor, proporciona tu API key en la configuración.",
      error: "RUNWAY_API_KEY not set",
    };
  }
  
  try {
    // Paso 1: Crear tarea de generación de video
    const createResponse = await axios.post(
      "https://api.runwayml.com/v1/gen3/text-to-video",
      {
        prompt: input.prompt,
        duration: input.duration || 5,
      },
      {
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        timeout: 30000,
      }
    );
    
    const taskId = createResponse.data.id;
    
    // Paso 2: Esperar a que se complete la generación (polling)
    let attempts = 0;
    const maxAttempts = 60; // 5 minutos máximo
    
    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Esperar 5 segundos
      
      const statusResponse = await axios.get(
        `https://api.runwayml.com/v1/tasks/${taskId}`,
        {
          headers: {
            "Authorization": `Bearer ${apiKey}`,
          },
          timeout: 10000,
        }
      );
      
      const status = statusResponse.data.status;
      
      if (status === "SUCCEEDED") {
        return {
          success: true,
          videoUrl: statusResponse.data.output[0],
          taskId,
          message: "Video generado exitosamente",
        };
      } else if (status === "FAILED") {
        return {
          success: false,
          taskId,
          message: "La generación del video falló",
          error: statusResponse.data.error || "Unknown error",
        };
      }
      
      attempts++;
    }
    
    return {
      success: false,
      taskId,
      message: "Timeout: La generación del video está tomando demasiado tiempo",
      error: "Timeout",
    };
  } catch (error: any) {
    return {
      success: false,
      message: "Error al generar video",
      error: error.message,
    };
  }
}

/**
 * Definición de la herramienta para el agente
 */
export const videoGeneratorTool = {
  type: "function" as const,
  function: {
    name: "generate_video",
    description:
      "Genera un video corto desde una descripción en texto usando IA. Requiere API key de Runway ML configurada. El video puede tardar varios minutos en generarse.",
    parameters: {
      type: "object",
      properties: {
        prompt: {
          type: "string",
          description:
            "Descripción detallada del video a generar. Ejemplo: 'Un gato naranja caminando por un jardín soleado'",
        },
        duration: {
          type: "number",
          description: "Duración del video en segundos (por defecto: 5, máximo: 10)",
        },
      },
      required: ["prompt"],
    },
  },
};
