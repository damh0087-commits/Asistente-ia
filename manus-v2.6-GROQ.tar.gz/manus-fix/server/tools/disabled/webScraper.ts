import axios from "axios";
import * as cheerio from "cheerio";

export interface WebScraperInput {
  url: string;
  selector?: string;
  extractImages?: boolean;
  extractLinks?: boolean;
}

export interface WebScraperOutput {
  success: boolean;
  content?: string;
  images?: string[];
  links?: Array<{ text: string; url: string }>;
  error?: string;
}

/**
 * Herramienta de scraping web avanzado con extracción de contenido estructurado
 */
export async function executeWebScraper(
  input: WebScraperInput
): Promise<WebScraperOutput> {
  try {
    console.log(`[WebScraper] Scraping URL: ${input.url}`);

    const response = await axios.get(input.url, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
      timeout: 30000,
    });

    const $ = cheerio.load(response.data);

    let content = "";
    if (input.selector) {
      content = $(input.selector).text().trim();
    } else {
      // Extraer texto principal eliminando scripts y estilos
      $("script, style, nav, footer, header").remove();
      content = $("body").text().replace(/\s+/g, " ").trim();
    }

    const images: string[] = [];
    if (input.extractImages) {
      $("img").each((_: any, el: any) => {
        const src = $(el).attr("src");
        if (src) {
          const absoluteUrl = new URL(src, input.url).href;
          images.push(absoluteUrl);
        }
      });
    }

    const links: Array<{ text: string; url: string }> = [];
    if (input.extractLinks) {
      $("a").each((_: any, el: any) => {
        const href = $(el).attr("href");
        const text = $(el).text().trim();
        if (href && text) {
          try {
            const absoluteUrl = new URL(href, input.url).href;
            links.push({ text, url: absoluteUrl });
          } catch (e) {
            // Ignorar URLs inválidas
          }
        }
      });
    }

    console.log(`[WebScraper] Scraping completado: ${content.substring(0, 100)}...`);

    return {
      success: true,
      content,
      images: images.length > 0 ? images : undefined,
      links: links.length > 0 ? links : undefined,
    };
  } catch (error: any) {
    console.error("[WebScraper] Error:", error);
    return {
      success: false,
      error: error.message || "Error al hacer scraping de la página web",
    };
  }
}

export const webScraperTool = {
  type: "function" as const,
  function: {
    name: "scrape_web",
    description:
      "Extrae contenido estructurado de páginas web. Puede extraer texto, imágenes y enlaces. Útil para analizar sitios web, extraer datos, recopilar información, etc.",
    parameters: {
      type: "object",
      properties: {
        url: {
          type: "string",
          description: "URL de la página web a scrapear",
        },
        selector: {
          type: "string",
          description:
            "Selector CSS opcional para extraer contenido específico (ej: '.article-content', '#main-text')",
        },
        extractImages: {
          type: "boolean",
          description: "Si es true, extrae todas las URLs de imágenes de la página",
        },
        extractLinks: {
          type: "boolean",
          description: "Si es true, extrae todos los enlaces de la página con su texto",
        },
      },
      required: ["url"],
    },
  },
};
