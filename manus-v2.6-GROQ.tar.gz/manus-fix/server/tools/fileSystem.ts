import { readFile, writeFile, mkdir, readdir, stat } from "fs/promises";
import { join, dirname } from "path";

const WORKSPACE_DIR = "/tmp/agent-workspace";

/**
 * Inicializa el directorio de trabajo
 */
async function ensureWorkspace(): Promise<void> {
  try {
    await mkdir(WORKSPACE_DIR, { recursive: true });
  } catch {
    // Ya existe
  }
}

export interface FileReadInput {
  path: string;
}

export interface FileReadOutput {
  content: string;
  size: number;
}

/**
 * Lee un archivo del workspace
 */
export async function readFileFromWorkspace(
  input: FileReadInput
): Promise<FileReadOutput> {
  await ensureWorkspace();
  const filePath = join(WORKSPACE_DIR, input.path);

  try {
    const content = await readFile(filePath, "utf-8");
    const stats = await stat(filePath);

    return {
      content,
      size: stats.size,
    };
  } catch (error) {
    throw new Error(
      `Error leyendo archivo ${input.path}: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  }
}

export interface FileWriteInput {
  path: string;
  content: string;
}

export interface FileWriteOutput {
  path: string;
  size: number;
}

/**
 * Escribe un archivo en el workspace
 */
export async function writeFileToWorkspace(
  input: FileWriteInput
): Promise<FileWriteOutput> {
  await ensureWorkspace();
  const filePath = join(WORKSPACE_DIR, input.path);

  try {
    // Crear directorios padres si no existen
    await mkdir(dirname(filePath), { recursive: true });

    await writeFile(filePath, input.content, "utf-8");
    const stats = await stat(filePath);

    return {
      path: input.path,
      size: stats.size,
    };
  } catch (error) {
    throw new Error(
      `Error escribiendo archivo ${input.path}: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  }
}

export interface FileListInput {
  path?: string;
}

export interface FileListOutput {
  files: Array<{
    name: string;
    isDirectory: boolean;
    size: number;
  }>;
}

/**
 * Lista archivos en el workspace
 */
export async function listFilesInWorkspace(
  input: FileListInput
): Promise<FileListOutput> {
  await ensureWorkspace();
  const dirPath = join(WORKSPACE_DIR, input.path || "");

  try {
    const entries = await readdir(dirPath);
    const files = await Promise.all(
      entries.map(async (name) => {
        const fullPath = join(dirPath, name);
        const stats = await stat(fullPath);
        return {
          name,
          isDirectory: stats.isDirectory(),
          size: stats.size,
        };
      })
    );

    return { files };
  } catch (error) {
    throw new Error(
      `Error listando archivos en ${input.path || "/"}: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  }
}

/**
 * Definiciones de herramientas para el agente
 */
export const fileReadToolDefinition = {
  type: "function" as const,
  function: {
    name: "read_file",
    description:
      "Lee el contenido de un archivo del workspace. Útil para leer archivos generados previamente o datos guardados.",
    parameters: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Ruta relativa del archivo a leer",
        },
      },
      required: ["path"],
    },
  },
};

export const fileWriteToolDefinition = {
  type: "function" as const,
  function: {
    name: "write_file",
    description:
      "Escribe contenido en un archivo del workspace. Útil para guardar código generado, datos procesados, resultados de análisis, etc.",
    parameters: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Ruta relativa del archivo a escribir",
        },
        content: {
          type: "string",
          description: "Contenido a escribir en el archivo",
        },
      },
      required: ["path", "content"],
    },
  },
};

export const fileListToolDefinition = {
  type: "function" as const,
  function: {
    name: "list_files",
    description:
      "Lista archivos y directorios en el workspace. Útil para ver qué archivos están disponibles.",
    parameters: {
      type: "object",
      properties: {
        path: {
          type: "string",
          description: "Ruta relativa del directorio a listar (por defecto: raíz)",
        },
      },
      required: [],
    },
  },
};
