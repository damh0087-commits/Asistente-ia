import axios from "axios";
import * as cheerio from "cheerio";

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export interface SearchToolInput {
  query: string;
  maxResults?: number;
}

export interface SearchToolOutput {
  results: SearchResult[];
  query: string;
}

/**
 * Herramienta de búsqueda web MEJORADA - 100% GRATUITA
 * Usa scraping HTML de DuckDuckGo para obtener resultados reales
 */
export async function searchWeb(
  input: SearchToolInput
): Promise<SearchToolOutput> {
  const { query, maxResults = 5 } = input;

  try {
    // Método 1: Scraping de HTML de DuckDuckGo (más resultados)
    const results = await searchDuckDuckGoHTML(query, maxResults);
    
    if (results.length > 0) {
      return {
        results: results.slice(0, maxResults),
        query,
      };
    }

    // Método 2: Fallback a API de DuckDuckGo
    return await searchDuckDuckGoAPI(query, maxResults);
  } catch (error) {
    console.error("Error en búsqueda web:", error);

    // Fallback final: enlace de búsqueda manual
    return {
      query,
      results: [
        {
          title: `Búsqueda: ${query}`,
          url: `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
          snippet:
            "La búsqueda automática no está disponible temporalmente. Haz clic para buscar manualmente.",
        },
      ],
    };
  }
}

/**
 * Scraping de HTML de DuckDuckGo (método principal)
 * Obtiene resultados REALES de búsqueda - 100% GRATUITO
 */
async function searchDuckDuckGoHTML(
  query: string,
  maxResults: number
): Promise<SearchResult[]> {
  const url = "https://html.duckduckgo.com/html/";
  
  const response = await axios.post(
    url,
    new URLSearchParams({
      q: query,
      b: "",
      kl: "wt-wt",
    }).toString(),
    {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
      timeout: 10000,
    }
  );

  const $ = cheerio.load(response.data);
  const results: SearchResult[] = [];

  // Extraer resultados del HTML
  $(".result").each((_, element) => {
    if (results.length >= maxResults) return false;

    const titleElement = $(element).find(".result__a");
    const snippetElement = $(element).find(".result__snippet");

    const title = titleElement.text().trim();
    const snippet = snippetElement.text().trim();
    
    // La URL está en el atributo href
    let url = titleElement.attr("href") || "";
    
    // DuckDuckGo usa URLs de redirección, extraer la real
    if (url.includes("uddg=")) {
      const match = url.match(/uddg=([^&]+)/);
      if (match) {
        url = decodeURIComponent(match[1]);
      }
    }

    if (title && url) {
      results.push({
        title,
        url,
        snippet: snippet || title,
      });
    }
  });

  return results;
}

/**
 * API de DuckDuckGo Instant Answer (fallback)
 * Limitado pero funciona sin scraping - 100% GRATUITO
 */
async function searchDuckDuckGoAPI(
  query: string,
  maxResults: number
): Promise<SearchToolOutput> {
  const response = await axios.get("https://api.duckduckgo.com/", {
    params: {
      q: query,
      format: "json",
      no_html: 1,
      skip_disambig: 1,
    },
    timeout: 10000,
  });

  const data = response.data;
  const results: SearchResult[] = [];

  // Agregar resultado principal si existe
  if (data.AbstractText && data.AbstractURL) {
    results.push({
      title: data.Heading || query,
      url: data.AbstractURL,
      snippet: data.AbstractText,
    });
  }

  // Agregar resultados relacionados
  if (data.RelatedTopics && Array.isArray(data.RelatedTopics)) {
    for (const topic of data.RelatedTopics) {
      if (results.length >= maxResults) break;

      if (topic.Text && topic.FirstURL) {
        results.push({
          title: topic.Text.split(" - ")[0] || topic.Text.substring(0, 100),
          url: topic.FirstURL,
          snippet: topic.Text,
        });
      }
    }
  }

  // Si no hay resultados, proporcionar enlace de búsqueda manual
  if (results.length === 0) {
    results.push({
      title: `Búsqueda: ${query}`,
      url: `https://duckduckgo.com/?q=${encodeURIComponent(query)}`,
      snippet:
        "No se encontraron resultados directos. Haz clic para buscar manualmente.",
    });
  }

  return {
    results: results.slice(0, maxResults),
    query,
  };
}

/**
 * Definición de la herramienta para el agente
 */
export const searchToolDefinition = {
  type: "function" as const,
  function: {
    name: "search_web",
    description:
      "Busca información en la web usando DuckDuckGo (100% GRATUITO). Obtiene resultados reales con títulos, URLs y descripciones. Útil para encontrar información actualizada, noticias, artículos, documentación, etc.",
    parameters: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "La consulta de búsqueda. Sé específico para mejores resultados.",
        },
        maxResults: {
          type: "number",
          description: "Número máximo de resultados (por defecto 5, máximo 20)",
        },
      },
      required: ["query"],
    },
  },
};
