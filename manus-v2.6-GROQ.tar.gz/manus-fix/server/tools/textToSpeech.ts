import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, unlink, mkdir } from "fs/promises";
import { join } from "path";
import { randomBytes } from "crypto";

const execAsync = promisify(exec);

export interface TextToSpeechInput {
  text: string;
  language?: "es" | "en" | "fr" | "de" | "it" | "pt";
  rate?: number; // velocidad (50-300, default 150)
  volume?: number; // volumen (0.0-1.0, default 1.0)
  voice?: "male" | "female";
}

export interface TextToSpeechOutput {
  success: boolean;
  audioUrl?: string;
  audioPath?: string;
  duration?: number; // en segundos
  message: string;
  error?: string;
}

/**
 * Genera audio desde texto usando pyttsx3 (100% GRATIS)
 * Usa las voces del sistema operativo
 */
export async function generateTextToSpeech(
  input: TextToSpeechInput
): Promise<TextToSpeechOutput> {
  const {
    text,
    language = "es",
    rate = 150,
    volume = 1.0,
    voice = "female",
  } = input;

  // Validar inputs
  if (!text || text.trim().length === 0) {
    return {
      success: false,
      message: "El texto no puede estar vacío",
      error: "Empty text",
    };
  }

  if (text.length > 10000) {
    return {
      success: false,
      message: "El texto es demasiado largo (máximo 10,000 caracteres)",
      error: "Text too long",
    };
  }

  try {
    // Crear directorio para audios si no existe
    const audioDir = "/tmp/agent-audio-generation";
    await mkdir(audioDir, { recursive: true });

    // Generar nombre único para el archivo
    const fileName = `tts_${randomBytes(8).toString("hex")}.mp3`;
    const audioPath = join(audioDir, fileName);

    // Crear script de Python para generar audio
    const pythonScript = `
import pyttsx3
import sys

def generate_speech(text, output_path, rate, volume, language):
    try:
        engine = pyttsx3.init()
        
        # Configurar propiedades
        engine.setProperty('rate', ${rate})
        engine.setProperty('volume', ${volume})
        
        # Seleccionar voz según idioma y género
        voices = engine.getProperty('voices')
        
        # Mapeo de idiomas a códigos
        lang_codes = {
            'es': 'es',
            'en': 'en',
            'fr': 'fr',
            'de': 'de',
            'it': 'it',
            'pt': 'pt'
        }
        
        target_lang = lang_codes.get('${language}', 'en')
        gender_pref = '${voice}'
        
        # Intentar encontrar voz apropiada
        selected_voice = None
        for v in voices:
            voice_lang = v.languages[0] if v.languages else ''
            voice_name = v.name.lower()
            
            # Priorizar idioma correcto
            if target_lang in voice_lang.lower() or target_lang in voice_name:
                # Considerar género si es posible
                if gender_pref == 'female' and ('female' in voice_name or 'zira' in voice_name or 'sabina' in voice_name):
                    selected_voice = v.id
                    break
                elif gender_pref == 'male' and ('male' in voice_name or 'david' in voice_name or 'jorge' in voice_name):
                    selected_voice = v.id
                    break
                # Si no encuentra género específico, usar la primera del idioma
                if selected_voice is None:
                    selected_voice = v.id
        
        # Si no encuentra idioma específico, usar la primera disponible
        if selected_voice is None and len(voices) > 0:
            selected_voice = voices[0].id
        
        if selected_voice:
            engine.setProperty('voice', selected_voice)
        
        # Guardar a archivo
        engine.save_to_file(text, output_path)
        engine.runAndWait()
        
        print("SUCCESS")
        return 0
        
    except Exception as e:
        print(f"ERROR: {str(e)}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    text = """${text.replace(/"/g, '\\"').replace(/\n/g, "\\n")}"""
    output_path = "${audioPath}"
    
    exit_code = generate_speech(text, output_path, ${rate}, ${volume}, '${language}')
    sys.exit(exit_code)
`;

    // Escribir script temporal
    const scriptPath = join(audioDir, `script_${randomBytes(4).toString("hex")}.py`);
    await writeFile(scriptPath, pythonScript, "utf-8");

    // Ejecutar script de Python
    const startTime = Date.now();
    const { stdout, stderr } = await execAsync(
      `python3 "${scriptPath}"`,
      {
        timeout: 60000, // 1 minuto máximo
        maxBuffer: 1024 * 1024 * 10,
      }
    );

    const executionTime = Date.now() - startTime;

    // Limpiar script temporal
    try {
      await unlink(scriptPath);
    } catch {
      // Ignorar errores de limpieza
    }

    // Verificar si fue exitoso
    if (stdout.includes("SUCCESS")) {
      // Estimar duración del audio (aproximado: 150 palabras por minuto)
      const words = text.split(/\s+/).length;
      const estimatedDuration = Math.ceil((words / 150) * 60);

      console.log(
        `✅ Audio generado exitosamente: ${fileName} (${estimatedDuration}s estimados, generado en ${executionTime}ms)`
      );

      return {
        success: true,
        audioPath,
        audioUrl: `/audio/${fileName}`, // URL relativa para el frontend
        duration: estimatedDuration,
        message: `Audio generado exitosamente (${estimatedDuration}s aprox)`,
      };
    } else {
      throw new Error(stderr || "Error desconocido al generar audio");
    }
  } catch (error: any) {
    console.error("❌ Error generando audio:", error);

    return {
      success: false,
      message: "Error al generar audio",
      error: error.message || "Unknown error",
    };
  }
}

/**
 * Definición de la herramienta para el agente
 */
export const textToSpeechToolDefinition = {
  type: "function" as const,
  function: {
    name: "generate_audio",
    description:
      "Genera audio/voz desde texto usando síntesis de voz (TTS). 100% GRATUITO. Útil para crear narraciones, podcasts, tutoriales en audio, mensajes de voz, contenido accesible, etc. Soporta múltiples idiomas y voces.",
    parameters: {
      type: "object",
      properties: {
        text: {
          type: "string",
          description:
            "El texto a convertir en audio. Máximo 10,000 caracteres.",
        },
        language: {
          type: "string",
          enum: ["es", "en", "fr", "de", "it", "pt"],
          description:
            "Idioma del audio: 'es' (español), 'en' (inglés), 'fr' (francés), 'de' (alemán), 'it' (italiano), 'pt' (portugués). Por defecto: 'es'",
        },
        rate: {
          type: "number",
          description:
            "Velocidad de lectura (50-300). 150 es normal, 200 es rápido, 100 es lento. Por defecto: 150",
        },
        volume: {
          type: "number",
          description:
            "Volumen del audio (0.0-1.0). 1.0 es máximo, 0.5 es medio. Por defecto: 1.0",
        },
        voice: {
          type: "string",
          enum: ["male", "female"],
          description:
            "Preferencia de voz: 'male' (masculina) o 'female' (femenina). Por defecto: 'female'",
        },
      },
      required: ["text"],
    },
  },
};
