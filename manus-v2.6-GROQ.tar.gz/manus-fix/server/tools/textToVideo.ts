import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, unlink, mkdir, readFile } from "fs/promises";
import { join } from "path";
import { randomBytes } from "crypto";
import { generateTextToSpeech } from "./textToSpeech";

const execAsync = promisify(exec);

export interface TextToVideoInput {
  text: string;
  style?: "static" | "ken-burns" | "slideshow" | "text-overlay";
  backgroundImages?: string[]; // URLs o paths
  backgroundColor?: string; // Hex color para fondo sólido
  textColor?: string; // Color del texto para text-overlay
  fontSize?: number; // Tamaño de fuente para text-overlay
  transitionDuration?: number; // Duración de transiciones en segundos
  language?: "es" | "en" | "fr" | "de" | "it" | "pt";
  voiceRate?: number;
}

export interface TextToVideoOutput {
  success: boolean;
  videoPath?: string;
  videoUrl?: string;
  duration?: number; // segundos
  generationTime?: number; // segundos
  message: string;
  error?: string;
}

/**
 * Genera video desde texto usando TTS + FFmpeg
 * 100% GRATIS, NO requiere GPU
 * 
 * Estilos:
 * - static: Imagen estática + audio
 * - ken-burns: Zoom/pan suave (efecto Ken Burns)
 * - slideshow: Múltiples imágenes con transiciones
 * - text-overlay: Texto animado sobre fondo
 */
export async function generateTextToVideo(
  input: TextToVideoInput
): Promise<TextToVideoOutput> {
  const {
    text,
    style = "ken-burns",
    backgroundImages = [],
    backgroundColor = "#1a1a2e",
    textColor = "#ffffff",
    fontSize = 48,
    transitionDuration = 1,
    language = "es",
    voiceRate = 150,
  } = input;

  // Validaciones
  if (!text || text.trim().length === 0) {
    return {
      success: false,
      message: "El texto no puede estar vacío",
      error: "Empty text",
    };
  }

  if (text.length > 5000) {
    return {
      success: false,
      message: "El texto es demasiado largo (máximo 5000 caracteres)",
      error: "Text too long",
    };
  }

  try {
    const startTime = Date.now();

    console.log(`🎬 Generando video: estilo=${style}, texto="${text.substring(0, 50)}..."`);

    // Crear directorio para videos
    const videoDir = "/tmp/agent-video-generation";
    await mkdir(videoDir, { recursive: true });

    // Nombre único
    const videoId = randomBytes(8).toString("hex");
    const videoPath = join(videoDir, `video_${videoId}.mp4`);

    // PASO 1: Generar audio con TTS
    console.log("🔊 Generando audio con TTS...");
    const audioResult = await generateTextToSpeech({
      text,
      language,
      rate: voiceRate,
    });

    if (!audioResult.success || !audioResult.audioPath) {
      throw new Error(audioResult.error || "Error generando audio");
    }

    // PASO 2: Generar o preparar imágenes según el estilo
    let imagesPaths: string[] = [];
    
    if (style === "text-overlay") {
      // Generar imagen con texto usando ImageMagick/FFmpeg
      imagesPaths = [await generateTextImage(text, backgroundColor, textColor, fontSize, videoDir)];
    } else if (backgroundImages.length > 0) {
      // Usar imágenes proporcionadas
      imagesPaths = backgroundImages;
    } else {
      // Generar imagen de fondo sólido
      imagesPaths = [await generateSolidBackground(backgroundColor, videoDir)];
    }

    // PASO 3: Generar video según el estilo
    console.log(`🎥 Generando video con estilo: ${style}`);
    
    let ffmpegCommand: string;

    switch (style) {
      case "static":
        ffmpegCommand = await generateStaticVideo(
          imagesPaths[0],
          audioResult.audioPath,
          videoPath
        );
        break;

      case "ken-burns":
        ffmpegCommand = await generateKenBurnsVideo(
          imagesPaths[0],
          audioResult.audioPath,
          videoPath
        );
        break;

      case "slideshow":
        ffmpegCommand = await generateSlideshowVideo(
          imagesPaths,
          audioResult.audioPath,
          videoPath,
          transitionDuration
        );
        break;

      case "text-overlay":
        ffmpegCommand = await generateTextOverlayVideo(
          imagesPaths[0],
          audioResult.audioPath,
          videoPath,
          text
        );
        break;

      default:
        throw new Error(`Estilo no soportado: ${style}`);
    }

    // Ejecutar FFmpeg
    console.log("⚙️  Ejecutando FFmpeg...");
    const { stdout, stderr } = await execAsync(ffmpegCommand, {
      timeout: 300000, // 5 minutos máximo
      maxBuffer: 1024 * 1024 * 50, // 50MB
    });

    const generationTime = Math.floor((Date.now() - startTime) / 1000);
    const duration = audioResult.duration || 0;

    console.log(`✅ Video generado: ${videoPath} (${duration}s, generado en ${generationTime}s)`);

    // Limpiar audio temporal
    try {
      await unlink(audioResult.audioPath);
    } catch {
      // Ignorar errores de limpieza
    }

    return {
      success: true,
      videoPath,
      videoUrl: `/videos/${videoId}.mp4`,
      duration,
      generationTime,
      message: `Video generado exitosamente (${duration}s de video en ${generationTime}s)`,
    };

  } catch (error: any) {
    console.error("❌ Error generando video:", error);

    return {
      success: false,
      message: "Error al generar video",
      error: error.message || "Unknown error",
    };
  }
}

/**
 * Genera imagen con texto usando FFmpeg
 */
async function generateTextImage(
  text: string,
  bgColor: string,
  textColor: string,
  fontSize: number,
  outputDir: string
): Promise<string> {
  const imagePath = join(outputDir, `text_${randomBytes(4).toString("hex")}.png`);

  // Convertir color hex a RGB
  const bgRGB = hexToRgb(bgColor);
  const textRGB = hexToRgb(textColor);

  // Escapar texto para FFmpeg
  const escapedText = text
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\\\'")
    .replace(/:/g, "\\:")
    .replace(/\n/g, "\\n");

  // Generar imagen con texto usando FFmpeg
  const command = `ffmpeg -f lavfi -i color=c=${bgColor}:s=1920x1080:d=1 \
    -vf "drawtext=text='${escapedText}':fontsize=${fontSize}:fontcolor=${textColor}:x=(w-text_w)/2:y=(h-text_h)/2:fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" \
    -frames:v 1 "${imagePath}" -y`;

  await execAsync(command, { timeout: 10000 });

  return imagePath;
}

/**
 * Genera fondo de color sólido
 */
async function generateSolidBackground(
  color: string,
  outputDir: string
): Promise<string> {
  const imagePath = join(outputDir, `bg_${randomBytes(4).toString("hex")}.png`);

  const command = `ffmpeg -f lavfi -i color=c=${color}:s=1920x1080:d=1 \
    -frames:v 1 "${imagePath}" -y`;

  await execAsync(command, { timeout: 10000 });

  return imagePath;
}

/**
 * Video estático: imagen fija + audio
 */
async function generateStaticVideo(
  imagePath: string,
  audioPath: string,
  outputPath: string
): Promise<string> {
  return `ffmpeg -loop 1 -i "${imagePath}" -i "${audioPath}" \
    -c:v libx264 -tune stillimage -c:a aac -b:a 192k \
    -pix_fmt yuv420p -shortest -y "${outputPath}"`;
}

/**
 * Video con efecto Ken Burns (zoom + pan suave)
 */
async function generateKenBurnsVideo(
  imagePath: string,
  audioPath: string,
  outputPath: string
): Promise<string> {
  // Efecto Ken Burns: zoom in + pan
  return `ffmpeg -loop 1 -i "${imagePath}" -i "${audioPath}" \
    -filter_complex "[0:v]scale=8000:-1,zoompan=z='min(zoom+0.0015,1.5)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=125:s=1920x1080:fps=30[v]" \
    -map "[v]" -map 1:a -c:v libx264 -c:a aac -b:a 192k \
    -pix_fmt yuv420p -shortest -y "${outputPath}"`;
}

/**
 * Video slideshow con múltiples imágenes y transiciones
 */
async function generateSlideshowVideo(
  imagesPaths: string[],
  audioPath: string,
  outputPath: string,
  transitionDuration: number
): Promise<string> {
  // Si solo hay una imagen, usar ken-burns
  if (imagesPaths.length === 1) {
    return generateKenBurnsVideo(imagesPaths[0], audioPath, outputPath);
  }

  // Crear input list para FFmpeg
  const inputsStr = imagesPaths.map((p) => `-loop 1 -t 3 -i "${p}"`).join(" ");

  // Crear filtro de transiciones
  const transitionsStr = imagesPaths
    .map((_, i) => {
      if (i === 0) return "[0:v]";
      return `[v${i - 1}][${i}:v]xfade=transition=fade:duration=${transitionDuration}:offset=${i * 3 - transitionDuration}[v${i}]`;
    })
    .join(";");

  const lastVideo = `[v${imagesPaths.length - 2}]`;

  return `ffmpeg ${inputsStr} -i "${audioPath}" \
    -filter_complex "${transitionsStr}" \
    -map "${lastVideo}" -map ${imagesPaths.length}:a \
    -c:v libx264 -c:a aac -b:a 192k -pix_fmt yuv420p \
    -shortest -y "${outputPath}"`;
}

/**
 * Video con texto animado sobre fondo
 */
async function generateTextOverlayVideo(
  imagePath: string,
  audioPath: string,
  outputPath: string,
  text: string
): Promise<string> {
  // Texto con animación de fade in/out
  const escapedText = text.replace(/'/g, "\\\\'").replace(/:/g, "\\:");

  return `ffmpeg -loop 1 -i "${imagePath}" -i "${audioPath}" \
    -filter_complex "[0:v]fade=t=in:st=0:d=1,fade=t=out:st=duration-1:d=1[v]" \
    -map "[v]" -map 1:a -c:v libx264 -c:a aac -b:a 192k \
    -pix_fmt yuv420p -shortest -y "${outputPath}"`;
}

/**
 * Convierte color hex a RGB
 */
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : { r: 0, g: 0, b: 0 };
}

/**
 * Definición de la herramienta para el agente
 */
export const textToVideoToolDefinition = {
  type: "function" as const,
  function: {
    name: "generate_video_from_text",
    description:
      "Genera un video profesional desde texto usando TTS + imágenes/efectos. 100% GRATIS, NO requiere GPU. El video incluye audio narrado automáticamente. Estilos disponibles: 'static' (imagen fija), 'ken-burns' (zoom suave), 'slideshow' (múltiples imágenes), 'text-overlay' (texto animado). Útil para crear videos explicativos, tutoriales, presentaciones, contenido para redes sociales, demos de productos, etc.",
    parameters: {
      type: "object",
      properties: {
        text: {
          type: "string",
          description:
            "Texto a narrar en el video. Se convierte automáticamente a audio. Máximo 5000 caracteres.",
        },
        style: {
          type: "string",
          enum: ["static", "ken-burns", "slideshow", "text-overlay"],
          description:
            "Estilo del video: 'static' (imagen estática + audio), 'ken-burns' (zoom/pan suave sobre imagen), 'slideshow' (múltiples imágenes con transiciones), 'text-overlay' (texto animado sobre fondo). Por defecto: 'ken-burns'",
        },
        backgroundImages: {
          type: "array",
          items: { type: "string" },
          description:
            "URLs o paths de imágenes de fondo. Para slideshow: múltiples imágenes. Para otros estilos: una imagen. Si no se proporciona, se genera un fondo de color.",
        },
        backgroundColor: {
          type: "string",
          description:
            "Color de fondo en formato hex (ej: '#1a1a2e', '#ff5733'). Solo se usa si no hay backgroundImages. Por defecto: '#1a1a2e' (azul oscuro)",
        },
        textColor: {
          type: "string",
          description:
            "Color del texto para style='text-overlay' en formato hex. Por defecto: '#ffffff' (blanco)",
        },
        fontSize: {
          type: "number",
          description:
            "Tamaño de fuente para style='text-overlay'. Por defecto: 48",
        },
        transitionDuration: {
          type: "number",
          description:
            "Duración de transiciones en segundos para style='slideshow'. Por defecto: 1",
        },
        language: {
          type: "string",
          enum: ["es", "en", "fr", "de", "it", "pt"],
          description:
            "Idioma del audio. Por defecto: 'es'",
        },
        voiceRate: {
          type: "number",
          description:
            "Velocidad de la narración (50-300). 150 es normal. Por defecto: 150",
        },
      },
      required: ["text"],
    },
  },
};
