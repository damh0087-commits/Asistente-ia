/**
 * ✅ MÓDULO DE VERSIONADO Y SNAPSHOTS
 * 
 * Características:
 * - Crear snapshots antes de aplicar mejoras
 * - Historial completo de versiones
 * - Rollback a cualquier versión anterior
 * - Diffs entre versiones
 * - Persistencia en base de datos
 */

import { readFile, writeFile, mkdir, rm } from "fs/promises";
import { join } from "path";
import { randomBytes } from "crypto";
import * as fs from "fs";

export interface VersionSnapshot {
  id: string;
  timestamp: Date;
  description: string;
  proposalId?: string;
  author?: string;
  files: Map<string, string>; // path -> content
  metadata: {
    filesCount: number;
    totalSize: number;
    checksum: string;
  };
}

export interface VersionHistory {
  versions: VersionSnapshot[];
  currentVersion: string;
}

/**
 * Archivos que se incluyen en snapshots
 */
const SNAPSHOT_FILES = [
  "server/agent.ts",
  "server/routers.ts",
  "server/tools/selfImprovement.ts",
  "server/tools/codeExecutor.ts",
  "server/tools/search.ts",
  "server/tools/browser.ts",
  "server/tools/dataAnalyzer.ts",
  "server/tools/fileSystem.ts",
  "server/tools/textToSpeech.ts",
  "server/tools/projectGenerator.ts",
  "server/toolCache.ts",
  "server/toolValidation.ts",
  "drizzle/schema.ts",
  "package.json",
];

/**
 * Directorio de almacenamiento de snapshots
 */
const SNAPSHOTS_DIR = ".manus-snapshots";

/**
 * Crea un snapshot del estado actual
 */
export async function createSnapshot(
  description: string,
  proposalId?: string,
  author?: string,
  projectRoot: string = process.cwd()
): Promise<VersionSnapshot> {
  console.log(`[Versioning] 📸 Creando snapshot: "${description}"`);

  const snapshot: VersionSnapshot = {
    id: `v-${Date.now()}-${randomBytes(4).toString("hex")}`,
    timestamp: new Date(),
    description,
    proposalId,
    author,
    files: new Map(),
    metadata: {
      filesCount: 0,
      totalSize: 0,
      checksum: "",
    },
  };

  // Capturar estado de archivos críticos
  for (const filePath of SNAPSHOT_FILES) {
    const fullPath = join(projectRoot, filePath);

    try {
      const content = await readFile(fullPath, "utf-8");
      snapshot.files.set(filePath, content);
      snapshot.metadata.totalSize += content.length;
    } catch (error) {
      console.warn(`[Versioning] ⚠️ No se pudo leer ${filePath}: ${error}`);
    }
  }

  snapshot.metadata.filesCount = snapshot.files.size;
  snapshot.metadata.checksum = generateChecksum(snapshot);

  // Guardar snapshot en almacenamiento
  await saveSnapshotToStorage(snapshot, projectRoot);

  console.log(
    `[Versioning] ✅ Snapshot creado: ${snapshot.id} (${snapshot.metadata.filesCount} archivos)`
  );

  return snapshot;
}

/**
 * Restaura un snapshot anterior
 */
export async function restoreSnapshot(
  versionId: string,
  projectRoot: string = process.cwd()
): Promise<boolean> {
  console.log(`[Versioning] 🔄 Restaurando snapshot: ${versionId}`);

  try {
    const snapshot = await loadSnapshotFromStorage(versionId, projectRoot);

    if (!snapshot) {
      console.error(`[Versioning] ❌ Snapshot no encontrado: ${versionId}`);
      return false;
    }

    // Restaurar cada archivo
    for (const [filePath, content] of snapshot.files) {
      const fullPath = join(projectRoot, filePath);

      try {
        await writeFile(fullPath, content, "utf-8");
        console.log(`[Versioning] ✓ Restaurado: ${filePath}`);
      } catch (error) {
        console.error(`[Versioning] ❌ Error restaurando ${filePath}: ${error}`);
        return false;
      }
    }

    console.log(
      `[Versioning] ✅ Snapshot restaurado: ${versionId} (${snapshot.metadata.filesCount} archivos)`
    );
    return true;
  } catch (error) {
    console.error(`[Versioning] ❌ Error durante restauración:`, error);
    return false;
  }
}

/**
 * Obtiene el historial de versiones
 */
export async function getVersionHistory(
  projectRoot: string = process.cwd()
): Promise<VersionHistory> {
  try {
    const snapshotsPath = join(projectRoot, SNAPSHOTS_DIR);

    // Crear directorio si no existe
    await mkdir(snapshotsPath, { recursive: true });

    // Leer lista de snapshots
    const files = await fs.promises.readdir(snapshotsPath);
    const snapshots: VersionSnapshot[] = [];

    for (const file of files) {
      if (file.endsWith(".json")) {
        try {
          const snapshot = await loadSnapshotFromStorage(
            file.replace(".json", ""),
            projectRoot
          );
          if (snapshot) {
            snapshots.push(snapshot);
          }
        } catch (error) {
          console.warn(`[Versioning] Error cargando snapshot ${file}:`, error);
        }
      }
    }

    // Ordenar por timestamp (más reciente primero)
    snapshots.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    return {
      versions: snapshots,
      currentVersion: snapshots.length > 0 ? snapshots[0].id : "none",
    };
  } catch (error) {
    console.error(`[Versioning] Error obteniendo historial:`, error);
    return {
      versions: [],
      currentVersion: "none",
    };
  }
}

/**
 * Obtiene información de un snapshot específico
 */
export async function getSnapshotInfo(
  versionId: string,
  projectRoot: string = process.cwd()
): Promise<VersionSnapshot | null> {
  try {
    return await loadSnapshotFromStorage(versionId, projectRoot);
  } catch (error) {
    console.error(`[Versioning] Error obteniendo snapshot ${versionId}:`, error);
    return null;
  }
}

/**
 * Genera diff entre dos versiones
 */
export async function generateDiff(
  versionId1: string,
  versionId2: string,
  projectRoot: string = process.cwd()
): Promise<Map<string, { before: string; after: string; changes: number }>> {
  const snapshot1 = await loadSnapshotFromStorage(versionId1, projectRoot);
  const snapshot2 = await loadSnapshotFromStorage(versionId2, projectRoot);

  const diffs = new Map<string, { before: string; after: string; changes: number }>();

  if (!snapshot1 || !snapshot2) {
    return diffs;
  }

  // Comparar archivos
  const allFiles = new Set([...snapshot1.files.keys(), ...snapshot2.files.keys()]);

  for (const file of allFiles) {
    const content1 = snapshot1.files.get(file) || "";
    const content2 = snapshot2.files.get(file) || "";

    if (content1 !== content2) {
      const changes = calculateChanges(content1, content2);
      diffs.set(file, {
        before: content1,
        after: content2,
        changes,
      });
    }
  }

  return diffs;
}

/**
 * Guarda snapshot en almacenamiento
 */
async function saveSnapshotToStorage(
  snapshot: VersionSnapshot,
  projectRoot: string
): Promise<void> {
  const snapshotsPath = join(projectRoot, SNAPSHOTS_DIR);
  await mkdir(snapshotsPath, { recursive: true });

  const snapshotPath = join(snapshotsPath, `${snapshot.id}.json`);

  // Convertir Map a objeto para serialización
  const snapshotData = {
    ...snapshot,
    files: Object.fromEntries(snapshot.files),
  };

  await writeFile(snapshotPath, JSON.stringify(snapshotData, null, 2), "utf-8");
  console.log(`[Versioning] 💾 Snapshot guardado: ${snapshotPath}`);
}

/**
 * Carga snapshot desde almacenamiento
 */
async function loadSnapshotFromStorage(
  versionId: string,
  projectRoot: string
): Promise<VersionSnapshot | null> {
  const snapshotsPath = join(projectRoot, SNAPSHOTS_DIR);
  const snapshotPath = join(snapshotsPath, `${versionId}.json`);

  try {
    const data = await readFile(snapshotPath, "utf-8");
    const parsed = JSON.parse(data);

    // Convertir objeto a Map
    const snapshot: VersionSnapshot = {
      ...parsed,
      timestamp: new Date(parsed.timestamp),
      files: new Map(Object.entries(parsed.files)),
    };

    return snapshot;
  } catch (error) {
    console.warn(`[Versioning] No se pudo cargar snapshot ${versionId}:`, error);
    return null;
  }
}

/**
 * Genera checksum para verificar integridad
 */
function generateChecksum(snapshot: VersionSnapshot): string {
  const crypto = require("crypto");
  const content = Array.from(snapshot.files.values()).join("|");
  return crypto.createHash("sha256").update(content).digest("hex");
}

/**
 * Calcula número de cambios entre dos versiones de archivo
 */
function calculateChanges(before: string, after: string): number {
  const beforeLines = before.split("\n");
  const afterLines = after.split("\n");

  let changes = 0;

  // Contar líneas diferentes
  const maxLines = Math.max(beforeLines.length, afterLines.length);
  for (let i = 0; i < maxLines; i++) {
    if ((beforeLines[i] || "") !== (afterLines[i] || "")) {
      changes++;
    }
  }

  return changes;
}

/**
 * Limpia snapshots antiguos (mantiene últimos N)
 */
export async function cleanupOldSnapshots(
  keepCount: number = 10,
  projectRoot: string = process.cwd()
): Promise<number> {
  console.log(`[Versioning] 🧹 Limpiando snapshots antiguos (mantener últimos ${keepCount})`);

  const history = await getVersionHistory(projectRoot);

  if (history.versions.length <= keepCount) {
    console.log(`[Versioning] ℹ️ No hay snapshots para limpiar`);
    return 0;
  }

  const snapshotsPath = join(projectRoot, SNAPSHOTS_DIR);
  let deleted = 0;

  // Eliminar snapshots antiguos
  for (let i = keepCount; i < history.versions.length; i++) {
    const snapshot = history.versions[i];
    const snapshotPath = join(snapshotsPath, `${snapshot.id}.json`);

    try {
      await rm(snapshotPath);
      deleted++;
      console.log(`[Versioning] 🗑️  Eliminado: ${snapshot.id}`);
    } catch (error) {
      console.warn(`[Versioning] Error eliminando ${snapshot.id}:`, error);
    }
  }

  console.log(`[Versioning] ✅ Limpieza completada (${deleted} snapshots eliminados)`);
  return deleted;
}

/**
 * Genera reporte de historial de versiones
 */
export async function generateVersionReport(
  projectRoot: string = process.cwd()
): Promise<string> {
  const history = await getVersionHistory(projectRoot);

  let report = `
╔════════════════════════════════════════════════════════════════╗
║                  HISTORIAL DE VERSIONES                       ║
╚════════════════════════════════════════════════════════════════╝

Versión actual: ${history.currentVersion}
Total de snapshots: ${history.versions.length}

`;

  for (const snapshot of history.versions) {
    report += `
📸 ${snapshot.id}
   Fecha: ${snapshot.timestamp.toLocaleString()}
   Descripción: ${snapshot.description}
   ${snapshot.proposalId ? `Propuesta: ${snapshot.proposalId}` : ""}
   ${snapshot.author ? `Autor: ${snapshot.author}` : ""}
   Archivos: ${snapshot.metadata.filesCount}
   Tamaño: ${(snapshot.metadata.totalSize / 1024).toFixed(2)} KB
   Checksum: ${snapshot.metadata.checksum.substring(0, 8)}...
`;
  }

  return report;
}
